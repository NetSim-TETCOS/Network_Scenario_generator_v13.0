﻿using System;
using System.Text;
using System.Xml;


namespace NetSim_Scenario_Generation_5GLTE
{
    class AddNetworkElement
    {
        private static XmlWriter nsWriter = new XmlWriter();

        /*
          func: function generated an Ipv4 
          params: id- rank(numbered) of device to which ipv4 has to be assigned
                  _4th- fourth octate value of the ip to be generated 
          return: return the generated ipv4
        */
        public string next_ip(int id, int _4th)
        {
            int _4th_octate = _4th, _3rd_octate = 0, _2nd_octate = 0, _1st_octate = 11;
            _3rd_octate += id % 200;
            _2nd_octate += (id % 200) % 200;
            _1st_octate += ((id / 200) / 200) % 200;
            string ip = Convert.ToString(_1st_octate) + "." + Convert.ToString(_2nd_octate) + "." +
                        Convert.ToString(_3rd_octate) + "." + Convert.ToString(_4th_octate);
            return ip;
        }
        public string next_ip_1(int id, int _4th)
        {
            int _4th_octate = _4th, _3rd_octate = 0, _2nd_octate = 0, _1st_octate = 10;
            _3rd_octate += id % 200;
            _2nd_octate += (id / 200) % 200;
            _1st_octate += ((id / 200) / 200) % 200;
            string ip = Convert.ToString(_1st_octate) + "." + Convert.ToString(_2nd_octate) + "." +
                        Convert.ToString(_3rd_octate) + "." + Convert.ToString(_4th_octate);
            return ip;
        }
        public string next_ip_2(int id, int _4th)
        {
            int _4th_octate = _4th, _3rd_octate = 0, _2nd_octate = 0, _1st_octate = 11;
            _3rd_octate += id % 200;
            _2nd_octate += (id / 200) % 200 + 1;
            _1st_octate += ((id / 200) / 200) % 200;
            string ip = Convert.ToString(_1st_octate) + "." + Convert.ToString(_2nd_octate) + "." +
                        Convert.ToString(_3rd_octate) + "." + Convert.ToString(_4th_octate);
            return ip;
        }
        public string next_ip_3(int id, int _4th)
        {
            int _4th_octate = _4th, _3rd_octate = 0, _2nd_octate = 0, _1st_octate = 11;
            _3rd_octate += id % 200;
            _2nd_octate += (id / 200) % 200 + 2;
            _1st_octate += ((id / 200) / 200) % 200;
            string ip = Convert.ToString(_1st_octate) + "." + Convert.ToString(_2nd_octate) + "." +
                        Convert.ToString(_3rd_octate) + "." + Convert.ToString(_4th_octate);
            return ip;
        }

        /*
           func: function generated an IME1_NUMBER of UE
           params: id- rank(numbered) of device to which IME1_NUMBER has to be assigned
           return: return the generated IME1_NUMBER
         */
        public string next_ime1_number(string ime1_number)
        {
            int i = 0, j, n, index = 0, id = -1;
            char temp;
            n = ime1_number.Length;
            //Console.WriteLine("value of n: {0}", n);
            StringBuilder str = new StringBuilder(ime1_number);
            for (i = 0; i < n - 1; i++)
            {
                if (str[i] <= str[i + 1])
                {
                    id = i;
                }
            }

            if (id == -1)
                return str.ToString();
            //Console.WriteLine("value of i: {0}", i);
            for (j = id + 1; j < n; j++)
            {
                if (str[j] > str[id])
                    index = j;
            }
            temp = str[id];
            str[id] = str[index];
            str[index] = temp;
            i = id + 1; j = n - 1;
            while (i <= j)
            {
                temp = str[i];
                str[i] = str[j];
                str[j] = temp;
                i++; j--;
            }
            return str.ToString();

        }

        /*
           func: function generated an mobile_number of UE
           params: id- rank(numbered) of device to which mobile_number has to be assigned
           return: return the generated IME1_mobile_number
         */
        public string next_mobile_number(string mobile_number)
        {
            int i = 0, j, n, index = 0, id = -1;
            char temp;
            n = mobile_number.Length;
            //Console.WriteLine("value of n: {0}", n);
            StringBuilder str = new StringBuilder(mobile_number);
            for (i = 0; i < n - 1; i++)
            {
                if (str[i] <= str[i + 1])
                {
                    id = i;
                }
            }

            if (id == -1)
                return str.ToString();
            //Console.WriteLine("value of i: {0}", i);
            for (j = id + 1; j < n; j++)
            {
                if (str[j] > str[id])
                    index = j;
            }
            temp = str[id];
            str[id] = str[index];
            str[index] = temp;
            i = id + 1; j = n - 1;
            while (i <= j)
            {
                temp = str[i];
                str[i] = str[j];
                str[j] = temp;
                i++; j--;
            }
            return str.ToString();

        }


        /*
          func: generates a mac address  
          params: mac- mac address assigned to the previous device
          return: return the generated mac address
        */
        public string next_mac(string mac)
        {
            int i = 0, j, n, index = 0, id = -1;
            char temp;
            n = mac.Length;
            //Console.WriteLine("value of n: {0}", n);
            StringBuilder str = new StringBuilder(mac);
            for (i = 0; i < n - 1; i++)
            {
                if (str[i] <= str[i + 1])
                {
                    id = i;
                }
            }

            if (id == -1)
                return str.ToString();
            //Console.WriteLine("value of i: {0}", i);
            for (j = id + 1; j < n; j++)
            {
                if (str[j] > str[id])
                    index = j;
            }
            temp = str[id];
            str[id] = str[index];
            str[index] = temp;
            i = id + 1; j = n - 1;
            while (i <= j)
            {
                temp = str[i];
                str[i] = str[j];
                str[j] = temp;
                i++; j--;
            }
            return str.ToString();
        }

        /*
          func: generates subnet mask(fixed here to 255.255.255.0)
          params: no params
          return: return the subnet mask
        */
        public string subnet_mask()
        {
            return "255.255.0.0";
        }


        /*
          func: adds a router(device) as child node to DEVICE_CONFIGUARTION(parent node)
          params: deviceConfig:-reference to parent node(DEVICE_CONFIGUARTION)
                  device_attribute:- attributs of router
                  pos_3d_attribute:-postion info of router
                  interface_variables:- interface info of router
          return: doesnt return
        */
        public void add_router(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\Router\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(device_attribute.WIRESHARK_OPTION),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("SERIAL"))
                    folder = "Serial";
                else if (interface_variables[i].INTERFACE_TYPE.Equals("WAN"))
                    folder = "Wan";
                else
                    folder = "Ethernet";

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\Router\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                    Convert.ToString(interface_variables[i].IP_ADDRESS),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
            }
            XmlNode routing_protocol = nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\Router\\Application_Layer.txt");
      
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\Router\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\Router\\Network_Layer.txt");
        }
        public void add_router_NSA(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location,string[] args)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\NSA\\Router\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(device_attribute.WIRESHARK_OPTION),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("SERIAL"))
                    folder = "Serial";
                else if (interface_variables[i].INTERFACE_TYPE.Equals("WAN"))
                    folder = "Wan";
                else
                    folder = "Ethernet";

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\Router\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                    Convert.ToString(interface_variables[i].IP_ADDRESS),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
            }
            if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
            {
                nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\Router\\Application_Layer.txt");
            }
            else
            {
                nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\Router\\App_Op\\Application_Layer.txt");

            }

            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\Router\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\Router\\Network_Layer.txt");
        }
        /*
          func: adds a wirednode(device) as child node to DEVICE_CONFIGUARTION(parent node)
          params: deviceConfig:-reference to parent node(DEVICE_CONFIGUARTION)
                  device_attribute:- attributs of wirednode
                  pos_3d_attribute:-postion info of wirednode
                  interface_variables:- interface info of wirednode
          return: doesnt return
        */
        public void add_wired_node(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\WiredNode\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.WIRESHARK_OPTION),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\WiredNode\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                    Convert.ToString(interface_variables[i].IP_ADDRESS),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
            }
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\WiredNode\\Application_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\WiredNode\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\WiredNode\\Network_Layer.txt");
        }

        public void add_wired_node_NSA(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\NSA\\WiredNode\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.WIRESHARK_OPTION),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\WiredNode\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                    Convert.ToString(interface_variables[i].IP_ADDRESS),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
            }
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\WiredNode\\Application_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\WiredNode\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\WiredNode\\Network_Layer.txt");
        }



        /*
          func: adds a UE(device) as child node to DEVICE_CONFIGUARTION(parent node)
          params: deviceConfig:-reference to parent node(DEVICE_CONFIGUARTION)
                  device_attribute:- attributs of UE
                  pos_3d_attribute:-postion info of UE
                  interface_variables:- interface info of UE
                  other_info- extra info about the UE
          return: doesnt return
        */
        public void add_UE(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\UE\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.WIRESHARK_OPTION),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));

            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_RAN"))
                    folder = "5G_RAN";
                else
                    folder = "LTE";

                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\UE\\" + folder + "\\Interface.txt",
               Convert.ToString(interface_variables[i].ID),
               Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
               Convert.ToString(interface_variables[i].IP_ADDRESS),
               Convert.ToString(interface_variables[i].SUBNET_MASK),
               Convert.ToString(interface_variables[i].IMEI_NUMBER),
               Convert.ToString(interface_variables[i].MOBILE_NUMBER));
                

               
            }

            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\UE\\Application_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\UE\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\UE\\Network_Layer.txt");
        }
        //
        public void add_UE_NSA(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location,string[] args)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\NSA\\UE\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.WIRESHARK_OPTION),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));

            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
                {
                    if (interface_variables[i].INTERFACE_TYPE.Equals("5G_RAN"))
                        folder = "5G_RAN";
                    else
                        folder = "LTE";

                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\UE\\" + folder + "\\Interface.txt",
           Convert.ToString(interface_variables[i].ID),
           Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
           Convert.ToString(interface_variables[i].IP_ADDRESS),
           Convert.ToString(interface_variables[i].SUBNET_MASK),
           Convert.ToString(interface_variables[i].IMEI_NUMBER),
           Convert.ToString(interface_variables[i].MOBILE_NUMBER),
           Convert.ToString(args[1]));
                }
                else if((args[1] == "OPTION_7") || (args[1] == "OPTION_7a") || (args[1] == "OPTION_7x"))
                {
                    if (interface_variables[i].INTERFACE_TYPE.Equals("5G_RAN"))
                        folder = "5G_RANOp7";
                    else
                        folder = "LTE_Op7";

                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\UE\\" + folder + "\\Interface.txt",
           Convert.ToString(interface_variables[i].ID),
           Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
           Convert.ToString(interface_variables[i].IP_ADDRESS),
           Convert.ToString(interface_variables[i].SUBNET_MASK),
           Convert.ToString(interface_variables[i].IMEI_NUMBER),
           Convert.ToString(interface_variables[i].MOBILE_NUMBER),
           Convert.ToString(args[1]));
                }
                else
                {
                    if (interface_variables[i].INTERFACE_TYPE.Equals("5G_RAN"))
                        folder = "5G_RANOp";
                    else
                        folder = "LTE_Op";

                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\UE\\" + folder + "\\Interface.txt",
           Convert.ToString(interface_variables[i].ID),
           Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
           Convert.ToString(interface_variables[i].IP_ADDRESS),
           Convert.ToString(interface_variables[i].SUBNET_MASK),
           Convert.ToString(interface_variables[i].IMEI_NUMBER),
           Convert.ToString(interface_variables[i].MOBILE_NUMBER),
           Convert.ToString(args[1]));

                }
                

            }

            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\UE\\Application_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\UE\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\UE\\Network_Layer.txt");
        }
        /*
          func: adds a GNB(device) as child node to DEVICE_CONFIGUARTION(parent node)
          params: deviceConfig:-reference to parent node(DEVICE_CONFIGUARTION)
                  device_attribute:- attributs of GNB
                  pos_3d_attribute:-postion info of GNB
                  interface_variables:- interface info of GNB
          return: doesnt return
        */
        public void add_GNB(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\GNB\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N3"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\GNB\\5G_N3\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].IP_ADDRESS),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS),
                         Convert.ToString(interface_variables[i].CONNECTED_TO));

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N1_N2"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\GNB\\5G_N1_N2\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].IP_ADDRESS),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS),
                         Convert.ToString(interface_variables[i].CONNECTED_TO));

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_XN"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\GNB\\5G_XN\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                           Convert.ToString(interface_variables[i].IP_ADDRESS),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS),
                          Convert.ToString(interface_variables[i].CONNECTED_TO));

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_RAN"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\GNB\\5G_RAN\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS));

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("LTE_S1"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\LTE_S1\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].IP_ADDRESS),
                         Convert.ToString(interface_variables[i].SUBNET_MASK),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS));

                }
            }
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\GNB\\Application_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\GNB\\Transport_Layer.txt");

        }

        //
        public void add_GNB_NSA(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location,string[] args)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_XN"))
                {
                    if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_XN\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].IP_ADDRESS),
                         Convert.ToString(interface_variables[i].SUBNET_MASK),
                        Convert.ToString(args[1]),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS),
                          Convert.ToString(interface_variables[i].CONNECTED_TO));
                    }
                    else if ((args[1] == "OPTION_7") || (args[1] == "OPTION_7a") || (args[1] == "OPTION_7x"))
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_XN_OP7\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].IP_ADDRESS),
                         Convert.ToString(interface_variables[i].SUBNET_MASK),
                        Convert.ToString(args[1]),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS),
                          Convert.ToString(interface_variables[i].CONNECTED_TO));
                    }
                    else
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_XN_OP\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].IP_ADDRESS),
                         Convert.ToString(interface_variables[i].SUBNET_MASK),
                        Convert.ToString(args[1]),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS),
                          Convert.ToString(interface_variables[i].CONNECTED_TO));
                    }

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_RAN"))
                {
                    if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_RAN_OP\\Interface.txt",
                             Convert.ToString(interface_variables[i].ID),
                             Convert.ToString(interface_variables[i].MAC_ADDRESS),
                             Convert.ToString(args[1]));
                    }
                    else
                    {
                        if ((args[1] == "OPTION_7") || (args[1] == "OPTION_7a") || (args[1] == "OPTION_7x"))
                        {
                            nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_RAN_OP7\\Interface.txt",
                                Convert.ToString(interface_variables[i].ID),
                                Convert.ToString(interface_variables[i].MAC_ADDRESS),
                                Convert.ToString(args[1]));
                        }
                        else
                        {
                            nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_RAN_OP\\Interface.txt",
                                Convert.ToString(interface_variables[i].ID),
                                Convert.ToString(interface_variables[i].MAC_ADDRESS),
                                Convert.ToString(args[1]));
                        }
                    }

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("LTE_S1"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\LTE_S1\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].IP_ADDRESS),
                         Convert.ToString(interface_variables[i].SUBNET_MASK),
                         Convert.ToString(args[1]),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS));

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N3"))
                {
                    if ((args[1] == "OPTION_7") || (args[1] == "OPTION_7a") || (args[1] == "OPTION_7x"))
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_N3OP7\\Interface.txt",
                              Convert.ToString(interface_variables[i].ID),
                              Convert.ToString(interface_variables[i].IP_ADDRESS),
                              Convert.ToString(interface_variables[i].SUBNET_MASK),
                              Convert.ToString(args[1]),
                              Convert.ToString(interface_variables[i].MAC_ADDRESS));
                    }
                  
                    else
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_N3\\Interface.txt",
                             Convert.ToString(interface_variables[i].ID),
                             Convert.ToString(interface_variables[i].IP_ADDRESS),
                             Convert.ToString(interface_variables[i].SUBNET_MASK),
                             Convert.ToString(args[1]),
                             Convert.ToString(interface_variables[i].MAC_ADDRESS));
                    }
                }
                    
                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N1_N2"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_N1_N2\\Interface.txt",
                        Convert.ToString(interface_variables[i].ID),
                        Convert.ToString(interface_variables[i].IP_ADDRESS),
                        Convert.ToString(interface_variables[i].SUBNET_MASK),
                        Convert.ToString(interface_variables[i].MAC_ADDRESS));
                }
              


            }

            if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
            {
                nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\Application_Layer.txt");
            }
            else if(args[1] == "OPTION_7") 
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_RAN_OP7\\Application_Layer.txt",
                    Convert.ToString(args[1]));
            }
            else if((args[1] == "OPTION_7a") || (args[1] == "OPTION_7x"))
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\App_7a\\Application_Layer.txt",
                   Convert.ToString(args[1]));
            }
            else
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\5G_RAN_OP\\Application_Layer.txt",
                    Convert.ToString(args[1]));
            }
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\GNB\\Transport_Layer.txt");

        }



        /*
          func: adds a router(device) as child node to DEVICE_CONFIGUARTION(parent node)
          params: deviceConfig:-reference to parent node(DEVICE_CONFIGUARTION)
                  device_attribute:- attributs of router
                  pos_3d_attribute:-postion info of router
                  interface_variables:- interface info of router
          return: doesnt return
        */

        //add AMF_device
        public void add_AMF(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location, string[] args,string[] gnb_ip_address)
        {
            int r;
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\AMF\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));

            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N1_N2"))
                    folder = "5G_N1_N2";
                else
                    folder = "5G_N11";

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\AMF\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
               /* nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\AMF\\Application_Layer.txt",
                   Convert.ToString(args[4]),
                   Convert.ToString("GNB_IP_ADDRESS"),
                   Convert.ToString(interface_variables[i].IP_ADDRESS));*/

            }
            //  nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\AMF\\Application_Layer.txt");
            // nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\AMF\\Application_Layer.txt",
            //  Convert.ToString(args[4]));

        
            int count = Convert.ToInt32(args[4]);
            string arr = "NGAP GNB_IP_ADDRESS";
            // for (r = 0; r < count; r++)
            // {
            nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\AMF\\Application_Layer.txt",
                   Convert.ToString(args[4]),
                   Convert.ToString(arr),
                   Convert.ToString(gnb_ip_address[1]));
          //  }

            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\AMF\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\AMF\\Network_Layer.txt");
        }
        //add AMF device for NSA mode
        public void add_AMF_NSA(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location,string[] args)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\NSA\\AMF\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));

            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N1_N2"))
                    folder = "5G_N1_N2";
                else
                    folder = "5G_N11";

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\AMF\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].IP_ADDRESS),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(args[1]),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
               


            }
            if(args[1] == "OPTION_4a")
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\AMF\\App_4a\\Application_Layer.txt",
                Convert.ToString(args[1]));
            }
            else if(args[1] == "OPTION_7")
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\AMF\\App_7\\Application_Layer.txt",
               Convert.ToString(args[1]));
            }
            else if(args[1] == "OPTION_7a")
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\AMF\\App_7a\\Application_Layer.txt",
               Convert.ToString(args[1]));
            }
            else if (args[1] == "OPTION_7x")
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\AMF\\App_7x\\Application_Layer.txt",
               Convert.ToString(args[1]));
            }
            else
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\AMF\\Application_Layer.txt",
                   Convert.ToString(args[1]));
            }
            
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\AMF\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\AMF\\Network_Layer.txt");
        }

        //add SMF device
        public void add_SMF(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\SMF\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));

            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N4"))
                    folder = "5G_N4";
                else
                    folder = "5G_N11";

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\SMF\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                     Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
            }
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\SMF\\Application_Layer.txt");
            
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\SMF\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\SMF\\Network_Layer.txt");
        }
        // Add SMF device for NSA mode
        public void add_SMF_NSA(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location,string[] args)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\SMF\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));

            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N4"))
                    folder = "5G_N4";
                else
                    folder = "5G_N11";

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\SMF\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                     Convert.ToString(interface_variables[i].IP_ADDRESS),
                     Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                     Convert.ToString(args[1]),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
               
            }
            
            nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\SMF\\Application_Layer.txt",
                   Convert.ToString(args[1]));
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\SMF\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\SMF\\Network_Layer.txt");
        }
        //add UPF device
        public void add_UPF(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location, string[] args,string[] gnb_ip_address)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\UPF\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));

            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N4"))
                    folder = "5G_N4";
                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N3"))
                    folder = "5G_N3";
                else
                {
                    folder = "5G_N6";
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\UPF\\" + folder + "\\Interface.txt",
                   Convert.ToString(interface_variables[i].ID),
                   Convert.ToString(interface_variables[i].IP_ADDRESS),
                   Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                   Convert.ToString(interface_variables[i].SUBNET_MASK),
                   Convert.ToString(interface_variables[i].MAC_ADDRESS),
                   Convert.ToString(interface_variables[i].CONNECTED_TO));
                    break;
                }

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\UPF\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));

                

            }
            int r;
            string arr = "GTP_U GNB_IP_ADDRESS";

            int count = Convert.ToInt32(args[4]);
            // for (r = 0; r < count; r++)
            // {
            nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\UPF\\Application_Layer.txt",
                   Convert.ToString(args[4]),
                  Convert.ToString(arr),
                  Convert.ToString(gnb_ip_address[0]));//+ );
           // }

            //nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\UPF\\Application_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\UPF\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\UPF\\Network_Layer.txt");
        }
        //Add UPF device for NSA mode
        public void add_UPF_NSA(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location, string[] args)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\NSA\\UPF\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));

            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N4"))
                    folder = "5G_N4";
                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N3"))
                    folder = "5G_N3";
                else
                    folder = "5G_N6";
                   

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\UPF\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].IP_ADDRESS),
                    Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(args[1]),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
              

            }
            if (args[1] == "OPTION_4a")
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\UPF\\App_4a\\Application_Layer.txt",
                    Convert.ToString(args[1]));
            }
            else if(args[1] == "OPTION_7")
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\UPF\\App_7\\Application_Layer.txt",
                    Convert.ToString(args[1]));
            }
            else if (args[1] == "OPTION_7a")
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\UPF\\App_7a\\Application_Layer.txt",
                    Convert.ToString(args[1]));
            }
            else if (args[1] == "OPTION_7x")
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\UPF\\App_7x\\Application_Layer.txt",
                   Convert.ToString(args[1]));
            }
            else
            {
                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\UPF\\Application_Layer.txt",
                    Convert.ToString(args[1]));
            }
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\UPF\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\UPF\\Network_Layer.txt");
        }


        // Add L2_Switch_4
        /* public void add_L2_Switch(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
         {


             for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
             {
                 string folder;
                 if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N1_N2"))
                     folder = "L2_Switch_AMF";
                 else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_XN"))
                     folder = "L2_Switch_gNB";
                 else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N3"))
                     folder = "L2_Switch_UPF";
                 else
                     folder = "Ethernet";

                 XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\L2_Switch\\" + folder + "\\Device.txt",
                   Convert.ToString(device_attribute.DEVICE_ID),
                   Convert.ToString(device_attribute.DEVICE_NAME),
                   Convert.ToString(device_attribute.INTERFACE_COUNT),
                   Convert.ToString(pos_3d_attribute.X_OR_LON),
                   Convert.ToString(pos_3d_attribute.Y_OR_LAT));

                 nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\L2_Switch\\" + folder + "\\Interface.txt",
                     Convert.ToString(interface_variables[i].ID),
                     Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                     Convert.ToString(interface_variables[i].IP_ADDRESS),
                     Convert.ToString(interface_variables[i].SUBNET_MASK),
                     Convert.ToString(interface_variables[i].MAC_ADDRESS),
                     Convert.ToString(interface_variables[i].CONNECTED_TO));
             }

         }*/


        // add L2_Switch_UPF
        public void add_L2_Switch_UPF(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\L2_Switch_UPF\\Device.txt",
              Convert.ToString(device_attribute.DEVICE_ID),
              Convert.ToString(device_attribute.DEVICE_NAME),
              Convert.ToString(device_attribute.INTERFACE_COUNT),
              Convert.ToString(pos_3d_attribute.X_OR_LON),
              Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("ETHERNET"))
                {
                    folder = "Ethernet";
                }
             else
                    folder = "5G_N3";

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\L2_Switch_UPF\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
            }

        }

        //Add L2_Switch_AMF

        public void add_L2_Switch_AMF(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\L2_Switch_AMF\\Device.txt",
              Convert.ToString(device_attribute.DEVICE_ID),
              Convert.ToString(device_attribute.DEVICE_NAME),
              Convert.ToString(device_attribute.INTERFACE_COUNT),
              Convert.ToString(pos_3d_attribute.X_OR_LON),
              Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("ETHERNET"))
                    folder = "Ethernet";
                else
                    folder = "5G_N1_N2";

                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\L2_Switch_AMF\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
            }

        }

        //Add L2_Switch_gNB
        public void add_L2_Switch_gNB(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\L2_Switch_gNB\\Device.txt",
              Convert.ToString(device_attribute.DEVICE_ID),
              Convert.ToString(device_attribute.DEVICE_NAME),
              Convert.ToString(device_attribute.INTERFACE_COUNT),
              Convert.ToString(pos_3d_attribute.X_OR_LON),
              Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;

                if (interface_variables[i].INTERFACE_TYPE.Equals("ETHERNET"))
                    folder = "Ethernet";
               
                else
                {
                    folder = "5G_XN";
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\L2_Switch_gNB\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS));
                }


                nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\L2_Switch_gNB\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
            }

        }

        //add EPC
        public void add_EPC(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location, string[] args)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\NSA\\EPC\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));

            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                string folder;
                if (interface_variables[i].INTERFACE_TYPE.Equals("WAN"))
                {
                    folder = "WAN";
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\EPC\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                    Convert.ToString(interface_variables[i].IP_ADDRESS),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
                }

                else if (interface_variables[i].INTERFACE_TYPE.Equals("LTE"))
                {
                    folder = "LTE";
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\EPC\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                    Convert.ToString(interface_variables[i].IP_ADDRESS),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(args[1]),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
                }

                else
                {
                    folder = "LTE_NR";
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\EPC\\" + folder + "\\Interface.txt",
                    Convert.ToString(interface_variables[i].ID),
                    Convert.ToString(interface_variables[i].DEFAULT_GATEWAY),
                    Convert.ToString(interface_variables[i].IP_ADDRESS),
                    Convert.ToString(interface_variables[i].SUBNET_MASK),
                    Convert.ToString(args[1]),
                    Convert.ToString(interface_variables[i].MAC_ADDRESS),
                    Convert.ToString(interface_variables[i].CONNECTED_TO));
                  
                }

                
            }
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\EPC\\Application_Layer.txt");

            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\EPC\\Transport_Layer.txt");
            nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\EPC\\Network_Layer.txt");
        }

        //add L2_Switch_2_NSA
        public void add_L2_Switch_NSA(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\NSA\\L2_Switch\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                if (interface_variables[i].INTERFACE_TYPE.Equals("ETHERNET"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\L2_Switch\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS),
                         Convert.ToString(interface_variables[i].CONNECTED_TO));

                }

            }
            // nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\L2_Switch\\Application_Layer.txt");

        }

        //Add ENB
        public void add_LTE_eNB(XmlNode deviceConfig, DEVICE device_attribute, POS_3D pos_3d_attribute, INTERFACE[] interface_variables, string config_helper_location,string[] args)
        {
            XmlNode device = nsWriter.add_element_from_file_with_format(deviceConfig, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\Device.txt",
                  Convert.ToString(device_attribute.DEVICE_ID),
                  Convert.ToString(device_attribute.DEVICE_NAME),
                  Convert.ToString(device_attribute.INTERFACE_COUNT),
                  Convert.ToString(pos_3d_attribute.X_OR_LON),
                  Convert.ToString(pos_3d_attribute.Y_OR_LAT));


            for (int i = 0; i < device_attribute.INTERFACE_COUNT; i++)
            {
                if (interface_variables[i].INTERFACE_TYPE.Equals("5G_XN"))
                {
                    if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\5G_XN\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].IP_ADDRESS),
                         Convert.ToString(args[1]),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS));
                    }
                    else if ((args[1] == "OPTION_7") || (args[1] == "OPTION_7a") || (args[1] == "OPTION_7x"))
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\5G_XN_OP7\\Interface.txt",
                        Convert.ToString(interface_variables[i].ID),
                        Convert.ToString(interface_variables[i].IP_ADDRESS),
                        Convert.ToString(args[1]),
                        Convert.ToString(interface_variables[i].MAC_ADDRESS));
                    }
                    else
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\5G_XN_OP\\Interface.txt",
                        Convert.ToString(interface_variables[i].ID),
                        Convert.ToString(interface_variables[i].IP_ADDRESS),
                        Convert.ToString(args[1]),
                        Convert.ToString(interface_variables[i].MAC_ADDRESS));
                    }

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("LTE"))
                {
                    if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\LTE\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS),
                         Convert.ToString(args[1]));
                    }
                    else
                    {
                        if (args[1] == "OPTION_4")
                        {
                            nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\LTE_OP\\Interface.txt",
                             Convert.ToString(interface_variables[i].ID),
                             Convert.ToString(interface_variables[i].MAC_ADDRESS),
                             Convert.ToString(args[1]));
                        }
                        
                        else
                        {
                            nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\LTE_OP4a\\Interface.txt",
                             Convert.ToString(interface_variables[i].ID),
                             Convert.ToString(interface_variables[i].MAC_ADDRESS),
                             Convert.ToString(args[1]));
                        }
                    }

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("LTE_S1"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\LTE_S1\\Interface.txt",
                         Convert.ToString(interface_variables[i].ID),
                         Convert.ToString(interface_variables[i].IP_ADDRESS),
                           Convert.ToString(args[1]),
                         Convert.ToString(interface_variables[i].MAC_ADDRESS));

                }
                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N3"))
                {
                    if ((args[1] == "OPTION_7") || (args[1] == "OPTION_7a") || (args[1] == "OPTION_7x"))
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\5G_N3OP7\\Interface.txt",
                        Convert.ToString(interface_variables[i].ID),
                        Convert.ToString(interface_variables[i].IP_ADDRESS),
                        Convert.ToString(interface_variables[i].SUBNET_MASK),
                        Convert.ToString(args[1]),
                        Convert.ToString(interface_variables[i].MAC_ADDRESS));
                    }
                    else
                    {
                        nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\5G_N3\\Interface.txt",
                             Convert.ToString(interface_variables[i].ID),
                             Convert.ToString(interface_variables[i].IP_ADDRESS),
                             Convert.ToString(interface_variables[i].SUBNET_MASK),
                             Convert.ToString(args[1]),
                             Convert.ToString(interface_variables[i].MAC_ADDRESS));
                    }
                }

                else if (interface_variables[i].INTERFACE_TYPE.Equals("5G_N1_N2"))
                {
                    nsWriter.add_element_from_file_with_format(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\5G_N1_N2\\Interface.txt",
                        Convert.ToString(interface_variables[i].ID),
                        Convert.ToString(interface_variables[i].IP_ADDRESS),
                        Convert.ToString(interface_variables[i].SUBNET_MASK),
                        Convert.ToString(interface_variables[i].MAC_ADDRESS));
                }


            }
            if (args[1] == "OPTION_4a")
            {
                nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\App_4a\\Application_Layer.txt");
            }
            else if((args[1] == "OPTION_7") || (args[1] == "OPTION_7a") || (args[1] == "OPTION_7x"))
            {
                nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\App_7\\Application_Layer.txt");

            }
            else
            {
                nsWriter.add_element_from_file(device, config_helper_location + "\\ConfigHelper\\NSA\\ENB\\Application_Layer.txt");
            }

        }


        /*
          func: adds all the devices as child node to DEVICE_CONFIGUARTION(parent node)
          params: parent:-reference to parent node(NETWORK_CONFIGURATION)
                  device_count :- number of devices to be added
                  device_container :- contains whole info for all the devices 
                  other_info :- extra info about wireless_sensor device
          return: doesnt return
        */
        public void add_deviceConfig(XmlNode parent, int device_count, DEVICE_CONTAINER[] device_container, string config_helper_location, string[] args,string[] gnb_ip_address)
        {
            XmlNode deviceConfig = nsWriter.add_element(parent, "DEVICE_CONFIGURATION");
            int deviceCount = device_count;
            nsWriter.add_attribute(deviceConfig, "DEVICE_COUNT", Convert.ToString(deviceCount));
            int count = Convert.ToInt32(args[4]);
         
            for (int i = 0; i < deviceCount; i++)
            {
                if (args[0] == "SA")
                {

                    if (device_container[i].device.DEVICE_TYPE.Equals("ROUTER"))
                        add_router(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("WIREDNODE"))
                        add_wired_node(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("LTE_NR_UE"))
                        add_UE(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("LTE_gNB"))
                        add_GNB(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("AMF"))
                        add_AMF(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args,gnb_ip_address);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("SMF"))
                        add_SMF(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("UPF"))
                        add_UPF(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args,gnb_ip_address);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("L2_Switch_UPF"))
                        add_L2_Switch_UPF(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("L2_Switch_AMF"))
                        add_L2_Switch_AMF(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("L2_Switch_gNB"))
                        add_L2_Switch_gNB(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                }
                else
                {

                    if (device_container[i].device.DEVICE_TYPE.Equals("ROUTER"))
                        add_router_NSA(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("WIREDNODE"))
                        add_wired_node_NSA(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("LTE_NR_UE"))
                        add_UE_NSA(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("LTE_gNB"))
                        add_GNB_NSA(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("AMF"))
                        add_AMF_NSA(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("SMF"))
                        add_SMF_NSA(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("UPF"))
                        add_UPF_NSA(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("L2_Switch_UPF"))
                        add_L2_Switch_UPF(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                    else if (device_container[i].device.DEVICE_TYPE.Equals("L2_Switch_AMF"))
                        add_L2_Switch_AMF(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);

                    else if (device_container[i].device.DEVICE_TYPE.Equals("LTE_EPC"))
                            add_EPC(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args);
                        else if (device_container[i].device.DEVICE_TYPE.Equals("L2_Switch_gNB"))
                            add_L2_Switch_NSA(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location);
                        else if (device_container[i].device.DEVICE_TYPE.Equals("LTE_eNB"))
                            add_LTE_eNB(deviceConfig, device_container[i].device, device_container[i].pos_3d, device_container[i]._interface, config_helper_location,args);

                }
            }

        }



        /*
          func: appends all the link info inside CONNECTION
          params: parent :- reference to parent node(NETWORK_CONFIGUARTION)
                  link_count :- number of links
                  link :- contains whole info about all the links 
          return: doesnt return
        */
        public void add_connection(XmlNode parent, int link_count, LINK[] link, string config_helper_location,string[] args)
        {
            XmlNode con = nsWriter.add_element(parent, "CONNECTION");
            for (int i = 0; i < link_count; i++)
            {
                XmlNode link_element; string folder_name;
                if (link[i].link_type.Equals("gNB_UE"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\Link\\GNB_UE\\Link.txt",
                     Convert.ToString(link[i].DEVICE_COUNT),
                     Convert.ToString(link[i].LINK_ID),
                     Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\GNB_UE\\Medium_Property.txt");
                    }
                    else
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\GNB_UE\\Medium_Property.txt");

                    }
                }
             
               
                //AMF_L2_Switch_5
                else if (link[i].link_type.Equals("AMF_L2_Switch"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\Link\\AMF_L2_Switch_5\\Link.txt",
                     Convert.ToString(link[i].DEVICE_COUNT),
                     Convert.ToString(link[i].LINK_ID),
                     Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\AMF_L2_Switch_5\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Link_Failure.txt");
                }
                //UPF_L2_Switch_4
                else if (link[i].link_type.Equals("UPF_L2_Switch"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\Link\\UPF_L2_Switch_4\\Link.txt",
                     Convert.ToString(link[i].DEVICE_COUNT),
                     Convert.ToString(link[i].LINK_ID),
                     Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\UPF_L2_Switch_4\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Link_Failure.txt");
                }

                //UPF_Router
                else if (link[i].link_type.Equals("UPF_Router"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\Link\\UPF_Router\\Link.txt",
                     Convert.ToString(link[i].DEVICE_COUNT),
                     Convert.ToString(link[i].LINK_ID),
                     Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\UPF_Router\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Link_Failure.txt");

                }
                //GNB_L2_Switch_6
                else if (link[i].link_type.Equals("GNB_L2_Switch"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\Link\\GNB_L2_Switch_6\\Link.txt",
                     Convert.ToString(link[i].DEVICE_COUNT),
                     Convert.ToString(link[i].LINK_ID),
                     Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\GNB_L2_Switch_6\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Link_Failure.txt");
                }
                //ENB_L2_Switch
                else if (link[i].link_type.Equals("ENB_L2_Switch"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\Link\\ENB_L2_Switch_6\\Link.txt",
                     Convert.ToString(link[i].DEVICE_COUNT),
                     Convert.ToString(link[i].LINK_ID),
                     Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\ENB_L2_Switch_6\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Link_Failure.txt");
                }
                //SMF_AMF
                else if (link[i].link_type.Equals("SMF_AMF"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\Link\\SMF_2_AMF_3\\Link.txt",
                     Convert.ToString(link[i].DEVICE_COUNT),
                     Convert.ToString(link[i].LINK_ID),
                     Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\SMF_2_AMF_3\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Link_Failure.txt");
                }
                //SMF_2_UPF_1
                else if (link[i].link_type.Equals("SMF_UPF"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\Link\\SMF_2_UPF_1\\Link.txt",
                     Convert.ToString(link[i].DEVICE_COUNT),
                     Convert.ToString(link[i].LINK_ID),
                     Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\SMF_2_UPF_1\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Link_Failure.txt");
                }


                else if (link[i].link_type.Equals("Wired_Router"))
                { 
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\Link\\Wired_Router\\Link.txt",
                    Convert.ToString(link[i].DEVICE_COUNT),
                    Convert.ToString(link[i].LINK_ID),
                    Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Wired_Router\\Medium_Property.txt");
                    //nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\Link\\Link_Failure.txt");
                }
                //enb_UE
                else if (link[i].link_type.Equals("eNB_UE"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\NSA\\Link\\eNB_UE\\Link.txt",
                     Convert.ToString(link[i].DEVICE_COUNT),
                     Convert.ToString(link[i].LINK_ID),
                     Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\eNB_UE\\Medium_Property.txt");
                }
                //eNB with EPC
                else if (link[i].link_type.Equals("eNB_EPC"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\NSA\\Link\\eNB_EPC\\Link.txt",
                    Convert.ToString(link[i].DEVICE_COUNT),
                    Convert.ToString(link[i].LINK_ID),
                    Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\eNB_EPC\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Link_Failure.txt");
                }
                //
                else if (link[i].link_type.Equals("EPC_Router_Router"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\NSA\\Link\\EPC_Router_Router\\Link.txt",
                    Convert.ToString(link[i].DEVICE_COUNT),
                    Convert.ToString(link[i].LINK_ID),
                    Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\EPC_Router_Router\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Link_Failure.txt");

                }
                //
                else if (link[i].link_type.Equals("L2_Swtich_gNB"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\NSA\\Link\\L2_Swtich_gNB\\Link.txt",
                    Convert.ToString(link[i].DEVICE_COUNT),
                    Convert.ToString(link[i].LINK_ID),
                    Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\L2_Swtich_gNB\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Link_Failure.txt");

                }
                //
                else if (link[i].link_type.Equals("L2_Swtich_eNB"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\NSA\\Link\\L2_Swtich_eNB\\Link.txt",
                    Convert.ToString(link[i].DEVICE_COUNT),
                    Convert.ToString(link[i].LINK_ID),
                    Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\L2_Swtich_eNB\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Link_Failure.txt");

                }
                //
                else if (link[i].link_type.Equals("gNB_EPC"))
                {
                    link_element = nsWriter.add_element_from_file_with_format(con, config_helper_location + "\\ConfigHelper\\NSA\\Link\\gNB_EPC\\Link.txt",
                    Convert.ToString(link[i].DEVICE_COUNT),
                    Convert.ToString(link[i].LINK_ID),
                    Convert.ToString(link[i].LINK_NAME));
                    for (int j = 0; j < link[i].DEVICE_COUNT; j++)
                    {
                        nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Device.txt",
                        Convert.ToString(link[i].link_device[j].DEVICE_ID),
                        Convert.ToString(link[i].link_device[j].INTERFACE_ID),
                        Convert.ToString(link[i].link_device[j].NAME));
                    }
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\gNB_EPC\\Medium_Property.txt");
                    nsWriter.add_element_from_file_with_format(link_element, config_helper_location + "\\ConfigHelper\\NSA\\Link\\Link_Failure.txt");
                }

            }
        }

        /*
          func: adds all the Applications in NETWORK_CONFIGUARTION(parent node)
          params: parent :- reference to parent node(NETWORK_CONFIGUARTION)
                  application_count :- number of applications
                  application :- container of all whole info about all the application
          return: doesnt return
        */
        public void add_application(XmlNode parent, int application_count, APPLICATION[] application, string config_helper_location)
        {
            XmlNode app = nsWriter.add_element(parent, "APPLICATION_CONFIGURATION");
            nsWriter.add_attribute(app, "COUNT", Convert.ToString(application_count));
            for (int i = 0; i < application_count; i++)
            {
                nsWriter.add_element_from_file_with_format(app, config_helper_location + "\\ConfigHelper\\Application.txt",
                    Convert.ToString(application[i].DESTINATION_ID),
                    Convert.ToString(application[i].ID),
                    Convert.ToString(application[i].NAME),
                    Convert.ToString(application[i].SOURCE_ID));
            }
        }

        /*
          func: append all the child nodes of NETWORK_CONFIGURATION
          params: parent :- reference to parent node(TETCOS_NETSIM)
                  device count:-  number of devices
                  link_count:- number of links
                  application_count:- number of applications
                  device_containe:- container containing whole info of all the devices
                  link:- container contaning whole info of all the links
                  application :- container of all whole info about all the application
                  other_info:- extra info about the wireless_sensor device
          return: doesn't return
        */
        public void add_network(XmlNode parent, int device_count, int link_count, int application_count, DEVICE_CONTAINER[] device_container, LINK[] link, APPLICATION[] application, string config_helper_location, string[] args,string[] gnb_ip_address)
        {
            XmlNode nwConfig = nsWriter.add_element(parent, "NETWORK_CONFIGURATION");
            add_deviceConfig(nwConfig, device_count, device_container, config_helper_location, args,gnb_ip_address);
            add_connection(nwConfig, link_count, link, config_helper_location,args);
            add_application(nwConfig, application_count, application, config_helper_location);
        }
    }
}
