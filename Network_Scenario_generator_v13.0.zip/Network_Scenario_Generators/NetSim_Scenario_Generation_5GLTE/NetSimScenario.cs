﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;

namespace NetSim_Scenario_Generation_5GLTE
{
    /*  structure to store the attributes of APPLICATION node  */
    public struct APPLICATION
    {
        public int DESTINATION_ID;
        public int ID;
        public string NAME;
        public int SOURCE_ID;
    }

    
    /*  structure to store the Postion of a DEVICE*/
    public struct POS_3D
    {
        public double X_OR_LON;
        public double Y_OR_LAT;
        public double Z;
    }

    /*structure for containing DEVICE INFO of a LINK*/
    public struct LINK_DEVICE
    {
        public int DEVICE_ID;
        public int INTERFACE_ID;
        public string NAME;
    }

    /*  structure for containing attributes of a link  along with DEVICE INFO of the link */
    public struct LINK
    {
        public int DEVICE_COUNT;
        public int LINK_ID;
        public string LINK_NAME;
        public string link_type;
        public LINK_DEVICE[] link_device;
    }

    /* structure which stores information regarding position from centre of the grid */
    public struct LEVEL
    {
        public double r;
        public double theta;
        public int level;
        public double low_angle;
        public double increment;

    }

    /*  structure to store the attributes of a DEVICE */
    public struct DEVICE
    {
        public string DEFAULT_DEVICE_NAME;
        public int DEVICE_ID;
        public string DEVICE_IMAGE;
        public string DEVICE_NAME;
        public string DEVICE_TYPE;
        public int INTERFACE_COUNT;
        public string TYPE;
        public string WIRESHARK_OPTION;
    }

    /*  structure to store the attributes of an Interface of a DEVICE  */
    public struct INTERFACE
    {
        public int ID;
        public string DEFAULT_GATEWAY;
        public string IP_ADDRESS;
        public string SUBNET_MASK;
        public string MAC_ADDRESS;
        public string CONNECTED_TO;
        public string INTERFACE_TYPE;
        public string IMEI_NUMBER;
        public string MOBILE_NUMBER;
    }

    /*  structure to store attributes,position,level and interfaces of a DEVICE */
    public struct DEVICE_CONTAINER
    {
        public DEVICE device;
        public POS_3D pos_3d;
        public LEVEL level;
        public INTERFACE[] _interface;
    }

    class Program
    {
        public static XmlWriter nsWriter;
        public static AddNetworkElement addNet;
        static void Main(string[] args)
        {
            string mode;//NSA or SA mode
            string option;
            int max_router;
            int max_node;
            int max_gnb;
            int max_ue;

            int max_application;
            string config_helper_location;
            string exp_name;
            string version_name;

            float simulation_time;

            string application_from_file = "";

            if (args.Length == 11)
            {
                mode = args[0];
                option = args[1];
                max_router = Int32.Parse(args[2]);//string mode add above and add string option 
                max_node = Int32.Parse(args[3]);
                max_gnb = Int32.Parse(args[4]);
                max_ue = Int32.Parse(args[5]);
                // max_5G_core = Int32.Parse(args[4]);//fix it and remove from arg
                max_application = Int32.Parse(args[6]);
                config_helper_location = args[7];
                exp_name = args[8];
                version_name = args[9];//please don't forget to add version number in the code 

                simulation_time = float.Parse(args[10]);
            }
            else
            {
                Console.WriteLine("Incorrect!! Required 11 arguments\n");
                return;
            }

            Console.WriteLine(mode);
            Console.WriteLine(option);
            Console.WriteLine(max_router);
            Console.WriteLine(max_node);
            Console.WriteLine(max_gnb);
            Console.WriteLine(max_ue);


            Console.WriteLine(max_application);
            Console.WriteLine(config_helper_location);
            Console.WriteLine(exp_name);                /*test_case name*/
            Console.WriteLine(version_name);            /* version_name and version_number taken from netsim_path_location\Docs\GUI\NSF-utility.txt */

            Console.WriteLine(simulation_time);         /* Browser input 0.001 to 1,00,000 */

            if (max_application > max_node * max_ue)
            {
                Console.WriteLine("Max application cannot be greater than (max_node * max_ue)");
                return;
            }


            /********************************************************************************************/
            // these parameters are to be decided by user
            // string mode = SA or NSA;
            // String option = Optio_3 or 3x;//only for NSA mode
            //int max_router = 20;          //(between 1-25000)
            //int max_node = 40;            //max 4*(max_router - 1)
            //int max_gnb = 5;             //(between 1-98)
            //int max_ue = 20;              //(between 1-10000 and multiple of max_gnb)
            //int max_5G_core = 1;          //(fixed to 1 only dont change)
            //int max_application = 2;      //(between 1- max_node * max_ue)
            //string application_from_file = "ConfigHelper\\Application_Config.txt"; //(give the file name along with path from which application has to be created or leave it as it is if you randomly want to create the application)
            /********************************************************************************************/


            /********************************************************************************************/
            //mac address of devices,mbile number and ime1 number of ue ,other variables
            string mac = "123456789ABC";
            string mobile_number = "1123456789";
            string ime1_number = "112233445566789";
            int i, j, ipv4_count = 0, mobile_number_count = 0, ime1_number_count = 0, link_count = 0, application_count = 0;
            /********************************************************************************************/


            /********************************************************************************************/
            //fixed router info 
            int max_5G_core_devices = 6;
            int max_router_interface = 6;
            int max_AMF_interface = 2;
            int max_SMF_interface = 2;
            int max_UPF_interface = max_router + 2;
            int max_SMF = 1;
            int max_AMF = 1;
            int max_UPF = 1;
            int max_L2_Switch_5 = 1;
            int max_L2_Switch_4 = 1;
            int max_L2_Switch_6 = 1;
            int max_hop = 6;
            int SA_router_id_1;
           // int NSA_router_id_1;
            int SA_wired_id;
            int NSA_wired_id;
            int SA_gnb_idd = max_5G_core_devices + 1;//first gNB_id
         
            int k;
            int gNB_ue;
            double low_angle;
            int ue;// = max_ue;
            int link_device_count;
            double theta0;
            double level0;
            double increment0;
            double NSA_theta0_3;
            double NSA_level0_3;
            double NSA_increment0_3;
            int ki;
            int branch = max_router_interface - 1;
            int height = (int)Math.Ceiling(Math.Log(max_router * (branch - 1) * 1.0 + 1.0, branch * 1.0)) - 1;
            int not_leaf_node = ((int)Math.Pow(branch, height) - 1) / (branch - 1);
            double router_x0 = 700.0, router_y0 = 700.0, offset_radius = 60.0;

            //parameter for NSA mode
            int max_epc = 1;
            int L2_Switch = 1;
            int max_eNB = max_gnb;
            int max__epc_interface = max_eNB + max_gnb + max_router + 1;
            int max_L2_Swtich_interface_NSA = max_eNB + max_gnb;
            //int max_L2_Swtich_interface = max_eNB + max_gnb;
            double epc_x0 = 500.0, epc_y0 = 100.0;
            /********************************************************************************************/

            /********************************************************************************************/
            //fixed epc , gnb  && ue info
            //int max__epc_interface = max_gnb + 1;
            // double epc_x0 = 200.0, epc_y0 = 200.0;

            double SMF_x0 = 500.0, SMF_y0 = 100.0;
            double AMF_x0 = 400.0, AMF_y0 = 200.0;
            double UPF_x0 = 600.0, UPF_y0 = 200.0;
            double L2_Switch_5_x0 = 400.0, L2_Switch_5_y0 = 300.0;
            double L2_Switch_4_x0 = 600.0, L2_Switch_4_y0 = 320.0;
            double L2_Switch_6_x0 = 500.0, L2_Switch_6_y0 = 400.0;
           // double epc_x0 = 500.0, epc_y0 = 100.0;
            double gnbNSA_x0 = 700.0, gnbNSA_y0 = 300.0;
            double L2_Switch_x0 = 500, L2_Switch_y0 = 300;
            double enb_x0 = 300.0, enb_y0 = 300.0;
            double gnb_x0 = 200.0, gnb_y0 = 200.0;
            double gnbSA_x0 = 200.0, gnbSA_y0 = 200.0;
            double gnb_radius = 60.0;
            double gnb_radiusSA = 10.0;
            double gnb_angle_increment = 360.0 / max_gnb;
            double ue_angle_increment = 360.0 / max_ue;
            double ue_radius = 100.0;
            int num_ue_per_gnb = (max_ue / max_gnb);
            int count_check = 0;
            int max_node_temp_3x;
            int octate_4 = 0;
            int num_ue_per_enb_NSA = (max_ue / max_eNB);
            int num_ue_per_gnb_NSA = (max_ue / max_gnb);
            /********************************************************************************************/


            /********************************************************************************************/
            //intermediate parameters used in generating scenario


            int total_device_SA = max_router + max_node + max_gnb + max_ue + max_5G_core_devices;
            int total_device_NSA = max_router + max_node + max_gnb + max_ue + max_epc + max_eNB + L2_Switch;
            int total_device_NSA_4 = max_router + max_node + max_gnb+ max_eNB + max_ue + max_5G_core_devices;
            int total_UE_check_4 = max_gnb + max_eNB + max_ue + max_5G_core_devices;
            int max_link = max_router + max_node + max_gnb + max_ue + max_5G_core_devices + 100;
            int NSA_router_id_1 = max_epc + max_eNB + L2_Switch + max_gnb;
            int NSA_gnb_idd = max_epc + max_eNB + L2_Switch;
            int NSA_gnb_idd_4x;
            int NSA_enb_idd_7;
            int L2_switch_4_last_interface = 0;
            int L2_switch_5_last_interface = 0;
            int L2_switch_6_last_interface = 0;
           
            
            Random rnd = new Random();
            int max_switch_interface = max_gnb + 1;
            int max_switch_interface_4a = max_gnb + max_eNB + 1;
            nsWriter = new XmlWriter();
            addNet = new AddNetworkElement();
            XmlNode root = nsWriter.open_document();
            /********************************************************************************************/

            /********************************************************************************************/
            //application for containing detailes of applications
            APPLICATION[] application = new APPLICATION[max_application];

            //device_container for SA mode to store varible for each device
            DEVICE_CONTAINER[] device_container_SA = new DEVICE_CONTAINER[total_device_SA];

            //device_container for NSA mode to store varible for each device
            DEVICE_CONTAINER[] device_container_NSA = new DEVICE_CONTAINER[total_device_NSA];

            string[] gnb_ip_address = new string[max_gnb];

             //link for storing details of all the links
             LINK[] link = new LINK[max_link];
            /********************************************************************************************/

            /********************************************************************************************/


            if (args[0] == "SA")
            {

                //Add First UPF
                device_container_SA[0].device.DEVICE_ID = 1;
                device_container_SA[0].device.DEVICE_NAME = "UPF_" + Convert.ToString(1);
                device_container_SA[0].device.DEVICE_TYPE = "UPF";
                device_container_SA[0].device.INTERFACE_COUNT = max_UPF_interface;

                device_container_SA[0].pos_3d.X_OR_LON = UPF_x0;
                device_container_SA[0].pos_3d.Y_OR_LAT = UPF_y0;

                device_container_SA[0]._interface = new INTERFACE[max_UPF_interface];

                //interface UPF with SMF
                device_container_SA[0]._interface[0].ID = 1;
                mac = addNet.next_mac(mac);
                device_container_SA[0]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[0]._interface[0].INTERFACE_TYPE = "5G_N4";


                //interface UPF with L2_Switch_4
                device_container_SA[0]._interface[1].ID = 2;
                mac = addNet.next_mac(mac);
                device_container_SA[0]._interface[1].MAC_ADDRESS = mac;
                device_container_SA[0]._interface[1].INTERFACE_TYPE = "5G_N3";

                //interface UPF with router
                device_container_SA[0]._interface[2].ID = 3;
                mac = addNet.next_mac(mac);
                device_container_SA[0]._interface[2].MAC_ADDRESS = mac;
                device_container_SA[0]._interface[2].INTERFACE_TYPE = "5G_N6";


                //Add First SMF
                device_container_SA[1].pos_3d.X_OR_LON = SMF_x0;
                device_container_SA[1].pos_3d.Y_OR_LAT = SMF_y0;
                device_container_SA[1].device.DEVICE_ID = 2;
                device_container_SA[1].device.DEVICE_NAME = "SMF_" + Convert.ToString(2);
                device_container_SA[1].device.DEVICE_TYPE = "SMF";
                device_container_SA[1].device.INTERFACE_COUNT = 2;
                device_container_SA[1]._interface = new INTERFACE[max_SMF_interface];

                //interface SMF with AMF
                device_container_SA[1]._interface[0].ID = 1;
                mac = addNet.next_mac(mac);
                device_container_SA[1]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[1]._interface[0].INTERFACE_TYPE = "5G_N11";
                device_container_SA[1]._interface[0].CONNECTED_TO = "AMF_" + Convert.ToString(3);

                //interface SMF with UPF
                device_container_SA[1]._interface[1].ID = 2;
                mac = addNet.next_mac(mac);
                device_container_SA[1]._interface[1].MAC_ADDRESS = mac;
                device_container_SA[1]._interface[1].INTERFACE_TYPE = "5G_N4";
                device_container_SA[1]._interface[1].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                //Add First AMF
                device_container_SA[2].device.DEVICE_ID = 3;
                device_container_SA[2].device.DEVICE_NAME = "AMF_" + Convert.ToString(3);
                device_container_SA[2].device.DEVICE_TYPE = "AMF";
                device_container_SA[2].device.INTERFACE_COUNT = 2;

                device_container_SA[2].pos_3d.X_OR_LON = AMF_x0;
                device_container_SA[2].pos_3d.Y_OR_LAT = AMF_y0;
                device_container_SA[2]._interface = new INTERFACE[max_AMF_interface];

                //interface to AMF with SMF
                device_container_SA[2]._interface[0].ID = 1;
                mac = addNet.next_mac(mac);
                device_container_SA[2]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[2]._interface[0].INTERFACE_TYPE = "5G_N11";
                device_container_SA[2]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);

                //interface AMF with L2_Switch_5 
                device_container_SA[2]._interface[1].ID = 2;
                mac = addNet.next_mac(mac);
                device_container_SA[2]._interface[1].MAC_ADDRESS = mac;
                device_container_SA[2]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                device_container_SA[2]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);

                //Add First L2_Switch_4
                device_container_SA[3].device.DEVICE_ID = 4;
                device_container_SA[3].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(4);
                device_container_SA[3].device.DEVICE_TYPE = "L2_Switch_UPF";
                device_container_SA[3].device.INTERFACE_COUNT = max_gnb + 1;


                device_container_SA[3].pos_3d.X_OR_LON = L2_Switch_4_x0;
                device_container_SA[3].pos_3d.Y_OR_LAT = L2_Switch_4_y0;

                device_container_SA[3]._interface = new INTERFACE[max_switch_interface];

                device_container_SA[3]._interface[0].ID = 1;
                device_container_SA[3]._interface[0].DEFAULT_GATEWAY = "";
                device_container_SA[3]._interface[0].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                device_container_SA[3]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[3]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[3]._interface[0].INTERFACE_TYPE = "ETHERNET";
                device_container_SA[3]._interface[0].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                //Add First L2_Switch_5
                device_container_SA[4].device.DEVICE_ID = 5;
                device_container_SA[4].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(5);
                device_container_SA[4].device.DEVICE_TYPE = "L2_Switch_AMF";
                device_container_SA[4].device.INTERFACE_COUNT = max_gnb + 1;
                device_container_SA[4].pos_3d.X_OR_LON = L2_Switch_5_x0;
                device_container_SA[4].pos_3d.Y_OR_LAT = L2_Switch_5_y0;
                device_container_SA[4]._interface = new INTERFACE[max_switch_interface];

                //Add First L2_Switch_6
                device_container_SA[5].device.DEVICE_ID = 6;
                device_container_SA[5].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(6);
                device_container_SA[5].device.DEVICE_TYPE = "L2_Switch_gNB";
                device_container_SA[5].device.INTERFACE_COUNT = max_gnb;
                device_container_SA[5].pos_3d.X_OR_LON = L2_Switch_6_x0;
                device_container_SA[5].pos_3d.Y_OR_LAT = L2_Switch_6_y0;
                device_container_SA[5]._interface = new INTERFACE[max_gnb];
                //SMF Connection

                //SMF with AMF
                link[link_count].DEVICE_COUNT = 2;
                link[link_count].LINK_ID = link_count + 1;
                link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                link[link_count].link_type = "SMF_AMF";
                link[link_count].link_device = new LINK_DEVICE[2];
                link[link_count].link_device[0].DEVICE_ID = 2;
                link[link_count].link_device[0].NAME = "SMF_" + Convert.ToString(2);
                link[link_count].link_device[0].INTERFACE_ID = 1;

                link[link_count].link_device[1].DEVICE_ID = 3;
                link[link_count].link_device[1].NAME = "AMF_" + Convert.ToString(3);
                link[link_count].link_device[1].INTERFACE_ID = 1;
                link_count++;

                //SMF with UPF
                link[link_count].DEVICE_COUNT = 2;
                link[link_count].LINK_ID = link_count + 1;
                link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                link[link_count].link_type = "SMF_UPF";
                link[link_count].link_device = new LINK_DEVICE[2];
                link[link_count].link_device[1].DEVICE_ID = 2;
                link[link_count].link_device[1].NAME = "SMF_" + Convert.ToString(2);
                link[link_count].link_device[1].INTERFACE_ID = 2;

                link[link_count].link_device[0].DEVICE_ID = 1;
                link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                link[link_count].link_device[0].INTERFACE_ID = 1;
                link_count++;

                //Connection UPF with L2_Switch_4
                link[link_count].DEVICE_COUNT = 2;
                link[link_count].LINK_ID = link_count + 1;
                link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                link[link_count].link_type = "UPF_L2_Switch";
                link[link_count].link_device = new LINK_DEVICE[2];
                link[link_count].link_device[0].DEVICE_ID = 1;
                link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                link[link_count].link_device[0].INTERFACE_ID = 2;

                link[link_count].link_device[1].DEVICE_ID = 4;
                link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(4);
                link[link_count].link_device[1].INTERFACE_ID = 1;
                link_count++;

                //Connection AMF with L2_Switch_5
                link[link_count].DEVICE_COUNT = 2;
                link[link_count].LINK_ID = link_count + 1;
                link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                link[link_count].link_type = "AMF_L2_Switch";
                link[link_count].link_device = new LINK_DEVICE[2];
                link[link_count].link_device[0].DEVICE_ID = 3;
                link[link_count].link_device[0].NAME = "AMF_" + Convert.ToString(3);
                link[link_count].link_device[0].INTERFACE_ID = 2;


                link[link_count].link_device[1].DEVICE_ID = 5;
                link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(5);
                link[link_count].link_device[1].INTERFACE_ID = 1;
                link_count++;


                //this block set the  attributes,positions of all L2_Switch with gNB


                int upf_last_interface = 0, smf_last_interface = 0, amf_last_interface = 0;//AMF,SMF,UPF,L2Switch.
                int L2_switch_link = 2,L2_switch_link_6=1;
                for (i = 0; i < (max_gnb); i++)
                {
                    //L2_Switch_5 connected with gNB
                    device_container_SA[4]._interface[upf_last_interface + 1].ID = upf_last_interface + 2;
                    device_container_SA[4]._interface[upf_last_interface + 1].DEFAULT_GATEWAY = "";
                    device_container_SA[4]._interface[upf_last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                    string ip = addNet.next_ip(++ipv4_count, 1);
                    device_container_SA[4]._interface[upf_last_interface + 1].IP_ADDRESS = ip;
                    mac = addNet.next_mac(mac);
                    device_container_SA[4]._interface[upf_last_interface + 1].MAC_ADDRESS = mac;
                    device_container_SA[4]._interface[upf_last_interface + 1].CONNECTED_TO = "gNB_" + Convert.ToString(SA_gnb_idd);
                    device_container_SA[4]._interface[upf_last_interface + 1].INTERFACE_TYPE = "ETHERNET";

                    //L2_Switch_6 connrcted with gNB
                    device_container_SA[5]._interface[upf_last_interface].ID = upf_last_interface + 1;
                    device_container_SA[5]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                    device_container_SA[5]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                    ip = addNet.next_ip(++ipv4_count, 1);
                    device_container_SA[5]._interface[upf_last_interface].IP_ADDRESS = ip;
                    mac = addNet.next_mac(mac);
                    device_container_SA[5]._interface[upf_last_interface].MAC_ADDRESS = mac;
                    device_container_SA[5]._interface[upf_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(SA_gnb_idd);
                    device_container_SA[5]._interface[upf_last_interface].INTERFACE_TYPE = "ETHERNET";

                    //L2_Switch_4 connected with gNB
                    device_container_SA[3]._interface[upf_last_interface + 1].ID = upf_last_interface + 2;
                    device_container_SA[3]._interface[upf_last_interface + 1].DEFAULT_GATEWAY = "";
                    device_container_SA[3]._interface[upf_last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                    ip = addNet.next_ip(++ipv4_count, 1);
                    device_container_SA[3]._interface[upf_last_interface + 1].IP_ADDRESS = ip;
                    mac = addNet.next_mac(mac);
                    device_container_SA[3]._interface[upf_last_interface + 1].MAC_ADDRESS = mac;
                    device_container_SA[3]._interface[upf_last_interface + 1].CONNECTED_TO = "gNB_" + Convert.ToString(SA_gnb_idd);
                    device_container_SA[3]._interface[upf_last_interface + 1].INTERFACE_TYPE = "ETHERNET";


                    //L2_switch link_4 connection with gNB
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "GNB_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 4;
                    link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(4);
                    link[link_count].link_device[0].INTERFACE_ID = L2_switch_link; //
                    link[link_count].link_device[1].DEVICE_ID = SA_gnb_idd;
                    link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(SA_gnb_idd);
                    link[link_count].link_device[1].INTERFACE_ID = 1;//
                    link_count++;

                    //L2_switch link_5 connection with gNB

                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "GNB_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];

                    link[link_count].link_device[0].DEVICE_ID = 5;
                    link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(5);
                    link[link_count].link_device[0].INTERFACE_ID = L2_switch_link;//

                    link[link_count].link_device[1].DEVICE_ID = SA_gnb_idd;
                    link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(SA_gnb_idd);
                    link[link_count].link_device[1].INTERFACE_ID = 2;//
                    link_count++;

                    //L2_switch_6 link connection with gNB
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "GNB_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];

                    link[link_count].link_device[0].DEVICE_ID = 6;
                    link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(6);
                    link[link_count].link_device[0].INTERFACE_ID = L2_switch_link_6;//

                    link[link_count].link_device[1].DEVICE_ID = SA_gnb_idd;
                    link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(SA_gnb_idd);
                    link[link_count].link_device[1].INTERFACE_ID = 3;//
                    link_count++;
                    upf_last_interface++;
                    L2_switch_link++;
                    L2_switch_link_6++;
                    SA_gnb_idd++;
                    count_check++;

                }
                // this block initialises set of independed attributtes of router and wirednode

                SA_router_id_1 = SA_gnb_idd;//first router id
                for (i = 0; i < max_router; i++)
                {

                    device_container_SA[SA_router_id_1 - 1].device.DEVICE_ID = SA_router_id_1;
                    device_container_SA[SA_router_id_1 - 1].device.DEVICE_NAME = "Router_" + Convert.ToString(SA_router_id_1);
                    device_container_SA[SA_router_id_1 - 1].device.DEVICE_TYPE = "ROUTER";
                    device_container_SA[SA_router_id_1 - 1].device.INTERFACE_COUNT = 0;
                    device_container_SA[SA_router_id_1 - 1].device.WIRESHARK_OPTION = "Disable";

                    device_container_SA[SA_router_id_1 - 1]._interface = new INTERFACE[max_router_interface];
                    SA_router_id_1++;

                }
                SA_wired_id = SA_router_id_1;
                for (; i < (max_router + max_node); i++)
                {
                    device_container_SA[SA_wired_id - 1].device.DEVICE_ID = SA_wired_id;
                    device_container_SA[SA_wired_id - 1].device.DEVICE_NAME = "Wired_Node_" + Convert.ToString(SA_wired_id);
                    device_container_SA[SA_wired_id - 1].device.DEVICE_TYPE = "WIREDNODE";
                    device_container_SA[SA_wired_id - 1].device.INTERFACE_COUNT = 0;
                    device_container_SA[SA_wired_id - 1].device.WIRESHARK_OPTION = "Disable";
                    device_container_SA[SA_wired_id - 1]._interface = new INTERFACE[1];
                    SA_wired_id++;

                }

                k = 1;
                gNB_ue = max_5G_core_devices;
                low_angle = 0;
                ue = max_ue;
                link_device_count = 0;
                int SA_octat_4th = 9;

                // this block sets the attributes,positions of all the gnb and ue
                for (i = 0; i < (max_gnb); i++)
                {

                    //upf_last_interface = device_container[total_device - 7].device.INTERFACE_COUNT;

                    ue--;
                    ipv4_count = 0;
                    device_container_SA[gNB_ue].device.DEVICE_ID = max_5G_core_devices + i + 1;
                    device_container_SA[gNB_ue].device.DEVICE_NAME = "gNB_" + Convert.ToString(max_5G_core_devices + i + 1);
                    device_container_SA[gNB_ue].device.DEVICE_TYPE = "LTE_gNB";
                    device_container_SA[gNB_ue].device.INTERFACE_COUNT = 4;
                    device_container_SA[gNB_ue]._interface = new INTERFACE[4];

                    device_container_SA[gNB_ue]._interface[0].ID = 1;
                    device_container_SA[gNB_ue]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, SA_octat_4th);
                    gnb_ip_address[i] = Convert.ToString(addNet.next_ip_1(ipv4_count, SA_octat_4th));

                    mac = addNet.next_mac(mac);
                    device_container_SA[gNB_ue]._interface[0].MAC_ADDRESS = mac;
                    device_container_SA[gNB_ue]._interface[0].INTERFACE_TYPE = "5G_N3";
                    device_container_SA[gNB_ue]._interface[0].CONNECTED_TO = "L2_Switch_" + Convert.ToString(4);
                    SA_octat_4th = SA_octat_4th + 2;

                    device_container_SA[gNB_ue]._interface[1].ID = 2;
                    device_container_SA[gNB_ue]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, SA_octat_4th);
                    mac = addNet.next_mac(mac);
                    device_container_SA[gNB_ue]._interface[1].MAC_ADDRESS = mac;
                    device_container_SA[gNB_ue]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                    device_container_SA[gNB_ue]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);

                    SA_octat_4th = SA_octat_4th + 2;
                    device_container_SA[gNB_ue]._interface[2].ID = 3;
                    device_container_SA[gNB_ue]._interface[2].IP_ADDRESS = addNet.next_ip_1(ipv4_count, SA_octat_4th);
                    mac = addNet.next_mac(mac);
                    device_container_SA[gNB_ue]._interface[2].MAC_ADDRESS = mac;
                    device_container_SA[gNB_ue]._interface[2].INTERFACE_TYPE = "5G_XN";
                    device_container_SA[gNB_ue]._interface[2].CONNECTED_TO = "L2_Switch_" + Convert.ToString(6);


                    device_container_SA[gNB_ue]._interface[3].ID = 4;
                    mac = addNet.next_mac(mac);
                    device_container_SA[gNB_ue]._interface[3].MAC_ADDRESS = mac;
                    device_container_SA[gNB_ue]._interface[3].INTERFACE_TYPE = "5G_RAN";
                    //device_container_SA[gNB_ue]._interface[3].CONNECTED_TO = "gNB_" + Convert.ToString(ue);

         
                    double theta = i * gnb_angle_increment;
                    device_container_SA[gNB_ue].pos_3d.X_OR_LON = gnbSA_x0 + gnb_radiusSA * Math.Cos(Math.PI * (theta / 180.0));
                    device_container_SA[gNB_ue].pos_3d.Y_OR_LAT = gnbSA_y0 + gnb_radiusSA * Math.Sin(Math.PI * (theta / 180.0));
                    low_angle = theta - (num_ue_per_gnb * ue_angle_increment / 2.0);


                    link_device_count = link[link_count].DEVICE_COUNT = 0;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "gNB_UE";
                    link[link_count].link_device = new LINK_DEVICE[num_ue_per_gnb + 1];
                    link[link_count].link_device[link_device_count].DEVICE_ID = max_5G_core_devices + i + 1;
                    link[link_count].link_device[link_device_count].NAME = "gNB_" + Convert.ToString(max_5G_core_devices + i + 1);
                    link[link_count].link_device[link_device_count].INTERFACE_ID = 4;
                    link_device_count++;
                    gNB_ue++;
                    SA_octat_4th = SA_octat_4th + 2;


                    for (int l = 0; l < num_ue_per_gnb; l++)
                    {
                        int ue_id = k + max_router + max_node + max_gnb + max_5G_core_devices;
                        if (ue_id - 1 >= total_device_SA)
                            break;

                        device_container_SA[ue_id - 1].device.DEVICE_ID = ue_id;
                        device_container_SA[ue_id - 1].device.DEVICE_NAME = "UE_" + Convert.ToString(ue_id);
                        device_container_SA[ue_id - 1].device.DEVICE_TYPE = "LTE_NR_UE";
                        device_container_SA[ue_id - 1].device.INTERFACE_COUNT = 0;
                        device_container_SA[ue_id - 1].device.WIRESHARK_OPTION = "Disable";
                        device_container_SA[ue_id - 1]._interface = new INTERFACE[1];

                        double theta1 = low_angle + l * ue_angle_increment;
                        device_container_SA[ue_id - 1].pos_3d.X_OR_LON = gnbSA_x0 + ue_radius * Math.Cos(Math.PI * (theta1 / 180.0));
                        device_container_SA[ue_id - 1].pos_3d.Y_OR_LAT = gnbSA_y0 + ue_radius * Math.Sin(Math.PI * (theta1 / 180.0));

                        int last_interface = device_container_SA[ue_id - 1].device.INTERFACE_COUNT;
                        device_container_SA[ue_id - 1]._interface[last_interface].ID = last_interface + 1;
                        string ip = addNet.next_ip_1(++ipv4_count, 1);
                        device_container_SA[ue_id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                        device_container_SA[ue_id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, l + 2);
                        device_container_SA[ue_id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_SA[ue_id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                        device_container_SA[ue_id - 1]._interface[last_interface].CONNECTED_TO = "";
                        ime1_number = addNet.next_ime1_number(ime1_number);
                        device_container_SA[ue_id - 1]._interface[last_interface].IMEI_NUMBER = ime1_number;
                        mobile_number = addNet.next_mobile_number(mobile_number);
                        device_container_SA[ue_id - 1]._interface[last_interface].MOBILE_NUMBER = mobile_number;
                        device_container_SA[ue_id - 1]._interface[last_interface].INTERFACE_TYPE = "5G_RAN";

                        device_container_SA[ue_id - 1].device.INTERFACE_COUNT = 1;

                        link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                        link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 1;
                        link_device_count++;
                        k++;
                    }
                    link[link_count].DEVICE_COUNT = link_device_count;
                    link_count++;
                    // device_container_SA[i].device.INTERFACE_COUNT = 4;//check the interface 
                    //device_container[max_5G_core_devices - 1].device.INTERFACE_COUNT = upf_last_interface + 1;
                    // upf_last_interface++;
                }


                /**********************************************************************************************/

                /**********************************************************************************************/
                //this block sets the attributes,position of SMF,AMF,UPF

                //ADD first UMF
                device_container_SA[0].pos_3d.X_OR_LON = UPF_x0;
                device_container_SA[0].pos_3d.Y_OR_LAT = UPF_y0;

                // upf_last_interface = device_container[total_device - 3].device.INTERFACE_COUNT;

                device_container_SA[0]._interface[0].ID = 1;
                device_container_SA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip(ipv4_count, 1);
                device_container_SA[0]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 4);
                device_container_SA[0]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[0]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[0]._interface[0].INTERFACE_TYPE = "5G_N4";
                device_container_SA[0]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);
               // device_container_SA[0].device.INTERFACE_COUNT = max_UPF_interface; 


                device_container_SA[0]._interface[1].ID = 2;
                device_container_SA[0]._interface[1].DEFAULT_GATEWAY = addNet.next_ip(ipv4_count, 1); ;
                device_container_SA[0]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 5);
                device_container_SA[0]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[0]._interface[1].MAC_ADDRESS = mac;
                device_container_SA[0]._interface[1].INTERFACE_TYPE = "5G_N3";
                device_container_SA[0]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(4);


                device_container_SA[0]._interface[2].ID = 3;
               // device_container_SA[0]._interface[2].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
               
                device_container_SA[0]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[0]._interface[2].MAC_ADDRESS = mac;
                device_container_SA[0]._interface[2].INTERFACE_TYPE = "5G_N6";
                device_container_SA[0]._interface[2].CONNECTED_TO = "Router_" + Convert.ToString(SA_router_id_1);//router id




                //Add SMF
                device_container_SA[1].pos_3d.X_OR_LON = SMF_x0;
                device_container_SA[1].pos_3d.Y_OR_LAT = SMF_y0;


                device_container_SA[1]._interface[0].ID = 1;
                device_container_SA[1]._interface[0].DEFAULT_GATEWAY = "";
                device_container_SA[1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 1);
                device_container_SA[1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[1]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[1]._interface[0].INTERFACE_TYPE = "5G_N11";
                device_container_SA[1]._interface[0].CONNECTED_TO = "AMF_" + Convert.ToString(3);
           //     device_container_SA[1].device.INTERFACE_COUNT = 2;

                device_container_SA[1]._interface[1].ID = 2;
                device_container_SA[1]._interface[1].DEFAULT_GATEWAY = "";
                device_container_SA[1]._interface[1].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                device_container_SA[1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[1]._interface[1].MAC_ADDRESS = mac;
                device_container_SA[1]._interface[1].INTERFACE_TYPE = "5G_N4";
                device_container_SA[1]._interface[1].CONNECTED_TO = "UPF_" + Convert.ToString(1);


                //ADD first AMF
                device_container_SA[2].pos_3d.X_OR_LON = AMF_x0;
                device_container_SA[2].pos_3d.Y_OR_LAT = AMF_y0;

                device_container_SA[2]._interface[0].ID = 1;
                device_container_SA[2]._interface[0].DEFAULT_GATEWAY = "";
                device_container_SA[2]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 1);
                device_container_SA[2]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[2]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[2]._interface[0].INTERFACE_TYPE = "5G_N11";
                device_container_SA[2]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);



                device_container_SA[2]._interface[1].ID = 2;
                device_container_SA[2]._interface[1].DEFAULT_GATEWAY = "";
                device_container_SA[2]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 7);
                device_container_SA[2]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[2]._interface[1].MAC_ADDRESS = mac;
                device_container_SA[2]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                device_container_SA[2]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);
                device_container_SA[2].device.INTERFACE_COUNT = 2;

                //L2_Switch_4

                device_container_SA[3].pos_3d.X_OR_LON = L2_Switch_4_x0;
                device_container_SA[3].pos_3d.Y_OR_LAT = L2_Switch_4_y0;

              //  device_container_SA[3].device.INTERFACE_COUNT = 2;

                device_container_SA[3]._interface[0].ID = 1;
                device_container_SA[3]._interface[0].DEFAULT_GATEWAY = "";
                device_container_SA[3]._interface[0].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                device_container_SA[3]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[3]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[3]._interface[0].INTERFACE_TYPE = "ETHERNET";
                device_container_SA[3]._interface[0].CONNECTED_TO = "UPF_" + Convert.ToString(1);


                device_container_SA[3]._interface[1].ID = 2;
                device_container_SA[3]._interface[1].DEFAULT_GATEWAY = "";
                device_container_SA[3]._interface[1].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                device_container_SA[3]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[3]._interface[1].MAC_ADDRESS = mac;
                device_container_SA[3]._interface[1].INTERFACE_TYPE = "ETHERNET";
                device_container_SA[3]._interface[1].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1);

                //attributes position of L2_Switches_5
                device_container_SA[4].pos_3d.X_OR_LON = L2_Switch_5_x0;
                device_container_SA[4].pos_3d.Y_OR_LAT = L2_Switch_5_y0;

              //  device_container_SA[4].device.INTERFACE_COUNT = 2;


                device_container_SA[4]._interface[0].ID = 1;
                device_container_SA[4]._interface[0].DEFAULT_GATEWAY = "";
                device_container_SA[4]._interface[0].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                device_container_SA[4]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[4]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[4]._interface[0].INTERFACE_TYPE = "ETHERNET";
                device_container_SA[4]._interface[0].CONNECTED_TO = "AMF_" + Convert.ToString(3);


                device_container_SA[4]._interface[1].ID = 2;
                device_container_SA[4]._interface[1].DEFAULT_GATEWAY = "";
                device_container_SA[4]._interface[1].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                device_container_SA[4]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[4]._interface[1].MAC_ADDRESS = mac;
                device_container_SA[4]._interface[1].INTERFACE_TYPE = "ETHERNET";
                device_container_SA[4]._interface[1].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1);


                //attributes position of L2_Switches_6
                device_container_SA[5].pos_3d.X_OR_LON = L2_Switch_6_x0;
                device_container_SA[5].pos_3d.Y_OR_LAT = L2_Switch_6_y0;

                device_container_SA[5].device.INTERFACE_COUNT = max_gnb;
                device_container_SA[5]._interface[0].ID = 1;
                device_container_SA[5]._interface[0].DEFAULT_GATEWAY = "";
                device_container_SA[5]._interface[0].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                device_container_SA[5]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[5]._interface[0].MAC_ADDRESS = mac;
                device_container_SA[5]._interface[0].INTERFACE_TYPE = "ETHERNET";
                device_container_SA[5]._interface[0].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1);

                /*-----------------------------------------------------------------------------------------------------*/
                // this block sets the attributes, position of first_router and
                SA_router_id_1 = max_5G_core_devices + max_gnb + 1;
                device_container_SA[SA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                device_container_SA[SA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;
                upf_last_interface = 1;
                //upf_last_interface = device_container[router_id_1 - 1].device.INTERFACE_COUNT;
                ipv4_count = 1;
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface - 1].ID = upf_last_interface;
                device_container_SA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                device_container_SA[0]._interface[2].IP_ADDRESS = addNet.next_ip_2(ipv4_count, 1);
                device_container_SA[0]._interface[1].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                device_container_SA[0]._interface[2].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface - 1].DEFAULT_GATEWAY = "";
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface - 1].IP_ADDRESS = addNet.next_ip_2(ipv4_count, 2);
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface - 1].MAC_ADDRESS = mac;
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface - 1].INTERFACE_TYPE = "SERIAL";
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface - 1].CONNECTED_TO = "UPF_" + Convert.ToString(1);
                device_container_SA[SA_router_id_1 - 1].device.INTERFACE_COUNT = upf_last_interface + 1;


                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                mac = addNet.next_mac(mac);
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "ETHERNET";
                device_container_SA[SA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "Wired_Node_" + Convert.ToString(SA_router_id_1 + max_router);


                //Router link with UPF
                link[link_count].link_device = new LINK_DEVICE[2];
                link[link_count].DEVICE_COUNT = 2;
                link[link_count].link_type = "UPF_Router";
                link[link_count].LINK_ID = link_count + 1;
                link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                link[link_count].link_device[1].DEVICE_ID = SA_router_id_1;
                link[link_count].link_device[1].INTERFACE_ID = 1;
                link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(SA_router_id_1);
                link[link_count].link_device[0].DEVICE_ID = 1;
                link[link_count].link_device[0].INTERFACE_ID = 3;
                link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                link_count++;



                device_container_SA[SA_router_id_1 - 1].level.r = 0.0;
                theta0 = device_container_SA[SA_router_id_1 - 1].level.theta = 0.0;
                level0 = device_container_SA[SA_router_id_1 - 1].level.level = 0;
                increment0 = device_container_SA[SA_router_id_1 - 1].level.increment = (360.0 / Math.Pow(branch, level0 + 1));
                device_container_SA[SA_router_id_1 - 1].level.low_angle = theta0 - (branch * 1.0) * increment0 / 2.0;
                device_container_SA[SA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                device_container_SA[SA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                /***********************************************************************************************/


                /***********************************************************************************************/
                //this block sets the attributes positions and interfaces ,link of all the routers
                ki = max_5G_core_devices + max_gnb - 1;// router id 
                for (i = ki; i < (max_router + max_5G_core_devices + max_gnb); i++)
                {
                    int id = device_container_SA[i].device.DEVICE_ID, index = 2;
                    int n_id_ = (id - (max_5G_core_devices - 1)) * branch + index + 1;
                    not_leaf_node = id - 1;
                    if (n_id_ > (max_router + max_5G_core_devices + max_gnb))
                        break;
                    int last_interface = device_container_SA[i].device.INTERFACE_COUNT;
                    POS_3D pos_3d = device_container_SA[i].pos_3d;

                    double r = device_container_SA[i].level.r;
                    double theta = device_container_SA[i].level.theta;
                    int level = device_container_SA[i].level.level;
                    low_angle = device_container_SA[i].level.low_angle;
                    double increment = device_container_SA[i].level.increment;
                    j = 0;
                    while (j < branch)
                    {
                        int n_id = (id - 1) * branch + (index++);
                        if (n_id > max_router)
                            break;

                        device_container_SA[i]._interface[last_interface].ID = last_interface;
                        device_container_SA[i]._interface[last_interface].DEFAULT_GATEWAY = "";
                        device_container_SA[i]._interface[last_interface].IP_ADDRESS = addNet.next_ip_2(++ipv4_count, 1);
                        mac = addNet.next_mac(mac);
                        device_container_SA[i]._interface[last_interface].MAC_ADDRESS = mac;
                        device_container_SA[i]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                        device_container_SA[i]._interface[last_interface].CONNECTED_TO = "";
                        device_container_SA[i]._interface[last_interface].INTERFACE_TYPE = "Serial";

                        int n_last_interface = device_container_SA[n_id_ - 1].device.INTERFACE_COUNT;
                        device_container_SA[n_id_ - 1]._interface[n_last_interface].ID = n_last_interface + 1;
                        device_container_SA[n_id_ - 1]._interface[n_last_interface].DEFAULT_GATEWAY = "";
                        device_container_SA[n_id_ - 1]._interface[n_last_interface].IP_ADDRESS = addNet.next_ip_2(ipv4_count, 2);
                        mac = addNet.next_mac(mac);
                        device_container_SA[n_id_ - 1]._interface[n_last_interface].MAC_ADDRESS = mac;
                        device_container_SA[n_id_ - 1]._interface[n_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        device_container_SA[n_id_ - 1]._interface[n_last_interface].CONNECTED_TO = "";
                        device_container_SA[n_id_ - 1]._interface[n_last_interface].INTERFACE_TYPE = "Serial";



                        double r1 = device_container_SA[n_id_ - 1].level.r = r + offset_radius;
                        double level1 = device_container_SA[n_id_ - 1].level.level = level + 1;
                        double theta1 = device_container_SA[n_id_ - 1].level.theta = low_angle + j * increment;
                        double increment1 = device_container_SA[n_id_ - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                        device_container_SA[n_id_ - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                        device_container_SA[n_id_ - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                        device_container_SA[n_id_ - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));

                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "Wired_Router";
                        link[link_count].link_device[0].DEVICE_ID = SA_router_id_1 + 1;
                        link[link_count].link_device[0].INTERFACE_ID = last_interface + 1;
                        link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(SA_router_id_1 + 1);
                        link[link_count].link_device[1].DEVICE_ID = i;
                        link[link_count].link_device[1].INTERFACE_ID = n_last_interface + 1;
                        link[link_count].link_device[1].NAME = "Wired_Node_" + Convert.ToString(n_id_);
                        //device_container[n_id - 1].device.INTERFACE_COUNT = n_last_interface + 1;
                        link_count++;
                        last_interface++;
                        j++;
                        i++;
                    }
                    device_container_SA[i].device.INTERFACE_COUNT = last_interface;
                }

                /*************************************************************************************************/

                //Console.WriteLine(not_leaf_node);
                //Console.ReadLine();

                /************************************************************************************************/
                // this block of code sets the sttributes,positions,interfaces,and link(to router) of all the wirednodes
                i = max_router + max_5G_core_devices + max_gnb;
                // int kii = - 1;//first router id
                int SA_max_node_temp = max_node;
                while (SA_max_node_temp != 0)
                {
                    for (j = max_5G_core_devices + max_gnb; j < i; j++)
                    {
                        int router_id = j;

                        int id = device_container_SA[i].device.DEVICE_ID;
                        int last_interface = device_container_SA[i].device.INTERFACE_COUNT;
                        int router_last_interface = device_container_SA[router_id - 1].device.INTERFACE_COUNT;
                        POS_3D pos_3d = device_container_SA[router_id - 1].pos_3d;

                        double r = device_container_SA[router_id - 1].level.r;
                        double theta = device_container_SA[router_id - 1].level.theta;
                        int level = device_container_SA[router_id - 1].level.level;
                        low_angle = device_container_SA[router_id - 1].level.low_angle;
                        double increment = device_container_SA[router_id - 1].level.increment;



                        /*
                            device_container[router_id - 1]._interface[router_last_interface - 1].ID = router_last_interface;
                            device_container[router_id - 1]._interface[router_last_interface - 1].DEFAULT_GATEWAY = "";

                          device_container[router_id- 1]._interface[router_last_interface -1].IP_ADDRESS = ip;
                         mac = addNet.next_mac(mac);
                          device_container[router_id- 1]._interface[router_last_interface - 1].MAC_ADDRESS = mac;
                       device_container[router_id - 1]._interface[router_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                     device_container[router_id - 1]._interface[router_last_interface - 1].CONNECTED_TO = "";
                       device_container[router_id - 1]._interface[router_last_interface -1].INTERFACE_TYPE = "ETHERNET";*/
                       ipv4_count = 1;
                        string ip = addNet.next_ip_3(ipv4_count, 1);
                        device_container_SA[id - 1]._interface[last_interface].ID = last_interface + 1;
                        device_container_SA[id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                        device_container_SA[id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 2);
                        mac = addNet.next_mac(mac);
                        device_container_SA[id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                        device_container_SA[id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                        device_container_SA[id - 1]._interface[last_interface].CONNECTED_TO = "";
                        device_container_SA[id - 1]._interface[last_interface].INTERFACE_TYPE = "ETHERNET";


                        double r1 = device_container_SA[id - 1].level.r = r + offset_radius;
                        //Console.WriteLine(r);
                        //Console.WriteLine(r1);
                        double level1 = device_container_SA[id - 1].level.level = level + 1;
                        double theta1 = device_container_SA[id - 1].level.theta = low_angle + (router_last_interface - 1) * increment;
                        double increment1 = device_container_SA[id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                        device_container_SA[id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                        device_container_SA[id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                        device_container_SA[id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));


                        //device_container[id - 1].pos_3d.X_OR_LON = (pos_3d.X_OR_LON + 0.1);
                        //device_container[id - 1].pos_3d.Y_OR_LAT = (pos_3d.Y_OR_LAT + 0.1);

                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "Wired_Router";
                        link[link_count].link_device[0].DEVICE_ID = id;
                        link[link_count].link_device[0].INTERFACE_ID = last_interface + 1;
                        link[link_count].link_device[0].NAME = "Wired_Node_" + Convert.ToString(id);
                        link[link_count].link_device[1].DEVICE_ID = router_id + 1;
                        link[link_count].link_device[1].INTERFACE_ID = last_interface + 2;
                        link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(router_id + 1);


                        device_container_SA[id - 1].device.INTERFACE_COUNT = last_interface + 1;
                        device_container_SA[router_id - 1].device.INTERFACE_COUNT = router_last_interface;

                        link_count++;
                        i++;
                        router_id++;


                        SA_max_node_temp--;
                        if (SA_max_node_temp == 0)
                            break;
                    }
                }

                /**************************************************************************************************/


                /************************************************************************************************/
                //this block of code randomly or from file  sets the  attributes for all the applications
                if (!application_from_file.Equals(""))
                {
                    /*
                      source id(max_router+1,max_router+max_node) and destination id(max_router+max_node+1,max_router+max_node+max_sensor) or vice versa
                    */
                    application_count = 0;
                    using (StreamReader sr = new StreamReader(application_from_file))
                    {
                        string line;
                        int count = 0;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (count == 0)
                            {
                                count++;
                                continue;
                            }
                            string[] tokens = line.Split(' ');
                            // Console.WriteLine(tokens[0]+","+tokens[1]);
                            if (application_count < max_application)
                            {
                                application[application_count].DESTINATION_ID = Convert.ToInt32(tokens[1]);
                                application[application_count].ID = application_count + 1;
                                application[application_count].NAME = "App" + Convert.ToString(application_count + 1) + "_CBR";
                                application[application_count].SOURCE_ID = Convert.ToInt32(tokens[0]);
                                application_count++;
                            }
                        }
                        // Console.ReadLine();
                    }
                }
                else
                {
                    //source = max_router + 1 to max_router + max_node
                    //destination = max_router + max_node + max_gnb + 1 to max_router + max_node + max_gnb + max_ue
                    int node_start = max_5G_core_devices + max_gnb + max_node + max_router;
                    int node_end = max_5G_core_devices + max_router + max_node + max_ue + max_gnb + 1;
                    int ue_start = max_5G_core_devices + max_router + max_node + max_gnb + 1;
                    //int ue_end = max_router + max_node + max_gnb + max_ue + 1;
                    int node = node_start;


                    for (i = 0; i < max_application; i++)
                    {
                        if (node == node_end)
                        {
                            ue_start++;
                            node = node_start;
                        }

                        application[i].DESTINATION_ID = node;
                        application[i].ID = i + 1;
                        application[i].NAME = Convert.ToString(i + 1);
                        application[i].SOURCE_ID = ue_start;
                        ue_start++;
                    }
                }
                /***************************************************************************************/


                /***************************************************************************************/
                //this block of code calls the diffrent funtions to create the Configuration.netsim
                nsWriter.add_experimentInfo(root, exp_name, version_name, mode,option);
                //nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\Experiment_Info.txt");
                nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\Gui_Info.txt");
                addNet.add_network(root, total_device_SA, link_count, max_application, device_container_SA, link, application, config_helper_location,args,gnb_ip_address);
                nsWriter.add_simulation_parameter(root, simulation_time);
                //nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\Simulation_Parameter.txt");

                nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\Protocol_Configuration.txt");
                nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\Statistics_Collection.txt");
                nsWriter.save_document(config_helper_location + "\\Configuration.netsim");
                /***************************************************************************************/


            }
            //For NSA mode

            else
            {
                if (args[1] == "OPTION_3")
                {
                    device_container_NSA = new DEVICE_CONTAINER[total_device_NSA];
                    for (i = 0; i < max_epc; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "LTE_EPC_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "LTE_EPC";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max__epc_interface];
                    }

                    for (; i < max_epc + L2_Switch; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "L2_Switch_gNB";
                        device_container_NSA[i].device.INTERFACE_COUNT = max_gnb + max_eNB;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_L2_Swtich_interface_NSA - max_gnb];
                    }
                    for (; i < max_epc + L2_Switch + max_gnb; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "gNB_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "LTE_gNB";
                       device_container_NSA[i].device.INTERFACE_COUNT = 2;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[2];
                    }

                    for (; i < max_epc + L2_Switch + max_gnb + max_router; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Router_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "ROUTER";
                        device_container_NSA[i].device.INTERFACE_COUNT = max_router_interface;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_router_interface];
                    }

                    for (; i < (max_epc + L2_Switch + max_gnb + max_router + max_node); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Wired_Node_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "WIREDNODE";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";
                        device_container_NSA[i]._interface = new INTERFACE[1];
                    }


                    /********************************************************************************************/


                    /********************************************************************************************/
                    device_container_NSA[0].device.DEVICE_ID = 1;
                    device_container_NSA[0].device.DEVICE_NAME = "LTE_EPC_" + Convert.ToString(1);
                    device_container_NSA[0].device.DEVICE_TYPE = "LTE_EPC";
                    device_container_NSA[0].device.INTERFACE_COUNT = 0;

                    device_container_NSA[0].pos_3d.X_OR_LON = epc_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = epc_y0;

                    device_container_NSA[0]._interface = new INTERFACE[max__epc_interface];

                    k = 1; int epc_last_interface = 0;
                    int enb_last_interface = 0, enb_r, idd = 0,octate = 4;

                    // this block sets the attributes,positions of all the enb and ue
                    for (; i < (max_epc + max_eNB + L2_Switch + max_router + max_node + max_gnb); i++)
                    {
                       

                        // epc_last_interface = device_container[total_device - 1].device.INTERFACE_COUNT;
                        device_container_NSA[0]._interface[epc_last_interface].ID = epc_last_interface + 1;
                        device_container_NSA[0]._interface[epc_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[0]._interface[epc_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        string ip = addNet.next_ip(++ipv4_count,1);
                        device_container_NSA[0]._interface[epc_last_interface].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[0]._interface[epc_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[0]._interface[epc_last_interface].CONNECTED_TO = "";
                        device_container_NSA[0]._interface[epc_last_interface].INTERFACE_TYPE = "WAN";
                        ipv4_count = 0;
                        device_container_NSA[0]._interface[epc_last_interface + 1].ID = 2;
                        device_container_NSA[0]._interface[epc_last_interface + 1].DEFAULT_GATEWAY = "";
                        device_container_NSA[0]._interface[epc_last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 4);
                        device_container_NSA[0]._interface[epc_last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[0]._interface[epc_last_interface + 1].MAC_ADDRESS = mac;
                        device_container_NSA[0]._interface[epc_last_interface + 1].INTERFACE_TYPE = "LTE";
                        device_container_NSA[0]._interface[epc_last_interface + 1].CONNECTED_TO = "";


                        //L2_Switch
                        for (enb_r = 0; enb_r < max_eNB; enb_r++)
                        {

                            device_container_NSA[1].device.DEVICE_ID = 2;
                            device_container_NSA[1].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(2);
                            device_container_NSA[1].device.DEVICE_TYPE = "L2_Switch_gNB";
                            // device_container[1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[1]._interface = new INTERFACE[max_L2_Swtich_interface_NSA];

                            device_container_NSA[1]._interface[enb_last_interface].ID = enb_last_interface + 1;
                            device_container_NSA[1]._interface[enb_last_interface].DEFAULT_GATEWAY = "";
                            //     device_container[1]._interface[enb_last_interface].IP_ADDRESS = addNet.next_ip(++ipv4_count, 1);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[1]._interface[enb_last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[1]._interface[enb_last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[1]._interface[enb_last_interface].CONNECTED_TO = "eNB_" + Convert.ToString(i + 1);
                            device_container_NSA[1]._interface[enb_last_interface].INTERFACE_TYPE = "ETHERNET";
                            enb_last_interface++;
                            //
                            while (idd < max_gnb)
                            {
                                device_container_NSA[1]._interface[enb_last_interface].ID = enb_last_interface + 1;
                                device_container_NSA[1]._interface[enb_last_interface].DEFAULT_GATEWAY = "";
                                //device_container[1]._interface[enb_last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 1);
                                mac = addNet.next_mac(mac);
                                device_container_NSA[1]._interface[enb_last_interface].MAC_ADDRESS = mac;
                                device_container_NSA[1]._interface[enb_last_interface].SUBNET_MASK = addNet.subnet_mask();
                                device_container_NSA[1]._interface[enb_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(NSA_gnb_idd);
                                device_container_NSA[1]._interface[enb_last_interface].INTERFACE_TYPE = "ETHERNET";
                                idd++;
                            }
                            octate += 8;
                        }

                        //L2_Switch and gNB link
                        link_device_count = link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "L2_Swtich_gNB";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = NSA_gnb_idd;
                        link[link_count].link_device[0].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd);
                        link[link_count].link_device[0].INTERFACE_ID = 1;
                        link[link_count].link_device[1].DEVICE_ID = 2;
                        link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(2);
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link_count++;

                        //Link EPC with router
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].link_type = "EPC_Router_Router";
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_device[0].DEVICE_ID = NSA_router_id_1;
                        link[link_count].link_device[0].INTERFACE_ID = 1;
                        link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(NSA_router_id_1);
                        link[link_count].link_device[1].DEVICE_ID = 1;
                        link[link_count].link_device[1].INTERFACE_ID = epc_last_interface + 1;
                        link[link_count].link_device[1].NAME = "EPC_" + Convert.ToString(1);
                        link_count++;

                        //link EPC with enb                             
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_EPC";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 1;
                        link[link_count].link_device[0].NAME = "EPC_" + Convert.ToString(1);
                        link[link_count].link_device[0].INTERFACE_ID = 2;
                        link[link_count].link_device[1].DEVICE_ID = i + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(i + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link_count++;

                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "eNB_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "LTE_eNB";
                        //device_container[i].device.INTERFACE_COUNT = 3;
                        device_container_NSA[i]._interface = new INTERFACE[3];

                        device_container_NSA[i]._interface[2].ID = 3;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[i]._interface[2].MAC_ADDRESS = mac;
                        device_container_NSA[i]._interface[2].INTERFACE_TYPE = "LTE";

                        device_container_NSA[i]._interface[1].ID = 2;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[i]._interface[1].MAC_ADDRESS = mac;
                        device_container_NSA[i]._interface[1].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[i]._interface[0].ID = 1;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[i]._interface[0].MAC_ADDRESS = mac;
                        device_container_NSA[i]._interface[0].INTERFACE_TYPE = "LTE_S1";


                        double theta = i * gnb_angle_increment;
                        device_container_NSA[i].pos_3d.X_OR_LON = enb_x0 + gnb_radius * Math.Cos(Math.PI * (theta / 180.0));
                        device_container_NSA[i].pos_3d.Y_OR_LAT = enb_y0 + gnb_radius * Math.Sin(Math.PI * (theta / 180.0));
                        low_angle = theta - (num_ue_per_enb_NSA * ue_angle_increment / 2.0);

                        //L2_Switch and eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "L2_Swtich_eNB";
                        link[link_count].link_device = new LINK_DEVICE[max_eNB + 1];
                        link[link_count].link_device[0].DEVICE_ID = i + 1;
                        link[link_count].link_device[0].NAME = "eNB_" + Convert.ToString(i + 1);
                        link[link_count].link_device[0].INTERFACE_ID = 2;
                        link[link_count].link_device[1].DEVICE_ID = 2;
                        link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(2);
                        link[link_count].link_device[1].INTERFACE_ID = 2;
                        link_count++;

                        //Link gNB  with Ue
                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "gNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_gnb + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = NSA_gnb_idd;
                        link[link_count].link_device[link_device_count].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                        link_device_count++;

                        //gnb with ue
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = k + max_router + max_node + max_gnb + max_eNB + L2_Switch + max_epc;
                            if (ue_id - 1 >= total_device_NSA)
                                break;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                            link_device_count++;
                            k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;

                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_enb_NSA + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = i + 1;
                        link[link_count].link_device[link_device_count].NAME = "eNB_" + Convert.ToString(i + 1);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 3;
                        link_device_count++;


                        //Ue and eNb
                        k = 1;
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = k + max_router + max_node + max_gnb + max_eNB + L2_Switch + max_epc;
                            if (ue_id - 1 >= total_device_NSA)
                                break;

                            device_container_NSA[ue_id - 1].device.DEVICE_ID = ue_id;
                            device_container_NSA[ue_id - 1].device.DEVICE_NAME = "UE_" + Convert.ToString(ue_id);
                            device_container_NSA[ue_id - 1].device.DEVICE_TYPE = "LTE_NR_UE";
                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[ue_id - 1].device.WIRESHARK_OPTION = "Disable";
                            device_container_NSA[ue_id - 1]._interface = new INTERFACE[2];

                            double theta1 = low_angle + l * ue_angle_increment;
                            device_container_NSA[ue_id - 1].pos_3d.X_OR_LON = enb_x0 + ue_radius * Math.Cos(Math.PI * (theta1 / 180.0));
                            device_container_NSA[ue_id - 1].pos_3d.Y_OR_LAT = enb_y0 + ue_radius * Math.Sin(Math.PI * (theta1 / 180.0));
                            ipv4_count = 0;
                            int last_interface = device_container_NSA[ue_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[ue_id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[ue_id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                            device_container_NSA[ue_id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface].INTERFACE_TYPE = "LTE";

                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].ID = last_interface + 2;
                          device_container_NSA[ue_id - 1]._interface[last_interface + 1].DEFAULT_GATEWAY = ip;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].INTERFACE_TYPE = "5G_RAN";

                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 2;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 1;
                            link_device_count++;
                            k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;
                        device_container_NSA[i].device.INTERFACE_COUNT = 3;
                        device_container_NSA[0].device.INTERFACE_COUNT = epc_last_interface + 2;
                        epc_last_interface++;
                    }
                    /**********************************************************************************************/

                    /**********************************************************************************************/
                    //this block sets the attributes,position of first_router and  L2_Switch and enb


                    device_container_NSA[0].pos_3d.X_OR_LON = epc_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = epc_y0;


                    device_container_NSA[1].pos_3d.X_OR_LON = L2_Switch_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = L2_Switch_y0;



                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    //for gNB
                    /*device_container[gnb_idd - 1].device.DEVICE_ID = gnb_idd;
                    device_container[gnb_idd - 1].device.DEVICE_NAME = "gNB_" + Convert.ToString(gnb_idd);
                    device_container[gnb_idd - 1].device.DEVICE_TYPE = "LTE_gNB";
                    //device_container[gnb_idd - 1].device.INTERFACE_COUNT = 0;
                    device_container[gnb_idd - 1]._interface = new INTERFACE[2];*/


                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].ID = 1;
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 5);
                    mac = addNet.next_mac(mac);
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].CONNECTED_TO = "L2_Switch_" + Convert.ToString(2);
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].INTERFACE_TYPE = "5G_XN";

                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].ID = 2;
                    mac = addNet.next_mac(mac);
                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].INTERFACE_TYPE = "5G_RAN";

                    device_container_NSA[NSA_gnb_idd - 1].pos_3d.X_OR_LON = gnb_x0;
                    device_container_NSA[NSA_gnb_idd - 1].pos_3d.Y_OR_LAT = gnb_y0;


                    device_container_NSA[NSA_router_id_1 - 1].level.r = 0.0;
                    theta0 = device_container_NSA[NSA_router_id_1 - 1].level.theta = 0.0;
                    level0 = device_container_NSA[NSA_router_id_1 - 1].level.level = 0;
                     increment0 = device_container_NSA[NSA_router_id_1 - 1].level.increment = (360.0 / Math.Pow(branch, level0 + 1));
                    device_container_NSA[NSA_router_id_1 - 1].level.low_angle = theta0 - (branch * 1.0) * increment0 / 2.0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    /***********************************************************************************************/


                    /***********************************************************************************************/
                    //this block sets the attributes positions and interfaces ,link of all the routers
                    i = max_epc + max_eNB + max_gnb + L2_Switch - 1;
                    for (; i < max_epc + max_eNB + max_gnb + L2_Switch + max_router; i++)
                    {
                        int id = device_container_NSA[i].device.DEVICE_ID, index = 2;
                        int n_id_ = (id - 1 - (max_epc + max_eNB + max_gnb + L2_Switch)) * branch + index;
                        not_leaf_node = id - 1;
                        if (n_id_ > max_router)
                            break;
                        int last_interface = device_container_NSA[i].device.INTERFACE_COUNT;
                        POS_3D pos_3d = device_container_NSA[i].pos_3d;

                        double r = device_container_NSA[i].level.r;
                        double theta = device_container_NSA[i].level.theta;
                        int level = device_container_NSA[i].level.level;
                        low_angle = device_container_NSA[i].level.low_angle;
                        double increment = device_container_NSA[i].level.increment;
                        j = 0;
                        while (j < branch)
                        {
                            int n_id = (id - 1) * branch + (index++);
                            if (n_id > max_router)
                                break;

                            device_container_NSA[i]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[i]._interface[last_interface].DEFAULT_GATEWAY = "";
                            device_container_NSA[i]._interface[last_interface].IP_ADDRESS = addNet.next_ip(++ipv4_count, 1);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[i]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[i]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[i]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[i]._interface[last_interface].INTERFACE_TYPE = "WAN";

                            int n_last_interface = device_container_NSA[n_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[n_id - 1]._interface[n_last_interface].ID = n_last_interface + 1;
                            device_container_NSA[n_id - 1]._interface[n_last_interface].DEFAULT_GATEWAY = "";
                            device_container_NSA[n_id - 1]._interface[n_last_interface].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[n_id - 1]._interface[n_last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[n_id - 1]._interface[n_last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[n_id - 1]._interface[n_last_interface].CONNECTED_TO = "";
                            device_container_NSA[n_id - 1]._interface[n_last_interface].INTERFACE_TYPE = "WAN";



                            double r1 = device_container_NSA[n_id - 1].level.r = r + offset_radius;
                            double level1 = device_container_NSA[n_id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[n_id - 1].level.theta = low_angle + j * increment;
                            double increment1 = device_container_NSA[n_id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[n_id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[n_id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[n_id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "EPC_Router_Router";
                            link[link_count].link_device[0].DEVICE_ID = id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(id);
                            link[link_count].link_device[1].DEVICE_ID = n_id;
                            link[link_count].link_device[1].INTERFACE_ID = n_last_interface + 1;
                            link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(n_id);
                            device_container_NSA[n_id - 1].device.INTERFACE_COUNT = n_last_interface + 1;
                            link_count++;
                            last_interface++;
                            j++;
                        }
                        device_container_NSA[i].device.INTERFACE_COUNT = last_interface;
                    }
                    /*************************************************************************************************/

                    //Console.WriteLine(not_leaf_node);
                    //Console.ReadLine();

                    /************************************************************************************************/
                    // this block of code sets the sttributes,positions,interfaces,and link(to router) of all the wirednodes
                    i = max_epc + max_eNB + max_gnb + L2_Switch + max_router;
                    int max_node_temp = max_node;
                    while (max_node_temp != 0)
                    {
                        for (j = max_epc + L2_Switch + max_gnb; j < max_epc + max_eNB + max_gnb + L2_Switch + max_router; j++)
                        {
                            int router_id = j + 1;
                            int id = device_container_NSA[i - 1].device.DEVICE_ID;
                            int last_interface = device_container_NSA[id - 1].device.INTERFACE_COUNT;
                            int router_last_interface = device_container_NSA[router_id - 1].device.INTERFACE_COUNT;
                            POS_3D pos_3d = device_container_NSA[router_id - 1].pos_3d;

                            double r = device_container_NSA[router_id - 1].level.r;
                            double theta = device_container_NSA[router_id - 1].level.theta;
                            int level = device_container_NSA[router_id - 1].level.level;
                            low_angle = device_container_NSA[router_id - 1].level.low_angle;
                            double increment = device_container_NSA[router_id - 1].level.increment;




                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].ID = 1;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].DEFAULT_GATEWAY = "";
                            string ip = addNet.next_ip(++ipv4_count, 2);
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].INTERFACE_TYPE = "WAN";

                            device_container_NSA[router_id - 1]._interface[router_last_interface - 2].ID = 2;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 2].DEFAULT_GATEWAY = "";
                            ip = addNet.next_ip_3(++ipv4_count, 1);
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 2].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 2].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 2].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 2].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 2].INTERFACE_TYPE = "ETHERNET";
                            router_last_interface++;

                            device_container_NSA[id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                            device_container_NSA[id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[id - 1]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[id - 1]._interface[last_interface].INTERFACE_TYPE = "ETHERNET";


                            double r1 = device_container_NSA[id - 1].level.r = r + offset_radius;
                            //Console.WriteLine(r);
                            //Console.WriteLine(r1);
                            double level1 = device_container_NSA[id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[id - 1].level.theta = low_angle + (router_last_interface - 1) * increment;
                            double increment1 = device_container_NSA[id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));


                            //device_container[id - 1].pos_3d.X_OR_LON = (pos_3d.X_OR_LON + 0.1);
                            //device_container[id - 1].pos_3d.Y_OR_LAT = (pos_3d.Y_OR_LAT + 0.1);

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "Wired_Router";
                            link[link_count].link_device[0].DEVICE_ID = id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[0].NAME = "Wired_Node_" + Convert.ToString(id);
                            link[link_count].link_device[1].DEVICE_ID = router_id;
                            link[link_count].link_device[1].INTERFACE_ID = router_last_interface + 1;
                            link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(router_id);


                            device_container_NSA[id - 1].device.INTERFACE_COUNT = last_interface + 1;
                            device_container_NSA[router_id - 1].device.INTERFACE_COUNT = router_last_interface + 1;

                            link_count++;
                            i++;
                            max_node_temp--;
                            if (max_node_temp == 0)
                                break;
                        }
                    }

                }
/**********************************************************************************************************************************************/
                else if (args[1] == "OPTION_3a")
                {
                    for (i = 0; i < max_epc; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "LTE_EPC_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "LTE_EPC";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max__epc_interface];
                    }

                    for (; i < max_epc + L2_Switch; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "L2_Switch_gNB";
                        device_container_NSA[i].device.INTERFACE_COUNT = max_gnb;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max__epc_interface];
                    }
                    for (; i < max_epc + L2_Switch + max_gnb; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "gNB_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "LTE_gNB";
                        device_container_NSA[i].device.INTERFACE_COUNT = 3;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[3];
                    }

                    for (; i < max_epc + L2_Switch + max_gnb + max_router; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Router_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "ROUTER";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_router_interface];
                    }

                    for (; i < (max_epc + L2_Switch + max_gnb + max_router + max_node); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Wired_Node_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "WIREDNODE";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";
                        device_container_NSA[i]._interface = new INTERFACE[1];
                    }
                    /********************************************************************************************/


                    /********************************************************************************************/
                    device_container_NSA[0].device.DEVICE_ID = 1;
                    device_container_NSA[0].device.DEVICE_NAME = "LTE_EPC_" + Convert.ToString(1);
                    device_container_NSA[0].device.DEVICE_TYPE = "LTE_EPC";
                    device_container_NSA[0].device.INTERFACE_COUNT = 0;

                    device_container_NSA[0].pos_3d.X_OR_LON = epc_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = epc_y0;

                    device_container_NSA[0]._interface = new INTERFACE[max__epc_interface];

                    k = 1; int epc_last_interface = 0;
                    int enb_last_interface = 0, enb_r;

                    // this block sets the attributes,positions of all the enb and ue
                    for (; i < (max_epc + max_eNB + L2_Switch + max_router + max_node + max_gnb); i++)
                    {

                        // epc_last_interface = device_container[total_device - 1].device.INTERFACE_COUNT;
                        device_container_NSA[0]._interface[epc_last_interface].ID = epc_last_interface + 1;
                        device_container_NSA[0]._interface[epc_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[0]._interface[epc_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        string ip = addNet.next_ip_1(ipv4_count, 4);
                        device_container_NSA[0]._interface[epc_last_interface].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[0]._interface[epc_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[0]._interface[epc_last_interface].CONNECTED_TO = "";
                        device_container_NSA[0]._interface[epc_last_interface].INTERFACE_TYPE = "LTE_NR";

                        device_container_NSA[0]._interface[epc_last_interface + 1].ID = 2;
                        device_container_NSA[0]._interface[epc_last_interface + 1].DEFAULT_GATEWAY = "";
                        device_container_NSA[0]._interface[epc_last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 6);
                        device_container_NSA[0]._interface[epc_last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[0]._interface[epc_last_interface + 1].MAC_ADDRESS = mac;
                        device_container_NSA[0]._interface[epc_last_interface + 1].INTERFACE_TYPE = "LTE";
                        device_container_NSA[0]._interface[epc_last_interface + 1].CONNECTED_TO = "";

                        device_container_NSA[0]._interface[epc_last_interface + 2].ID = 3;
                        device_container_NSA[0]._interface[epc_last_interface + 2].DEFAULT_GATEWAY = "";
                        device_container_NSA[0]._interface[epc_last_interface + 2].IP_ADDRESS = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[0]._interface[epc_last_interface + 2].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[0]._interface[epc_last_interface + 2].MAC_ADDRESS = mac;
                        device_container_NSA[0]._interface[epc_last_interface + 2].INTERFACE_TYPE = "WAN";
                        device_container_NSA[0]._interface[epc_last_interface + 2].CONNECTED_TO = "";

                        //L2_Switch

                        for (enb_r = 0; enb_r < max_eNB; enb_r++)
                        {

                            device_container_NSA[1].device.DEVICE_ID = 2;
                            device_container_NSA[1].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(2);
                            device_container_NSA[1].device.DEVICE_TYPE = "L2_Switch_gNB";
                            // device_container[1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[1]._interface = new INTERFACE[max_L2_Swtich_interface_NSA];

                            device_container_NSA[1]._interface[enb_last_interface].ID = enb_last_interface + 1;
                            device_container_NSA[1]._interface[enb_last_interface].DEFAULT_GATEWAY = "";
                            //     device_container[1]._interface[enb_last_interface].IP_ADDRESS = addNet.next_ip(++ipv4_count, 1);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[1]._interface[enb_last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[1]._interface[enb_last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[1]._interface[enb_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(NSA_gnb_idd);
                            device_container_NSA[1]._interface[enb_last_interface].INTERFACE_TYPE = "ETHERNET";
                            enb_last_interface++;
                            //
                            /* while (idd < max_gnb)
                             {
                                 device_container[1]._interface[enb_last_interface].ID = enb_last_interface + 1;
                                 device_container[1]._interface[enb_last_interface].DEFAULT_GATEWAY = "";
                                 //device_container[1]._interface[enb_last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 1);
                                 mac = addNet.next_mac(mac);
                                 device_container[1]._interface[enb_last_interface].MAC_ADDRESS = mac;
                                 device_container[1]._interface[enb_last_interface].SUBNET_MASK = addNet.subnet_mask();
                                 device_container[1]._interface[enb_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(gnb_idd);
                                 device_container[1]._interface[enb_last_interface].INTERFACE_TYPE = "ETHERNET";
                                 idd++;
                             }*/
                        }

                        //link EPC with gnb                             
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "gNB_EPC";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 1;
                        link[link_count].link_device[0].NAME = "EPC_" + Convert.ToString(1);
                        link[link_count].link_device[0].INTERFACE_ID = 1;
                        link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd;
                        link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd);
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link_count++;

                        //L2_Switch and gNB link
                        link_device_count = link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "L2_Swtich_gNB";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 2;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(2);
                        link[link_count].link_device[0].INTERFACE_ID = 1;
                        link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd;
                        link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd);
                        link[link_count].link_device[1].INTERFACE_ID = 2;
                        link_count++;

                        //link EPC with enb                             
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_EPC";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 1;
                        link[link_count].link_device[0].NAME = "LTE_EPC_" + Convert.ToString(1);
                        link[link_count].link_device[0].INTERFACE_ID = 2;
                        link[link_count].link_device[1].DEVICE_ID = i + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(i + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link_count++;

                        //Link EPC with router
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].link_type = "EPC_Router_Router";
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_device[0].DEVICE_ID = NSA_router_id_1;
                        link[link_count].link_device[0].INTERFACE_ID = 1;
                        link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(NSA_router_id_1);
                        link[link_count].link_device[1].DEVICE_ID = 1;
                        link[link_count].link_device[1].INTERFACE_ID = 3;
                        link[link_count].link_device[1].NAME = "LTE_EPC_" + Convert.ToString(1);
                        link_count++;


                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "eNB_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "LTE_eNB";
                        //device_container[i].device.INTERFACE_COUNT = 3;
                        device_container_NSA[i]._interface = new INTERFACE[2];

                        device_container_NSA[i]._interface[1].ID = 2;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[i]._interface[1].MAC_ADDRESS = mac;
                        device_container_NSA[i]._interface[1].INTERFACE_TYPE = "LTE";

                        /*device_container[i]._interface[1].ID = 2;
                        mac = addNet.next_mac(mac);
                        device_container[i]._interface[1].MAC_ADDRESS = mac;
                        device_container[i]._interface[1].INTERFACE_TYPE = "5G_XN";*/

                        device_container_NSA[i]._interface[0].ID = 1;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[i]._interface[0].MAC_ADDRESS = mac;
                        device_container_NSA[i]._interface[0].INTERFACE_TYPE = "LTE_S1";


                        double theta = i * gnb_angle_increment;
                        device_container_NSA[i].pos_3d.X_OR_LON = enb_x0 + gnb_radius * Math.Cos(Math.PI * (theta / 180.0));
                        device_container_NSA[i].pos_3d.Y_OR_LAT = enb_y0 + gnb_radius * Math.Sin(Math.PI * (theta / 180.0));
                        low_angle = theta - (num_ue_per_enb_NSA * ue_angle_increment / 2.0);

                        //Link gNB  with Ue
                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "gNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_gnb + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = NSA_gnb_idd;
                        link[link_count].link_device[link_device_count].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 3;
                        link_device_count++;

                        //gnb with ue
                        for (int l = 0; l < num_ue_per_gnb_NSA; l++)
                        {
                            int ue_id = k + max_router + max_node + max_gnb + max_eNB + L2_Switch + max_epc;
                            if (ue_id - 1 >= total_device_NSA)
                                break;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                            link_device_count++;
                            k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;

                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_enb_NSA + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = i + 1;
                        link[link_count].link_device[link_device_count].NAME = "eNB_" + Convert.ToString(i + 1);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                        link_device_count++;


                        //Ue and eNb
                        k = 1;
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = k + max_router + max_node + max_gnb + max_eNB + L2_Switch + max_epc;
                            if (ue_id - 1 >= total_device_NSA)
                                break;

                            device_container_NSA[ue_id - 1].device.DEVICE_ID = ue_id;
                            device_container_NSA[ue_id - 1].device.DEVICE_NAME = "UE_" + Convert.ToString(ue_id);
                            device_container_NSA[ue_id - 1].device.DEVICE_TYPE = "LTE_NR_UE";
                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[ue_id - 1].device.WIRESHARK_OPTION = "Disable";
                            device_container_NSA[ue_id - 1]._interface = new INTERFACE[2];

                            double theta1 = low_angle + l * ue_angle_increment;
                            device_container_NSA[ue_id - 1].pos_3d.X_OR_LON = enb_x0 + ue_radius * Math.Cos(Math.PI * (theta1 / 180.0));
                            device_container_NSA[ue_id - 1].pos_3d.Y_OR_LAT = enb_y0 + ue_radius * Math.Sin(Math.PI * (theta1 / 180.0));

                            int last_interface = device_container_NSA[ue_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[ue_id - 1]._interface[last_interface].ID = last_interface + 1;
                            // device_container[ue_id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                            ipv4_count = 0;
                            device_container_NSA[ue_id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface].INTERFACE_TYPE = "LTE";

                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].ID = last_interface + 2;
                            //  device_container[ue_id - 1]._interface[last_interface + 1].DEFAULT_GATEWAY = ip;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].INTERFACE_TYPE = "5G_RAN";

                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 2;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 1;
                            link_device_count++;
                            k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;
                        device_container_NSA[i].device.INTERFACE_COUNT = 2;
                        device_container_NSA[0].device.INTERFACE_COUNT = epc_last_interface + 3;
                        epc_last_interface++;
                    }
                    /**********************************************************************************************/

                    /**********************************************************************************************/
                    //this block sets the attributes,position of first_router and  L2_Switch and enb


                    device_container_NSA[0].pos_3d.X_OR_LON = epc_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = epc_y0;


                    device_container_NSA[1].pos_3d.X_OR_LON = L2_Switch_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = L2_Switch_y0;



                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    //for gNB
                    /*device_container[gnb_idd - 1].device.DEVICE_ID = gnb_idd;
                    device_container[gnb_idd - 1].device.DEVICE_NAME = "gNB_" + Convert.ToString(gnb_idd);
                    device_container[gnb_idd - 1].device.DEVICE_TYPE = "LTE_gNB";
                    //device_container[gnb_idd - 1].device.INTERFACE_COUNT = 0;
                    device_container[gnb_idd - 1]._interface = new INTERFACE[2];*/


                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].ID = 1;
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 4);
                    mac = addNet.next_mac(mac);
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    // device_container[gnb_idd - 1]._interface[0].CONNECTED_TO = "L2_Switch_" + Convert.ToString(2);
                    device_container_NSA[NSA_gnb_idd - 1]._interface[0].INTERFACE_TYPE = "LTE_S1";

                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].ID = 2;
                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 5);
                    mac = addNet.next_mac(mac);
                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(2);
                    device_container_NSA[NSA_gnb_idd - 1]._interface[1].INTERFACE_TYPE = "5G_XN";


                    device_container_NSA[NSA_gnb_idd - 1]._interface[2].ID = 3;
                    mac = addNet.next_mac(mac);
                    device_container_NSA[NSA_gnb_idd - 1]._interface[2].MAC_ADDRESS = mac;
                    device_container_NSA[NSA_gnb_idd - 1]._interface[2].INTERFACE_TYPE = "5G_RAN";



                    device_container_NSA[NSA_gnb_idd - 1].pos_3d.X_OR_LON = gnb_x0;
                    device_container_NSA[NSA_gnb_idd - 1].pos_3d.Y_OR_LAT = gnb_y0;


                    device_container_NSA[NSA_router_id_1 - 1].level.r = 0.0;
                     theta0 = device_container_NSA[NSA_router_id_1 - 1].level.theta = 0.0;
                     level0 = device_container_NSA[NSA_router_id_1 - 1].level.level = 0;
                    increment0 = device_container_NSA[NSA_router_id_1 - 1].level.increment = (360.0 / Math.Pow(branch, level0 + 1));
                    device_container_NSA[NSA_router_id_1 - 1].level.low_angle = theta0 - (branch * 1.0) * increment0 / 2.0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    /***********************************************************************************************/


                    /***********************************************************************************************/
                    //this block sets the attributes positions and interfaces ,link of all the routers
                    i = max_epc + max_eNB + max_gnb + L2_Switch - 1;
                    for (; i < max_epc + max_eNB + max_gnb + L2_Switch + max_router; i++)
                    {
                        int id = device_container_NSA[i].device.DEVICE_ID, index = 2;
                        int n_id_ = (id - 1 - (max_epc + max_eNB + max_gnb + L2_Switch)) * branch + index;
                        not_leaf_node = id - 1;
                        if (n_id_ > max_router)
                            break;
                        int last_interface = device_container_NSA[i].device.INTERFACE_COUNT;
                        POS_3D pos_3d = device_container_NSA[i].pos_3d;

                        double r = device_container_NSA[i].level.r;
                        double theta = device_container_NSA[i].level.theta;
                        int level = device_container_NSA[i].level.level;
                         low_angle = device_container_NSA[i].level.low_angle;
                        double increment = device_container_NSA[i].level.increment;
                        j = 0;
                        while (j < branch)
                        {
                            int n_id = (id - 1) * branch + (index++);
                            if (n_id > max_router)
                                break;

                            device_container_NSA[i]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[i]._interface[last_interface].DEFAULT_GATEWAY = "";
                            device_container_NSA[i]._interface[last_interface].IP_ADDRESS = addNet.next_ip(++ipv4_count, 1);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[i]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[i]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[i]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[i]._interface[last_interface].INTERFACE_TYPE = "WAN";

                            int n_last_interface = device_container_NSA[n_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[n_id - 1]._interface[n_last_interface].ID = n_last_interface + 1;
                            device_container_NSA[n_id - 1]._interface[n_last_interface].DEFAULT_GATEWAY = "";
                            device_container_NSA[n_id - 1]._interface[n_last_interface].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[n_id - 1]._interface[n_last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[n_id - 1]._interface[n_last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[n_id - 1]._interface[n_last_interface].CONNECTED_TO = "";
                            device_container_NSA[n_id - 1]._interface[n_last_interface].INTERFACE_TYPE = "WAN";



                            double r1 = device_container_NSA[n_id - 1].level.r = r + offset_radius;
                            double level1 = device_container_NSA[n_id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[n_id - 1].level.theta = low_angle + j * increment;
                            double increment1 = device_container_NSA[n_id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[n_id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[n_id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[n_id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "EPC_Router_Router";
                            link[link_count].link_device[0].DEVICE_ID = id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(id);
                            link[link_count].link_device[1].DEVICE_ID = n_id;
                            link[link_count].link_device[1].INTERFACE_ID = n_last_interface + 1;
                            link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(n_id);
                            device_container_NSA[n_id - 1].device.INTERFACE_COUNT = n_last_interface + 1;
                            link_count++;
                            last_interface++;
                            j++;
                        }
                        device_container_NSA[i].device.INTERFACE_COUNT = last_interface;
                    }
                    /*************************************************************************************************/

                    //Console.WriteLine(not_leaf_node);
                    //Console.ReadLine();

                    /************************************************************************************************/
                    // this block of code sets the sttributes,positions,interfaces,and link(to router) of all the wirednodes
                    i = max_epc + max_eNB + max_gnb + L2_Switch + max_router;
                    int max_node_temp = max_node;
                    while (max_node_temp != 0)
                    {
                        for (j = not_leaf_node; j < max_epc + max_eNB + max_gnb + L2_Switch + max_router; j++)
                        {
                            int router_id = j;
                            int id = device_container_NSA[i - 1].device.DEVICE_ID;
                            int last_interface = device_container_NSA[id - 1].device.INTERFACE_COUNT;
                            int router_last_interface = device_container_NSA[router_id - 1].device.INTERFACE_COUNT;
                            POS_3D pos_3d = device_container_NSA[router_id - 1].pos_3d;

                            double r = device_container_NSA[router_id - 1].level.r;
                            double theta = device_container_NSA[router_id - 1].level.theta;
                            int level = device_container_NSA[router_id - 1].level.level;
                             low_angle = device_container_NSA[router_id - 1].level.low_angle;
                            double increment = device_container_NSA[router_id - 1].level.increment;




                            device_container_NSA[router_id - 1]._interface[router_last_interface].ID = router_last_interface + 1;
                            device_container_NSA[router_id - 1]._interface[router_last_interface].DEFAULT_GATEWAY = "";
                            string ip = addNet.next_ip(++ipv4_count, 2);
                            device_container_NSA[router_id - 1]._interface[router_last_interface].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface].INTERFACE_TYPE = "WAN";

                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].ID = router_last_interface + 2;
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].DEFAULT_GATEWAY = "";
                            ip = addNet.next_ip_3(++ipv4_count, 1);
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].INTERFACE_TYPE = "ETHERNET";
                            router_last_interface++;

                            device_container_NSA[id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                            device_container_NSA[id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[id - 1]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[id - 1]._interface[last_interface].INTERFACE_TYPE = "ETHERNET";


                            double r1 = device_container_NSA[id - 1].level.r = r + offset_radius;
                            //Console.WriteLine(r);
                            //Console.WriteLine(r1);
                            double level1 = device_container_NSA[id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[id - 1].level.theta = low_angle + (router_last_interface - 1) * increment;
                            double increment1 = device_container_NSA[id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));


                            //device_container[id - 1].pos_3d.X_OR_LON = (pos_3d.X_OR_LON + 0.1);
                            //device_container[id - 1].pos_3d.Y_OR_LAT = (pos_3d.Y_OR_LAT + 0.1);

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "Wired_Router";
                            link[link_count].link_device[0].DEVICE_ID = id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[0].NAME = "Wired_Node_" + Convert.ToString(id);
                            link[link_count].link_device[1].DEVICE_ID = router_id;
                            link[link_count].link_device[1].INTERFACE_ID = router_last_interface + 1;
                            link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(router_id);


                            device_container_NSA[id - 1].device.INTERFACE_COUNT = last_interface + 1;
                            device_container_NSA[router_id - 1].device.INTERFACE_COUNT = router_last_interface + 1;

                            link_count++;
                            i++;
                            max_node_temp--;
                            if (max_node_temp == 0)
                                break;
                        }
                    }

                }
                /*********************************************************************************************************************/
                else if (args[1] == "OPTION_3x")
                {
                    device_container_NSA = new DEVICE_CONTAINER[total_device_NSA];
                    for (i = 0; i < max_epc; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "LTE_EPC_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "LTE_EPC";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max__epc_interface];
                    }

                    for (; i < max_epc + L2_Switch; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "L2_Switch_gNB";
                        device_container_NSA[i].device.INTERFACE_COUNT = max_gnb + max_eNB;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_L2_Swtich_interface_NSA];
                    }
                    for (; i < max_epc + L2_Switch + max_gnb; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "gNB_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "LTE_gNB";
                        device_container_NSA[i].device.INTERFACE_COUNT = 3;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[3];
                    }

                    for (; i < max_epc + L2_Switch + max_gnb + max_router; i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Router_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "ROUTER";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_router_interface];
                    }

                    for (; i < (max_epc + L2_Switch + max_gnb + max_router + max_node); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Wired_Node_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "WIREDNODE";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";
                        device_container_NSA[i]._interface = new INTERFACE[1];
                    }


                    /********************************************************************************************/


                    /********************************************************************************************/
                   /* device_container_NSA[0].device.DEVICE_ID = 1;
                    device_container_NSA[0].device.DEVICE_NAME = "LTE_EPC_" + Convert.ToString(1);
                    device_container_NSA[0].device.DEVICE_TYPE = "LTE_EPC";
                    device_container_NSA[0].device.INTERFACE_COUNT = 0;

                    device_container_NSA[0].pos_3d.X_OR_LON = epc_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = epc_y0;

                    device_container_NSA[0]._interface = new INTERFACE[max__epc_interface];*/

                    int NSA_k = 1; int epc_last_interface = 0;
                    int enb_last_interface = 0, enb_r, idd = 0;

                    string ip3x, ip1_3x;
                    for (; i < (max_epc + max_eNB + L2_Switch + max_router + max_node + max_gnb); i++)
                    {

                        // epc_last_interface = device_container[total_device - 1].device.INTERFACE_COUNT;
                        ipv4_count = 0;
                        ip3x = addNet.next_ip_1(ipv4_count, 2);
                        device_container_NSA[0]._interface[epc_last_interface].ID = 1;
                        device_container_NSA[0]._interface[epc_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[0]._interface[epc_last_interface].IP_ADDRESS = ip3x;
                        device_container_NSA[0]._interface[epc_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[0]._interface[epc_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[0]._interface[epc_last_interface].INTERFACE_TYPE = "LTE_NR";
                        device_container_NSA[0]._interface[epc_last_interface].CONNECTED_TO = "";
                        epc_last_interface++;
                                               
                        ipv4_count = 0;
                        ip3x = addNet.next_ip_1(ipv4_count, 6);
                        device_container_NSA[0]._interface[epc_last_interface].ID = epc_last_interface + 1;
                        device_container_NSA[0]._interface[epc_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[0]._interface[epc_last_interface].IP_ADDRESS = ip3x;
                        device_container_NSA[0]._interface[epc_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[0]._interface[epc_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[0]._interface[epc_last_interface].INTERFACE_TYPE = "LTE";
                        device_container_NSA[0]._interface[epc_last_interface].CONNECTED_TO = "";
                        epc_last_interface++;
                    
                        device_container_NSA[0]._interface[epc_last_interface].ID = epc_last_interface + 1;
                        device_container_NSA[0]._interface[epc_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[0]._interface[epc_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        ip1_3x = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[0]._interface[epc_last_interface].IP_ADDRESS = ip1_3x;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[0]._interface[epc_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[0]._interface[epc_last_interface].CONNECTED_TO = "";
                        device_container_NSA[0]._interface[epc_last_interface].INTERFACE_TYPE = "WAN";
                        epc_last_interface++;



                        //link EPC with gnb                             
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "gNB_EPC";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 1;
                        link[link_count].link_device[0].NAME = "LTE_EPC_" + Convert.ToString(1);
                        link[link_count].link_device[0].INTERFACE_ID = 1;
                        link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd;
                        link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd);
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link_count++;

                        //L2_Switch and gNB link
                        link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "L2_Swtich_gNB";
                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].link_device[0].DEVICE_ID = NSA_gnb_idd;
                            link[link_count].link_device[0].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd);
                            link[link_count].link_device[0].INTERFACE_ID = 2;
                            link[link_count].link_device[1].DEVICE_ID = 2;
                            link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(2);
                            link[link_count].link_device[1].INTERFACE_ID = 1;
                            link_count++;
                        //link EPC with enb                             
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_EPC";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 1;
                        link[link_count].link_device[0].NAME = "LTE_EPC_" + Convert.ToString(1);
                        link[link_count].link_device[0].INTERFACE_ID = 2;
                        link[link_count].link_device[1].DEVICE_ID = i + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(i + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link_count++;
                        //L2_Switch and eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "L2_Swtich_eNB";
                        link[link_count].link_device = new LINK_DEVICE[max_eNB + 1];
                        link[link_count].link_device[0].DEVICE_ID = i + 1;
                        link[link_count].link_device[0].NAME = "eNB_" + Convert.ToString(i + 1);
                        link[link_count].link_device[0].INTERFACE_ID = 2;
                        link[link_count].link_device[1].DEVICE_ID = 2;
                        link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(2);
                        link[link_count].link_device[1].INTERFACE_ID = 2;
                        link_count++;


                        //L2_Switch

                        for (enb_r = 0; enb_r < max_eNB; enb_r++)
                        {
                            while (idd < max_gnb)
                            {
                                device_container_NSA[1].device.DEVICE_ID = 2;
                                device_container_NSA[1].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(2);
                                device_container_NSA[1].device.DEVICE_TYPE = "L2_Switch_gNB";
                                device_container_NSA[1].device.INTERFACE_COUNT = max_eNB + max_gnb;
                                device_container_NSA[1]._interface = new INTERFACE[max_L2_Swtich_interface_NSA];

                                device_container_NSA[1]._interface[enb_last_interface].ID = enb_last_interface + 1;
                                device_container_NSA[1]._interface[enb_last_interface].DEFAULT_GATEWAY = "";
                                device_container_NSA[1]._interface[enb_last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 3);
                                mac = addNet.next_mac(mac);
                                device_container_NSA[1]._interface[enb_last_interface].MAC_ADDRESS = mac;
                                device_container_NSA[1]._interface[enb_last_interface].SUBNET_MASK = addNet.subnet_mask();
                                device_container_NSA[1]._interface[enb_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(NSA_gnb_idd);
                                device_container_NSA[1]._interface[enb_last_interface].INTERFACE_TYPE = "ETHERNET";
                                enb_last_interface++;
                                idd++;
                            }

                                    device_container_NSA[1]._interface[enb_last_interface].ID = enb_last_interface + 1;
                                    device_container_NSA[1]._interface[enb_last_interface].DEFAULT_GATEWAY = "";
                                    device_container_NSA[1]._interface[enb_last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 1);
                                    mac = addNet.next_mac(mac);
                                    device_container_NSA[1]._interface[enb_last_interface].MAC_ADDRESS = mac;
                                    device_container_NSA[1]._interface[enb_last_interface].SUBNET_MASK = addNet.subnet_mask();
                                    device_container_NSA[1]._interface[enb_last_interface].CONNECTED_TO = "eNB_" + Convert.ToString(i + 1); 
                                    device_container_NSA[1]._interface[enb_last_interface].INTERFACE_TYPE = "ETHERNET";
                                    
                                    enb_last_interface++;
                     
                 
                        }
                       

                        //Link EPC with router
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].link_type = "EPC_Router_Router";
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_device[0].DEVICE_ID = NSA_router_id_1;
                        link[link_count].link_device[0].INTERFACE_ID = 1;
                        link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(NSA_router_id_1);
                        link[link_count].link_device[1].DEVICE_ID = 1;
                        link[link_count].link_device[1].INTERFACE_ID = 3;
                        link[link_count].link_device[1].NAME = "LTE_EPC_" + Convert.ToString(1);
                        link_count++;

                        //
                        

                        //

                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "eNB_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "LTE_eNB";
                        //device_container[i].device.INTERFACE_COUNT = 3;

                            device_container_NSA[i]._interface = new INTERFACE[3];


                            device_container_NSA[i]._interface[2].ID = 3;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[i]._interface[2].MAC_ADDRESS = mac;
                            device_container_NSA[i]._interface[2].INTERFACE_TYPE = "LTE";

                            device_container_NSA[i]._interface[1].ID = 2;
                        ipv4_count = 0;
                        device_container_NSA[i]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 7);
                        mac = addNet.next_mac(mac);
                            device_container_NSA[i]._interface[1].MAC_ADDRESS = mac;
                            device_container_NSA[i]._interface[1].INTERFACE_TYPE = "5G_XN";

                            device_container_NSA[i]._interface[0].ID = 1;
                        device_container_NSA[i]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, 5); 
                        mac = addNet.next_mac(mac);
                            device_container_NSA[i]._interface[0].MAC_ADDRESS = mac;
                            device_container_NSA[i]._interface[0].INTERFACE_TYPE = "LTE_S1";
                      
                          


                        double theta = i * gnb_angle_increment;
                        device_container_NSA[i].pos_3d.X_OR_LON = enb_x0 + gnb_radius * Math.Cos(Math.PI * (theta / 180.0));
                        device_container_NSA[i].pos_3d.Y_OR_LAT = enb_y0 + gnb_radius * Math.Sin(Math.PI * (theta / 180.0));
                        double low_angle_NSA = theta - (num_ue_per_enb_NSA * ue_angle_increment / 2.0);

                        //Link gNB  with Ue
                       
                            link_device_count = link[link_count].DEVICE_COUNT = 0;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "gNB_UE";
                            link[link_count].link_device = new LINK_DEVICE[num_ue_per_gnb + 1];
                            link[link_count].link_device[link_device_count].DEVICE_ID = NSA_gnb_idd;
                            link[link_count].link_device[link_device_count].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 3;
                            link_device_count++;
             
                        //gnb with ue
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = NSA_k + max_router + max_node + max_gnb + max_eNB + L2_Switch + max_epc;
                            if (ue_id - 1 >= total_device_NSA)
                                break;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                            link_device_count++;
                            NSA_k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;

                       
                            link_device_count = link[link_count].DEVICE_COUNT = 0;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "eNB_UE";
                            link[link_count].link_device = new LINK_DEVICE[num_ue_per_enb_NSA + 1];
                            link[link_count].link_device[link_device_count].DEVICE_ID = i + 1;
                            link[link_count].link_device[link_device_count].NAME = "eNB_" + Convert.ToString(i + 1);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 3;
                            link_device_count++;
   

                        // this block sets the attributes,positions of all the enb and ue
                        k = 1;
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = k + max_router + max_node + max_gnb + max_eNB + L2_Switch + max_epc;
                            if (ue_id - 1 >= total_device_NSA)
                                break;

                            device_container_NSA[ue_id - 1].device.DEVICE_ID = ue_id;
                            device_container_NSA[ue_id - 1].device.DEVICE_NAME = "UE_" + Convert.ToString(ue_id);
                            device_container_NSA[ue_id - 1].device.DEVICE_TYPE = "LTE_NR_UE";
                           // device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[ue_id - 1].device.WIRESHARK_OPTION = "Disable";
                            device_container_NSA[ue_id - 1]._interface = new INTERFACE[2];

                            double theta1 = low_angle_NSA + l * ue_angle_increment;
                            device_container_NSA[ue_id - 1].pos_3d.X_OR_LON = enb_x0 + ue_radius * Math.Cos(Math.PI * (theta1 / 180.0));
                            device_container_NSA[ue_id - 1].pos_3d.Y_OR_LAT = enb_y0 + ue_radius * Math.Sin(Math.PI * (theta1 / 180.0));
                            ipv4_count = 0;
                            int last_interface = device_container_NSA[ue_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[ue_id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[ue_id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip3x;
                            device_container_NSA[ue_id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, l + 10);
                            device_container_NSA[ue_id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface].INTERFACE_TYPE = "LTE";

                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].ID = last_interface + 2;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].DEFAULT_GATEWAY = ip3x;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, l + 10);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].INTERFACE_TYPE = "5G_RAN";

                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 2;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 1;
                            link_device_count++;
                            k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;
                        device_container_NSA[i].device.INTERFACE_COUNT = 3;// enb_last_interface + 1;
                        device_container_NSA[0].device.INTERFACE_COUNT = epc_last_interface;
                        epc_last_interface++;
                    }
                    /**********************************************************************************************/

                    /**********************************************************************************************/
                    //this block sets the attributes,position of first_router and  L2_Switch and enb

                    device_container_NSA[0].pos_3d.X_OR_LON = epc_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = epc_y0;


                    device_container_NSA[1].pos_3d.X_OR_LON = L2_Switch_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = L2_Switch_y0;

                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    idd = 0;
                    while (idd < max_gnb)
                    {
                        octate_4 += 1;
                        ipv4_count = 0;
                        device_container_NSA[NSA_gnb_idd - 1]._interface[0].ID = 1;
                        mac = addNet.next_mac(mac);
                   
                        device_container_NSA[NSA_gnb_idd - 1]._interface[0].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4);
                        device_container_NSA[NSA_gnb_idd - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd - 1]._interface[0].INTERFACE_TYPE = "LTE_S1";

                       
                        device_container_NSA[NSA_gnb_idd - 1]._interface[1].ID = 2;
                        device_container_NSA[NSA_gnb_idd - 1]._interface[1].DEFAULT_GATEWAY = "";
                        device_container_NSA[NSA_gnb_idd - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4 + 2);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd - 1]._interface[1].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd - 1]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(2);
                        device_container_NSA[NSA_gnb_idd - 1]._interface[1].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[NSA_gnb_idd - 1]._interface[2].ID = 3;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd - 1]._interface[2].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd - 1]._interface[2].INTERFACE_TYPE = "5G_RAN";

                        device_container_NSA[NSA_gnb_idd - 1].pos_3d.X_OR_LON = gnbNSA_x0;
                        device_container_NSA[NSA_gnb_idd - 1].pos_3d.Y_OR_LAT = gnbNSA_y0;

                        device_container_NSA[NSA_gnb_idd - 1].device.INTERFACE_COUNT = 3;
                        idd++;
                    }
            
                    device_container_NSA[NSA_router_id_1 - 1].level.r = 0.0;
                    double NSA_theta0 = device_container_NSA[NSA_router_id_1 - 1].level.theta = 0.0;
                    double NSA_level0 = device_container_NSA[NSA_router_id_1 - 1].level.level = 0;
                    double NSA_increment0 = device_container_NSA[NSA_router_id_1 - 1].level.increment = (360.0 / Math.Pow(branch, NSA_level0 + 1));
                    device_container_NSA[NSA_router_id_1 - 1].level.low_angle = NSA_theta0 - (branch * 1.0) * NSA_increment0 / 2.0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    /***********************************************************************************************/


                    /***********************************************************************************************/
                    //this block sets the attributes positions and interfaces ,link of all the routers
                    i = max_epc + max_eNB + max_gnb + L2_Switch - 1;
                    for (; i < max_epc + max_eNB + max_gnb + L2_Switch + max_router; i++)
                    {
                        int id = device_container_NSA[i].device.DEVICE_ID, index = 2;
                        int n_id_ = (id - 1 - (max_epc + max_eNB + max_gnb + L2_Switch)) * branch + index;
                        not_leaf_node = id - 1;
                        if (n_id_ > max_router)
                            break;
                        int last_interface = device_container_NSA[i].device.INTERFACE_COUNT;
                        POS_3D pos_3d = device_container_NSA[i].pos_3d;

                        double r = device_container_NSA[i].level.r;
                        double theta = device_container_NSA[i].level.theta;
                        int level = device_container_NSA[i].level.level;
                        double NSA_low_angle = device_container_NSA[i].level.low_angle;
                        double increment = device_container_NSA[i].level.increment;
                        j = 0;
                        while (j < branch)
                        {
                            int n_id = (id - 1) * branch + (index++);
                            if (n_id > max_router)
                                break;

                            device_container_NSA[i]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[i]._interface[last_interface].DEFAULT_GATEWAY = "";
                            device_container_NSA[i]._interface[last_interface].IP_ADDRESS = addNet.next_ip(++ipv4_count, 1);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[i]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[i]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[i]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[i]._interface[last_interface].INTERFACE_TYPE = "WAN";

                            int n_last_interface = device_container_NSA[n_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[n_id - 1]._interface[n_last_interface].ID = n_last_interface + 1;
                            device_container_NSA[n_id - 1]._interface[n_last_interface].DEFAULT_GATEWAY = "";
                            device_container_NSA[n_id - 1]._interface[n_last_interface].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[n_id - 1]._interface[n_last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[n_id - 1]._interface[n_last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[n_id - 1]._interface[n_last_interface].CONNECTED_TO = "";
                            device_container_NSA[n_id - 1]._interface[n_last_interface].INTERFACE_TYPE = "WAN";



                            double r1 = device_container_NSA[n_id - 1].level.r = r + offset_radius;
                            double level1 = device_container_NSA[n_id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[n_id - 1].level.theta = NSA_low_angle + j * increment;
                            double increment1 = device_container_NSA[n_id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[n_id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[n_id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[n_id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "EPC_Router_Router";
                            link[link_count].link_device[0].DEVICE_ID = id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(id);
                            link[link_count].link_device[1].DEVICE_ID = n_id;
                            link[link_count].link_device[1].INTERFACE_ID = n_last_interface + 1;
                            link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(n_id);
                            device_container_NSA[n_id - 1].device.INTERFACE_COUNT = n_last_interface + 1;
                            link_count++;
                            last_interface++;
                            j++;
                        }
                        //device_container_NSA[i].device.INTERFACE_COUNT = last_interface;
                    }
                    /*************************************************************************************************/

                    //Console.WriteLine(not_leaf_node);
                    //Console.ReadLine();

                    /************************************************************************************************/
                    // this block of code sets the sttributes,positions,interfaces,and link(to router) of all the wirednodes
                    i = max_epc + max_eNB + max_gnb + L2_Switch + max_router;
                    int max_node_temp = max_node;
                    while (max_node_temp != 0)
                    {
                        for (j = not_leaf_node; j < max_epc + max_eNB + max_gnb + L2_Switch + max_router; j++)
                        {
                            int router_id = j;
                            int id = device_container_NSA[i - 1].device.DEVICE_ID;
                            int last_interface = device_container_NSA[id - 1].device.INTERFACE_COUNT;
                            int router_last_interface = device_container_NSA[router_id - 1].device.INTERFACE_COUNT;
                            POS_3D pos_3d = device_container_NSA[router_id - 1].pos_3d;

                            double r = device_container_NSA[router_id - 1].level.r;
                            double theta = device_container_NSA[router_id - 1].level.theta;
                            int level = device_container_NSA[router_id - 1].level.level;
                            double NSA_low_angle = device_container_NSA[router_id - 1].level.low_angle;
                            double increment = device_container_NSA[router_id - 1].level.increment;




                            device_container_NSA[router_id - 1]._interface[router_last_interface].ID = router_last_interface + 1;
                            device_container_NSA[router_id - 1]._interface[router_last_interface].DEFAULT_GATEWAY = "";
                            ip1_3x = addNet.next_ip(++ipv4_count, 2);
                            device_container_NSA[router_id - 1]._interface[router_last_interface].IP_ADDRESS = ip1_3x;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface].INTERFACE_TYPE = "WAN";

                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].ID = router_last_interface + 2;
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].DEFAULT_GATEWAY = "";
                            ip1_3x = addNet.next_ip(++ipv4_count, 1);
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].IP_ADDRESS = ip1_3x;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface + 1].INTERFACE_TYPE = "ETHERNET";
                            router_last_interface++;

                            device_container_NSA[id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip1_3x;
                            device_container_NSA[id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[id - 1]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[id - 1]._interface[last_interface].INTERFACE_TYPE = "ETHERNET";


                            double r1 = device_container_NSA[id - 1].level.r = r + offset_radius;
                            //Console.WriteLine(r);
                            //Console.WriteLine(r1);
                            double level1 = device_container_NSA[id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[id - 1].level.theta = NSA_low_angle + (router_last_interface - 1) * increment;
                            double increment1 = device_container_NSA[id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));


                            //device_container[id - 1].pos_3d.X_OR_LON = (pos_3d.X_OR_LON + 0.1);
                            //device_container[id - 1].pos_3d.Y_OR_LAT = (pos_3d.Y_OR_LAT + 0.1);

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "Wired_Router";
                            link[link_count].link_device[1].DEVICE_ID = id;
                            link[link_count].link_device[1].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[1].NAME = "Wired_Node_" + Convert.ToString(id);
                            link[link_count].link_device[0].DEVICE_ID = router_id;
                            link[link_count].link_device[0].INTERFACE_ID = router_last_interface + 1;
                            link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(router_id);


                            device_container_NSA[id - 1].device.INTERFACE_COUNT = last_interface + 1;
                            device_container_NSA[router_id - 1].device.INTERFACE_COUNT = router_last_interface + 1;

                            link_count++;
                            i++;
                            max_node_temp--;
                            if (max_node_temp == 0)
                                break;
                        }
                    }
                }

/*******************************************************************************************************************************/
                else if(args[1] == "OPTION_4")
                {
                    device_container_NSA = new DEVICE_CONTAINER[total_device_NSA_4];
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    int NSA_k = 1;
                    int e_idd;
                    int octate_4th;
                    int r = 0;
                    string ip_upf;
                    string ip_upf_r;
                   
                    int eNb_idd = max_5G_core_devices + max_eNB + max_gnb + 1;
                    //ADD first UMF
                    device_container_NSA[0].device.DEVICE_ID = 1;
                    device_container_NSA[0].device.DEVICE_NAME = "UPF_" + Convert.ToString(1);
                    device_container_NSA[0].device.DEVICE_TYPE = "UPF";
                    device_container_NSA[0].device.INTERFACE_COUNT = max_UPF_interface;
                    device_container_NSA[0]._interface = new INTERFACE[max_UPF_interface];

                    device_container_NSA[0].pos_3d.X_OR_LON = UPF_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = UPF_y0;

                    //Add SMF

                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;
                    device_container_NSA[1].device.DEVICE_ID = 2;
                    device_container_NSA[1].device.DEVICE_NAME = "SMF_" + Convert.ToString(2);
                    device_container_NSA[1].device.DEVICE_TYPE = "SMF";
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;
                    device_container_NSA[1]._interface = new INTERFACE[max_SMF_interface];
                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;

                    //ADD first AMF
                    device_container_NSA[2].device.DEVICE_ID = 3;
                    device_container_NSA[2].device.DEVICE_NAME = "AMF_" + Convert.ToString(3);
                    device_container_NSA[2].device.DEVICE_TYPE = "AMF";
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    device_container_NSA[2].pos_3d.X_OR_LON = AMF_x0;
                    device_container_NSA[2].pos_3d.Y_OR_LAT = AMF_y0;
                    device_container_NSA[2]._interface = new INTERFACE[max_AMF_interface];


      /*****************************************************************************************************/
                    //SMF interface  with AMF
                    octate_4th = 1;
                    device_container_NSA[1]._interface[0].ID = 1;
                    device_container_NSA[1]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[1]._interface[0].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;

                    //AMF interface  with SMF
                    device_container_NSA[2]._interface[0].ID = 1;
                    device_container_NSA[2]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[2]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[2]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);


                    //interface of SMF with UPF
                    device_container_NSA[1]._interface[1].ID = 2;
                    device_container_NSA[1]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[1].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[1]._interface[1].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                    //UPF interface with SMF
                    device_container_NSA[0]._interface[0].ID = 1;
                    device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip(ipv4_count, 1);
                    device_container_NSA[0]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[0].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[0]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);
                    device_container_NSA[0].device.INTERFACE_COUNT = 3;

                  

                    device_container_NSA[0]._interface[1].ID = 2;
                  ip_upf = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[1].IP_ADDRESS = ip_upf;
                    device_container_NSA[0]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[1].INTERFACE_TYPE = "5G_N3";
                    device_container_NSA[0]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(4);

                    ip_upf_r = addNet.next_ip(++ipv4_count, 1);
                    device_container_NSA[0]._interface[2].ID = 3;
                  
                    device_container_NSA[0]._interface[2].IP_ADDRESS = ip_upf_r;
                    device_container_NSA[0]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[2].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[2].INTERFACE_TYPE = "5G_N6";
                    device_container_NSA[0]._interface[2].CONNECTED_TO = "Router_" + Convert.ToString(NSA_router_id_1);//router id




                    octate_4th += 2;
                    //AMF interface with L2_Switch
                    ipv4_count = 0;
                    device_container_NSA[2]._interface[1].ID = 2;
                    device_container_NSA[2]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[2]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                    device_container_NSA[2]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    //L2_Switch_4

                    device_container_NSA[3].device.DEVICE_ID = 4;
                    device_container_NSA[3].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(4);
                    device_container_NSA[3].device.DEVICE_TYPE = "L2_Switch_UPF";
                    device_container_NSA[3].device.INTERFACE_COUNT = max_gnb + 1;
                    device_container_NSA[3].pos_3d.X_OR_LON = L2_Switch_4_x0;
                    device_container_NSA[3].pos_3d.Y_OR_LAT = L2_Switch_4_y0;
                    device_container_NSA[3]._interface = new INTERFACE[max_switch_interface];

                    r = 0;
                    while (r < max_gnb)
                    {
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 1;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);
                        L2_switch_4_last_interface++;

                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 2;
                     device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_4_last_interface++;
                        r++;
                    }

                    //attributes position of L2_Switches_5

                    device_container_NSA[4].device.DEVICE_ID = 5;
                    device_container_NSA[4].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[4].device.DEVICE_TYPE = "L2_Switch_AMF";
                    device_container_NSA[4].device.INTERFACE_COUNT = max_gnb + 1;
                    device_container_NSA[4].pos_3d.X_OR_LON = L2_Switch_5_x0;
                    device_container_NSA[4].pos_3d.Y_OR_LAT = L2_Switch_5_y0;
                    device_container_NSA[4]._interface = new INTERFACE[max_switch_interface];
                    r = 0;

                        device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                        L2_switch_5_last_interface++;
                    while (r < max_gnb)
                    {
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_5_last_interface++;
                        r++;
                    }


                    //attributes position of L2_Switches_6
                    device_container_NSA[5].device.DEVICE_ID = 6;
                    device_container_NSA[5].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(6);
                    device_container_NSA[5].device.DEVICE_TYPE = "L2_Switch_gNB";
                    device_container_NSA[5].device.INTERFACE_COUNT = max_gnb + max_eNB;
                    device_container_NSA[5].pos_3d.X_OR_LON = L2_Switch_6_x0;
                    device_container_NSA[5].pos_3d.Y_OR_LAT = L2_Switch_6_y0; 
                    device_container_NSA[5]._interface = new INTERFACE[max_gnb + max_eNB];

                    r = 0;
                    while (r < max_gnb)
                    {
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].ID = 1;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].IP_ADDRESS = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_6_last_interface++;
                        r++;
                    }

                    //Links
                    //SMF with AMF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_AMF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 2;
                    link[link_count].link_device[0].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[0].INTERFACE_ID = 1;

                    link[link_count].link_device[1].DEVICE_ID = 3;
                    link[link_count].link_device[1].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;


                    //SMF with UPF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_UPF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[1].DEVICE_ID = 2;
                    link[link_count].link_device[1].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[1].INTERFACE_ID = 2;

                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 1;
                    link_count++;

                    //Connection UPF with L2_Switch_4
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "UPF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 2;

                    link[link_count].link_device[1].DEVICE_ID = 4;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(4);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;

                    //Connection AMF with L2_Switch_5
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "AMF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 3;
                    link[link_count].link_device[0].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[0].INTERFACE_ID = 2;


                    link[link_count].link_device[1].DEVICE_ID = 5;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(5);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;


                    int upf_last_interface = 0;
                    int NSA_gnb_idd_1 = max_5G_core_devices + max_gnb;//max gNB check
                    string ip;
                    octate_4th += 2;
                    ipv4_count = 0;
                    int check = 1;
                    while (NSA_gnb_idd_4x - 1 < NSA_gnb_idd_1)
                    {
                        
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_ID = NSA_gnb_idd_4x;
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_TYPE = "LTE_gNB";
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.INTERFACE_COUNT = 4;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface = new INTERFACE[4];

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].ID = 1;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].INTERFACE_TYPE = "5G_N3";
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].CONNECTED_TO = "L2_Switch_" + Convert.ToString(4);
                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].ID = 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].MAC_ADDRESS = mac;

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);

                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].ID = 3;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].CONNECTED_TO = "L2_Switch_" + Convert.ToString(6);

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[3].ID = 4;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[3].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[3].INTERFACE_TYPE = "5G_RAN";
                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.X_OR_LON = gnbNSA_x0;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.Y_OR_LAT = gnbNSA_y0;
                        upf_last_interface++;
                        NSA_gnb_idd_4x++;
                        

                    }

                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    //this block set the  attributes,positions of all L2_Switch with gNB

                    //L2_Switch_5 connected with gNB
                    while (L2_switch_5_last_interface >= 2)
                        {
                            if (check > max_gnb)
                                break;
                            device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].ID = L2_switch_5_last_interface;
                                device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].DEFAULT_GATEWAY = "";
                                device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                                ip = addNet.next_ip(++ipv4_count, 1);
                                device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].IP_ADDRESS = ip;
                                mac = addNet.next_mac(mac);
                                device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].MAC_ADDRESS = mac;
                                device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].CONNECTED_TO = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + check - 1);
                                device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                               
                            
                            L2_switch_5_last_interface++;
                        NSA_gnb_idd_4x++;
                            check++;

                        }
                        check = 1;
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    //L2_Switch_6 connrcted with gNB
                    while (L2_switch_6_last_interface >= 1)
                    {
                        if (check > max_gnb)
                            break;
                             
                                            
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].ID = L2_switch_6_last_interface;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].DEFAULT_GATEWAY = "";
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            ip = addNet.next_ip(++ipv4_count, 1);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].CONNECTED_TO = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + check - 1);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                            L2_switch_6_last_interface++;
                        NSA_gnb_idd_4x++;
                            check++;
                       

                    }
                        check = 1;
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    //L2_Switch_4 connected with gNB
                    while (L2_switch_4_last_interface >= 2)
                        {
                            if (check > max_gnb)
                                break;
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].ID = L2_switch_4_last_interface;
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].DEFAULT_GATEWAY = "";
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            ip = addNet.next_ip(++ipv4_count, 1);
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].CONNECTED_TO = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + check - 1);
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                            L2_switch_4_last_interface++;
                        NSA_gnb_idd_4x++;
                            check++;

                        }
                        check = 1;
                    NSA_gnb_idd_4x = max_5G_core_devices;
                    while (NSA_gnb_idd_4x < NSA_gnb_idd_1)
                    {

                        //L2_switch link_4 connection with gNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "GNB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 4;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(4);
                        link[link_count].link_device[0].INTERFACE_ID = 2; //
                        link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x + 1;
                        link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1;//
                        link_count++;

                        //L2_switch link_5 connection with gNB

                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "GNB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 5;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(5);
                        link[link_count].link_device[0].INTERFACE_ID = 2;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x + 1;
                        link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 2;//
                        link_count++;

                        //L2_switch_6 link connection with gNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "GNB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 6;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(6);
                        link[link_count].link_device[0].INTERFACE_ID = 1;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x + 1;
                        link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 3;//
                        link_count++;
                        NSA_gnb_idd_4x++;


                    }

                    link_device_count = link[link_count].DEVICE_COUNT = 0;
                    double theta;
                    e_idd = max_5G_core_devices + max_gnb + 1;
                
                    r = 0;
                    ipv4_count = 0;
                    while (e_idd < eNb_idd)
                    {
                        device_container_NSA[e_idd - 1].device.DEVICE_ID = e_idd;
                        device_container_NSA[e_idd - 1].device.DEVICE_NAME = "eNB_" + Convert.ToString(e_idd);
                        device_container_NSA[e_idd - 1].device.DEVICE_TYPE = "LTE_eNB";

                        device_container_NSA[e_idd - 1]._interface = new INTERFACE[2];


                        device_container_NSA[e_idd - 1]._interface[0].ID = 1;
                        device_container_NSA[e_idd - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[0].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[0].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[e_idd - 1]._interface[1].ID = 2;
                      
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[1].MAC_ADDRESS = mac;
                        device_container_NSA[e_idd - 1]._interface[1].INTERFACE_TYPE = "LTE";

                      
                        while (L2_switch_6_last_interface >= 1)
                        {
                            if (check > max_eNB)
                                break;
                          device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].ID = L2_switch_6_last_interface;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].DEFAULT_GATEWAY = "";
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            ip = addNet.next_ip_1(ipv4_count, octate_4th);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].CONNECTED_TO = "eNB_" + Convert.ToString(e_idd + r);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                            L2_switch_6_last_interface++;
                            check++;

                        }
                    
                        theta = e_idd * gnb_angle_increment;
                        device_container_NSA[e_idd - 1].pos_3d.X_OR_LON = enb_x0 + gnb_radius * Math.Cos(Math.PI * (theta / 180.0));
                        device_container_NSA[e_idd - 1].pos_3d.Y_OR_LAT = enb_y0 + gnb_radius * Math.Sin(Math.PI * (theta / 180.0));
                        double low_angle_NSA = theta - (num_ue_per_enb_NSA * ue_angle_increment / 2.0);

                        //Link enb and L2_switch
                        //L2_Switch and eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "L2_Swtich_eNB";
                        link[link_count].link_device = new LINK_DEVICE[max_eNB + 1];
                        link[link_count].link_device[1].DEVICE_ID = eNb_idd - 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(eNb_idd - 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link[link_count].link_device[0].DEVICE_ID = 6;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(6);
                        link[link_count].link_device[0].INTERFACE_ID = 2;
                        link_count++;

                        //Ue link 
                        //Link gNB  with Ue

                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "gNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_gnb + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = NSA_gnb_idd_4x;
                        link[link_count].link_device[link_device_count].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x );
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 4;
                        link_device_count++;

                        //gnb with ue
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = NSA_k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 1;
                            link_device_count++;
                            NSA_k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;


                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_enb_NSA + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = e_idd;
                        link[link_count].link_device[link_device_count].NAME = "eNB_" + Convert.ToString(e_idd);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                        link_device_count++;

                        k = 1;
                      
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;
                            ipv4_count = 0;
                            device_container_NSA[ue_id - 1].device.DEVICE_ID = ue_id;
                            device_container_NSA[ue_id - 1].device.DEVICE_NAME = "UE_" + Convert.ToString(ue_id);
                            device_container_NSA[ue_id - 1].device.DEVICE_TYPE = "LTE_NR_UE";
                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[ue_id - 1].device.WIRESHARK_OPTION = "Disable";
                            device_container_NSA[ue_id - 1]._interface = new INTERFACE[2];

                            double theta1 = low_angle_NSA + l * ue_angle_increment;
                            device_container_NSA[ue_id - 1].pos_3d.X_OR_LON = enb_x0 + ue_radius * Math.Cos(Math.PI * (theta1 / 180.0));
                            device_container_NSA[ue_id - 1].pos_3d.Y_OR_LAT = enb_y0 + ue_radius * Math.Sin(Math.PI * (theta1 / 180.0));

                            int last_interface = device_container_NSA[ue_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[ue_id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[ue_id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th +l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface].INTERFACE_TYPE = "5G_RAN";

                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].ID = last_interface + 2;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th  + l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].INTERFACE_TYPE = "LTE";

                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 2;

                          link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                           link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                            link_device_count++;
                            k++;
                        }
                      link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;
                        device_container_NSA[e_idd - 1].device.INTERFACE_COUNT =  2; 
                        e_idd++;
                        r++;

                    }
 
                    i = NSA_gnb_idd_4x + max_eNB+ max_gnb + max_ue - 1;
                    //Add router
                    for (; i <(NSA_gnb_idd_4x + max_eNB + max_ue + max_router); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Router_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "ROUTER";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_router_interface];
                    }

                    //Add node
                    for (; i < (NSA_gnb_idd_4x + max_eNB+max_gnb + max_ue + max_router+ max_node - 1); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Wired_Node_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "WIREDNODE";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";
                        device_container_NSA[i]._interface = new INTERFACE[1];
                    }



                    /*-----------------------------------------------------------------------------------------------------*/
                    // this block sets the attributes, position of first_router and
                    NSA_router_id_1 = NSA_gnb_idd_4x + max_eNB + max_ue + max_router;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    upf_last_interface = device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT;
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                    device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip_2(++ipv4_count, 2);
                    device_container_NSA[0]._interface[1].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                    device_container_NSA[0]._interface[2].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "SERIAL";
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);
                    
                    upf_last_interface++;

                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "ETHERNET";
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "Wired_Node_" + Convert.ToString(NSA_router_id_1 + max_router);
                    device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT = upf_last_interface + 1;


                    //Router link with UPF
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].link_type = "UPF_Router";
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_device[1].DEVICE_ID = NSA_router_id_1;
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(NSA_router_id_1);
                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].INTERFACE_ID = 3;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link_count++;



                    device_container_NSA[NSA_router_id_1 - 1].level.r = 0.0;
                    theta0 = device_container_NSA[NSA_router_id_1 - 1].level.theta = 0.0;
                    level0 = device_container_NSA[NSA_router_id_1 - 1].level.level = 0;
                    increment0 = device_container_NSA[NSA_router_id_1 - 1].level.increment = (360.0 / Math.Pow(branch, level0 + 1));
                    device_container_NSA[NSA_router_id_1 - 1].level.low_angle = theta0 - (branch * 1.0) * increment0 / 2.0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    /***********************************************************************************************/
                    /*************************************************************************************************/

                    //Console.WriteLine(not_leaf_node);
                    //Console.ReadLine();

                    /************************************************************************************************/
                    // this block of code sets the sttributes,positions,interfaces,and link(to router) of all the wirednodes
                    i = max_router + max_5G_core_devices + max_gnb+max_eNB + max_ue;
                    // int kii = - 1;//first router id
                    int NSA_max_node_temp = max_node;
                    double r_level;
                   
                    while (NSA_max_node_temp != 0)
                    {
                        for (j = max_5G_core_devices + max_gnb+max_ue+max_eNB; j < i; j++)
                        {
                            int router_id = j + 1;

                            int id = device_container_NSA[i].device.DEVICE_ID;
                            int last_interface = device_container_NSA[i].device.INTERFACE_COUNT;
                            int router_last_interface = device_container_NSA[router_id - 1].device.INTERFACE_COUNT;
                            POS_3D pos_3d = device_container_NSA[router_id - 1].pos_3d;

                            r_level = device_container_NSA[router_id - 1].level.r;
                            theta = device_container_NSA[router_id - 1].level.theta;
                            int level = device_container_NSA[router_id - 1].level.level;
                            low_angle = device_container_NSA[router_id - 1].level.low_angle;
                            double increment = device_container_NSA[router_id - 1].level.increment;



                            
                                device_container_NSA[router_id - 1]._interface[router_last_interface - 1].ID = router_last_interface;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].DEFAULT_GATEWAY = "";

                            device_container_NSA[router_id- 1]._interface[router_last_interface -1].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                             mac = addNet.next_mac(mac);
                            device_container_NSA[router_id- 1]._interface[router_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface -1].INTERFACE_TYPE = "ETHERNET";

                         ip = addNet.next_ip_3(ipv4_count, 1);
                            device_container_NSA[id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                            device_container_NSA[id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[id - 1]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[id - 1]._interface[last_interface].INTERFACE_TYPE = "ETHERNET";


                            double r1 = device_container_NSA[id - 1].level.r = r_level + offset_radius;
                            //Console.WriteLine(r);
                            //Console.WriteLine(r1);
                            double level1 = device_container_NSA[id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[id - 1].level.theta = low_angle + (router_last_interface - 1) * increment;
                            double increment1 = device_container_NSA[id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));


                            //device_container[id - 1].pos_3d.X_OR_LON = (pos_3d.X_OR_LON + 0.1);
                            //device_container[id - 1].pos_3d.Y_OR_LAT = (pos_3d.Y_OR_LAT + 0.1);

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "Wired_Router";
                            link[link_count].link_device[1].DEVICE_ID = id;
                            link[link_count].link_device[1].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[1].NAME = "Wired_Node_" + Convert.ToString(id);
                            link[link_count].link_device[0].DEVICE_ID = router_id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 2;
                            link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(router_id);


                            device_container_NSA[id - 1].device.INTERFACE_COUNT = last_interface + 1;
                            device_container_NSA[router_id - 1].device.INTERFACE_COUNT = router_last_interface;

                            link_count++;
                            i++;
                            router_id++;


                            NSA_max_node_temp--;
                            if (NSA_max_node_temp == 0)
                                break;
                        }
                    }


                }
                /*****************************************************************************************************************/
                else if(args[1] == "OPTION_4a")
                {
                    device_container_NSA = new DEVICE_CONTAINER[total_device_NSA_4];
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    int NSA_k = 1;
                    int e_idd;
                    int octate_4th;
                    int r = 0;
                    string ip_upf;
                    string ip_upf_r;

                    int eNb_idd = max_5G_core_devices + max_eNB + max_gnb + 1;
                    //ADD first UMF
                    device_container_NSA[0].device.DEVICE_ID = 1;
                    device_container_NSA[0].device.DEVICE_NAME = "UPF_" + Convert.ToString(1);
                    device_container_NSA[0].device.DEVICE_TYPE = "UPF";
                    device_container_NSA[0].device.INTERFACE_COUNT = max_UPF_interface;
                    device_container_NSA[0]._interface = new INTERFACE[max_UPF_interface];

                    device_container_NSA[0].pos_3d.X_OR_LON = UPF_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = UPF_y0;

                    //Add SMF

                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;
                    device_container_NSA[1].device.DEVICE_ID = 2;
                    device_container_NSA[1].device.DEVICE_NAME = "SMF_" + Convert.ToString(2);
                    device_container_NSA[1].device.DEVICE_TYPE = "SMF";
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;
                    device_container_NSA[1]._interface = new INTERFACE[max_SMF_interface];
                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;

                    //ADD first AMF
                    device_container_NSA[2].device.DEVICE_ID = 3;
                    device_container_NSA[2].device.DEVICE_NAME = "AMF_" + Convert.ToString(3);
                    device_container_NSA[2].device.DEVICE_TYPE = "AMF";
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    device_container_NSA[2].pos_3d.X_OR_LON = AMF_x0;
                    device_container_NSA[2].pos_3d.Y_OR_LAT = AMF_y0;
                    device_container_NSA[2]._interface = new INTERFACE[max_AMF_interface];


                    /*****************************************************************************************************/
                    //SMF interface  with AMF
                    octate_4th = 1;
                    device_container_NSA[1]._interface[0].ID = 1;
                    device_container_NSA[1]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[1]._interface[0].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;

                    //AMF interface  with SMF
                    device_container_NSA[2]._interface[0].ID = 1;
                    device_container_NSA[2]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[2]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[2]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);


                    //interface of SMF with UPF
                    device_container_NSA[1]._interface[1].ID = 2;
                    device_container_NSA[1]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[1].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[1]._interface[1].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                    //UPF interface with SMF
                    device_container_NSA[0]._interface[0].ID = 1;
                    device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip(ipv4_count, 1);
                    device_container_NSA[0]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[0].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[0]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);
                    device_container_NSA[0].device.INTERFACE_COUNT = 3;



                    device_container_NSA[0]._interface[1].ID = 2;
                    ip_upf = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[1].IP_ADDRESS = ip_upf;
                    device_container_NSA[0]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[1].INTERFACE_TYPE = "5G_N3";
                    device_container_NSA[0]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(4);

                    ip_upf_r = addNet.next_ip(++ipv4_count, 1);
                    device_container_NSA[0]._interface[2].ID = 3;

                    device_container_NSA[0]._interface[2].IP_ADDRESS = ip_upf_r;
                    device_container_NSA[0]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[2].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[2].INTERFACE_TYPE = "5G_N6";
                    device_container_NSA[0]._interface[2].CONNECTED_TO = "Router_" + Convert.ToString(NSA_router_id_1);//router id




                    octate_4th += 2;
                    //AMF interface with L2_Switch
                    ipv4_count = 0;
                    device_container_NSA[2]._interface[1].ID = 2;
                    device_container_NSA[2]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[2]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                    device_container_NSA[2]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    //L2_Switch_4

                    device_container_NSA[3].device.DEVICE_ID = 4;
                    device_container_NSA[3].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(4);
                    device_container_NSA[3].device.DEVICE_TYPE = "L2_Switch_UPF";
                    device_container_NSA[3].device.INTERFACE_COUNT = max_gnb+max_eNB + 1;
                    device_container_NSA[3].pos_3d.X_OR_LON = L2_Switch_4_x0;
                    device_container_NSA[3].pos_3d.Y_OR_LAT = L2_Switch_4_y0;
                    device_container_NSA[3]._interface = new INTERFACE[max_switch_interface_4a];

                    r = 0;
                    while (r < max_gnb)
                    {
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 1;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);
                        L2_switch_4_last_interface++;

                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 2;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_4_last_interface++;
                        r++;
                    }

                    //attributes position of L2_Switches_5

                    device_container_NSA[4].device.DEVICE_ID = 5;
                    device_container_NSA[4].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[4].device.DEVICE_TYPE = "L2_Switch_AMF";
                    device_container_NSA[4].device.INTERFACE_COUNT = max_gnb+max_eNB + 1;
                    device_container_NSA[4].pos_3d.X_OR_LON = L2_Switch_5_x0;
                    device_container_NSA[4].pos_3d.Y_OR_LAT = L2_Switch_5_y0;
                    device_container_NSA[4]._interface = new INTERFACE[max_switch_interface_4a];
                    r = 0;

                    device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                    mac = addNet.next_mac(mac);
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                    L2_switch_5_last_interface++;
                    while (r < max_gnb)
                    {
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_5_last_interface++;
                        r++;
                    }



                    //attributes position of L2_Switches_6
                    device_container_NSA[5].device.DEVICE_ID = 6;
                    device_container_NSA[5].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(6);
                    device_container_NSA[5].device.DEVICE_TYPE = "L2_Switch_gNB";
                    device_container_NSA[5].device.INTERFACE_COUNT = max_gnb;
                    device_container_NSA[5].pos_3d.X_OR_LON = L2_Switch_6_x0;
                    device_container_NSA[5].pos_3d.Y_OR_LAT = L2_Switch_6_y0;
                    device_container_NSA[5]._interface = new INTERFACE[max_gnb];

                    r = 0;
                    while (r < max_gnb)
                    {
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].ID = 1;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].IP_ADDRESS = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_6_last_interface++;
                        r++;
                    }

                    //Links
                    //SMF with AMF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_AMF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 2;
                    link[link_count].link_device[0].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[0].INTERFACE_ID = 1;

                    link[link_count].link_device[1].DEVICE_ID = 3;
                    link[link_count].link_device[1].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;


                    //SMF with UPF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_UPF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[1].DEVICE_ID = 2;
                    link[link_count].link_device[1].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[1].INTERFACE_ID = 2;

                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 1;
                    link_count++;

                    //Connection UPF with L2_Switch_4
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "UPF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 2;

                    link[link_count].link_device[1].DEVICE_ID = 4;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(4);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;

                    //Connection AMF with L2_Switch_5
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "AMF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 3;
                    link[link_count].link_device[0].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[0].INTERFACE_ID = 2;


                    link[link_count].link_device[1].DEVICE_ID = 5;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(5);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;


                    int upf_last_interface = 0;
                    int NSA_gnb_idd_1 = max_5G_core_devices + max_gnb;//max gNB check
                    string ip;
                    octate_4th += 2;
                    ipv4_count = 0;
                    int check = 1;
                    while (NSA_gnb_idd_4x - 1 < NSA_gnb_idd_1)
                    {

                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_ID = NSA_gnb_idd_4x;
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_TYPE = "LTE_gNB";
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.INTERFACE_COUNT = 4;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface = new INTERFACE[4];

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].ID = 1;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].INTERFACE_TYPE = "5G_N3";
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].CONNECTED_TO = "L2_Switch_" + Convert.ToString(4);
                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].ID = 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].MAC_ADDRESS = mac;

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);

                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].ID = 3;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].CONNECTED_TO = "L2_Switch_" + Convert.ToString(6);

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[3].ID = 4;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[3].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[3].INTERFACE_TYPE = "5G_RAN";
                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.X_OR_LON = gnbNSA_x0;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.Y_OR_LAT = gnbNSA_y0;
                        upf_last_interface++;
                        NSA_gnb_idd_4x++;


                    }

                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    //this block set the  attributes,positions of all L2_Switch with gNB

                    //L2_Switch_5 connected with gNB
                    while (L2_switch_5_last_interface >= 2)
                    {
                        if (check > max_gnb)
                            break;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].ID = L2_switch_5_last_interface;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].DEFAULT_GATEWAY = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                        ip = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].MAC_ADDRESS = mac;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].CONNECTED_TO = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + check - 1);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].INTERFACE_TYPE = "ETHERNET";


                        L2_switch_5_last_interface++;
                        NSA_gnb_idd_4x++;
                        check++;

                    }
                    check = 1;
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    //L2_Switch_6 connrcted with gNB
                    while (L2_switch_6_last_interface >= 1)
                    {
                        if (check > max_gnb)
                            break;


                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].ID = L2_switch_6_last_interface;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].DEFAULT_GATEWAY = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                        ip = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].MAC_ADDRESS = mac;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].CONNECTED_TO = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + check - 1);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                        L2_switch_6_last_interface++;
                        NSA_gnb_idd_4x++;
                        check++;


                    }
                    check = 1;
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    //L2_Switch_4 connected with gNB
                    while (L2_switch_4_last_interface >= 2)
                    {
                        if (check > max_gnb)
                            break;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].ID = L2_switch_4_last_interface;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                        ip = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].CONNECTED_TO = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + check - 1);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                        L2_switch_4_last_interface++;
                        NSA_gnb_idd_4x++;
                        check++;

                    }
                    check = 1;
                    int last_link = 0;
                    NSA_gnb_idd_4x = max_5G_core_devices;
                    while (NSA_gnb_idd_4x < NSA_gnb_idd_1)
                    {

                        //L2_switch link_4 connection with gNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "GNB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 4;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(4);
                        link[link_count].link_device[0].INTERFACE_ID = 2 + last_link; //
                        link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x + 1;
                        link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1 +  last_link  ;//
                        link_count++;

                        //L2_switch link_5 connection with gNB

                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "GNB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 5;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(5);
                        link[link_count].link_device[0].INTERFACE_ID = 2 + last_link;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x + 1;
                        link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 2 + last_link;//
                        link_count++;

                        //L2_switch_6 link connection with gNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "GNB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 6;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(6);
                        link[link_count].link_device[0].INTERFACE_ID = 1;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x + 1;
                        link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 3;//
                        link_count++;
                        NSA_gnb_idd_4x++;


                    }

                    link_device_count = link[link_count].DEVICE_COUNT = 0;
                    double theta;
                    e_idd = max_5G_core_devices + max_gnb + 1;

                    r = 0;
                    ipv4_count = 0;
                   
                    while (e_idd < eNb_idd)
                    {
                        device_container_NSA[e_idd - 1].device.DEVICE_ID = e_idd;
                        device_container_NSA[e_idd - 1].device.DEVICE_NAME = "eNB_" + Convert.ToString(e_idd);
                        device_container_NSA[e_idd - 1].device.DEVICE_TYPE = "LTE_eNB";

                        device_container_NSA[e_idd - 1]._interface = new INTERFACE[3];


                        device_container_NSA[e_idd - 1]._interface[0].ID = 1;
                        device_container_NSA[e_idd - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[0].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[0].INTERFACE_TYPE = "5G_N3";
                        octate_4th += 2;
                        device_container_NSA[e_idd - 1]._interface[1].ID = 2;
                        device_container_NSA[e_idd - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[1].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[1].INTERFACE_TYPE = "5G_N1_N2";

                        device_container_NSA[e_idd - 1]._interface[2].ID = 3;

                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[2].MAC_ADDRESS = mac;
                        device_container_NSA[e_idd - 1]._interface[2].INTERFACE_TYPE = "LTE";

                        while (L2_switch_4_last_interface >= 1)
                        {
                            if (check > max_eNB)
                                break;
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].ID = L2_switch_4_last_interface;
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].DEFAULT_GATEWAY = "";
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            ip = addNet.next_ip_1(ipv4_count, octate_4th);
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].CONNECTED_TO = "eNB_" + Convert.ToString(e_idd + r);
                            device_container_NSA[3]._interface[L2_switch_4_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                            L2_switch_4_last_interface++;
                            check++;

                        }
                        check = 1;

                        while (L2_switch_5_last_interface >= 1)
                        {
                            if (check > max_eNB)
                                break;
                            device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].ID = L2_switch_5_last_interface;
                            device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].DEFAULT_GATEWAY = "";
                            device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            ip = addNet.next_ip_1(ipv4_count, octate_4th);
                            device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].CONNECTED_TO = "eNB_" + Convert.ToString(e_idd + r);
                            device_container_NSA[4]._interface[L2_switch_5_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                            L2_switch_5_last_interface++;
                            check++;

                        }

                        theta = e_idd * gnb_angle_increment;
                        device_container_NSA[e_idd - 1].pos_3d.X_OR_LON = enb_x0 + gnb_radius * Math.Cos(Math.PI * (theta / 180.0));
                        device_container_NSA[e_idd - 1].pos_3d.Y_OR_LAT = enb_y0 + gnb_radius * Math.Sin(Math.PI * (theta / 180.0));
                        double low_angle_NSA = theta - (num_ue_per_enb_NSA * ue_angle_increment / 2.0);

                        //Link enb and L2_switch
                        //L2_Switch and eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "L2_Swtich_eNB";
                        link[link_count].link_device = new LINK_DEVICE[max_eNB + 1];
                        link[link_count].link_device[1].DEVICE_ID = eNb_idd - 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(eNb_idd - 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link[link_count].link_device[0].DEVICE_ID = 4;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(4);
                        link[link_count].link_device[0].INTERFACE_ID = 3;
                        link_count++;

                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "L2_Swtich_eNB";
                        link[link_count].link_device = new LINK_DEVICE[max_eNB + 1];
                        link[link_count].link_device[1].DEVICE_ID = eNb_idd - 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(eNb_idd - 1);
                        link[link_count].link_device[1].INTERFACE_ID = 2;
                        link[link_count].link_device[0].DEVICE_ID = 5;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(5);
                        link[link_count].link_device[0].INTERFACE_ID = 3;
                        link_count++;

                        //Ue link 
                        //Link gNB  with Ue

                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "gNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_gnb + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = NSA_gnb_idd_4x;
                        link[link_count].link_device[link_device_count].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 4;
                        link_device_count++;

                        //gnb with ue
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = NSA_k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 1;
                            link_device_count++;
                            NSA_k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;


                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_enb_NSA + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = e_idd;
                        link[link_count].link_device[link_device_count].NAME = "eNB_" + Convert.ToString(e_idd);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 3;
                        link_device_count++;

                        k = 1;

                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;
                            ipv4_count = 0;
                            device_container_NSA[ue_id - 1].device.DEVICE_ID = ue_id;
                            device_container_NSA[ue_id - 1].device.DEVICE_NAME = "UE_" + Convert.ToString(ue_id);
                            device_container_NSA[ue_id - 1].device.DEVICE_TYPE = "LTE_NR_UE";
                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[ue_id - 1].device.WIRESHARK_OPTION = "Disable";
                            device_container_NSA[ue_id - 1]._interface = new INTERFACE[2];

                            double theta1 = low_angle_NSA + l * ue_angle_increment;
                            device_container_NSA[ue_id - 1].pos_3d.X_OR_LON = enb_x0 + ue_radius * Math.Cos(Math.PI * (theta1 / 180.0));
                            device_container_NSA[ue_id - 1].pos_3d.Y_OR_LAT = enb_y0 + ue_radius * Math.Sin(Math.PI * (theta1 / 180.0));

                            int last_interface = device_container_NSA[ue_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[ue_id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[ue_id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th + l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface].INTERFACE_TYPE = "5G_RAN";

                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].ID = last_interface + 2;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th + l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].INTERFACE_TYPE = "LTE";

                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 2;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                            link_device_count++;
                            k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;
                        device_container_NSA[e_idd - 1].device.INTERFACE_COUNT = 3;
                        e_idd++;
                        r++;

                    }

                    i = NSA_gnb_idd_4x + max_eNB + max_gnb + max_ue - 1;
                    //Add router
                    for (; i < (NSA_gnb_idd_4x + max_eNB + max_ue + max_router); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Router_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "ROUTER";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_router_interface];
                    }

                    //Add node
                    for (; i < (NSA_gnb_idd_4x + max_eNB + max_gnb + max_ue + max_router + max_node - 1); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Wired_Node_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "WIREDNODE";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";
                        device_container_NSA[i]._interface = new INTERFACE[1];
                    }



                    /*-----------------------------------------------------------------------------------------------------*/
                    // this block sets the attributes, position of first_router and
                    NSA_router_id_1 = NSA_gnb_idd_4x + max_eNB + max_ue + max_router;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    upf_last_interface = device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT;
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                    device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip_2(++ipv4_count, 2);
                    device_container_NSA[0]._interface[1].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                    device_container_NSA[0]._interface[2].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "SERIAL";
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                    upf_last_interface++;

                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "ETHERNET";
                    device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "Wired_Node_" + Convert.ToString(NSA_router_id_1 + max_router);
                    device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT = upf_last_interface + 1;


                    //Router link with UPF
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].link_type = "UPF_Router";
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_device[1].DEVICE_ID = NSA_router_id_1;
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(NSA_router_id_1);
                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].INTERFACE_ID = 3;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link_count++;



                    device_container_NSA[NSA_router_id_1 - 1].level.r = 0.0;
                    theta0 = device_container_NSA[NSA_router_id_1 - 1].level.theta = 0.0;
                    level0 = device_container_NSA[NSA_router_id_1 - 1].level.level = 0;
                    increment0 = device_container_NSA[NSA_router_id_1 - 1].level.increment = (360.0 / Math.Pow(branch, level0 + 1));
                    device_container_NSA[NSA_router_id_1 - 1].level.low_angle = theta0 - (branch * 1.0) * increment0 / 2.0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;

                    /***********************************************************************************************/
                    /*************************************************************************************************/

                    //Console.WriteLine(not_leaf_node);
                    //Console.ReadLine();

                    /************************************************************************************************/
                    // this block of code sets the sttributes,positions,interfaces,and link(to router) of all the wirednodes
                    i = max_router + max_5G_core_devices + max_gnb + max_eNB + max_ue;
                    // int kii = - 1;//first router id
                    int NSA_max_node_temp = max_node;
                    double r_level;

                    while (NSA_max_node_temp != 0)
                    {
                        for (j = max_5G_core_devices + max_gnb + max_ue + max_eNB; j < i; j++)
                        {
                            int router_id = j + 1;

                            int id = device_container_NSA[i].device.DEVICE_ID;
                            int last_interface = device_container_NSA[i].device.INTERFACE_COUNT;
                            int router_last_interface = device_container_NSA[router_id - 1].device.INTERFACE_COUNT;
                            POS_3D pos_3d = device_container_NSA[router_id - 1].pos_3d;

                            r_level = device_container_NSA[router_id - 1].level.r;
                            theta = device_container_NSA[router_id - 1].level.theta;
                            int level = device_container_NSA[router_id - 1].level.level;
                            low_angle = device_container_NSA[router_id - 1].level.low_angle;
                            double increment = device_container_NSA[router_id - 1].level.increment;




                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].ID = router_last_interface;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].DEFAULT_GATEWAY = "";

                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].INTERFACE_TYPE = "ETHERNET";

                            ip = addNet.next_ip_3(ipv4_count, 1);
                            device_container_NSA[id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                            device_container_NSA[id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[id - 1]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[id - 1]._interface[last_interface].INTERFACE_TYPE = "ETHERNET";


                            double r1 = device_container_NSA[id - 1].level.r = r_level + offset_radius;
                            //Console.WriteLine(r);
                            //Console.WriteLine(r1);
                            double level1 = device_container_NSA[id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[id - 1].level.theta = low_angle + (router_last_interface - 1) * increment;
                            double increment1 = device_container_NSA[id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));


                            //device_container[id - 1].pos_3d.X_OR_LON = (pos_3d.X_OR_LON + 0.1);
                            //device_container[id - 1].pos_3d.Y_OR_LAT = (pos_3d.Y_OR_LAT + 0.1);

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "Wired_Router";
                            link[link_count].link_device[1].DEVICE_ID = id;
                            link[link_count].link_device[1].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[1].NAME = "Wired_Node_" + Convert.ToString(id);
                            link[link_count].link_device[0].DEVICE_ID = router_id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 2;
                            link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(router_id);


                            device_container_NSA[id - 1].device.INTERFACE_COUNT = last_interface + 1;
                            device_container_NSA[router_id - 1].device.INTERFACE_COUNT = router_last_interface;

                            link_count++;
                            i++;
                            router_id++;


                            NSA_max_node_temp--;
                            if (NSA_max_node_temp == 0)
                                break;
                        }
                    }
                }
   /*********************************************************************************************************************/
                else if(args[1] == "OPTION_7")
                {
                    device_container_NSA = new DEVICE_CONTAINER[total_device_NSA_4];
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    int NSA_k = 1;
                    int e_idd;
                    int octate_4th;
                    int r = 0;
                    string ip_upf;
                    string ip_upf_r;
                    int NSA_enb_idd_1;

                    int eNb_idd = max_5G_core_devices + max_eNB + max_gnb + 1;
                    //ADD first UMF
                    device_container_NSA[0].device.DEVICE_ID = 1;
                    device_container_NSA[0].device.DEVICE_NAME = "UPF_" + Convert.ToString(1);
                    device_container_NSA[0].device.DEVICE_TYPE = "UPF";
                    device_container_NSA[0].device.INTERFACE_COUNT = max_UPF_interface;
                    device_container_NSA[0]._interface = new INTERFACE[max_UPF_interface];

                    device_container_NSA[0].pos_3d.X_OR_LON = UPF_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = UPF_y0;

                    //Add SMF

                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;
                    device_container_NSA[1].device.DEVICE_ID = 2;
                    device_container_NSA[1].device.DEVICE_NAME = "SMF_" + Convert.ToString(2);
                    device_container_NSA[1].device.DEVICE_TYPE = "SMF";
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;
                    device_container_NSA[1]._interface = new INTERFACE[max_SMF_interface];
                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;

                    //ADD first AMF
                    device_container_NSA[2].device.DEVICE_ID = 3;
                    device_container_NSA[2].device.DEVICE_NAME = "AMF_" + Convert.ToString(3);
                    device_container_NSA[2].device.DEVICE_TYPE = "AMF";
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    device_container_NSA[2].pos_3d.X_OR_LON = AMF_x0;
                    device_container_NSA[2].pos_3d.Y_OR_LAT = AMF_y0;
                    device_container_NSA[2]._interface = new INTERFACE[max_AMF_interface];


                    /*****************************************************************************************************/
                    //SMF interface  with AMF
                    octate_4th = 1;
                    device_container_NSA[1]._interface[0].ID = 1;
                    device_container_NSA[1]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[1]._interface[0].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;

                    //AMF interface  with SMF
                    device_container_NSA[2]._interface[0].ID = 1;
                    device_container_NSA[2]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[2]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[2]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);


                    //interface of SMF with UPF
                    device_container_NSA[1]._interface[1].ID = 2;
                    device_container_NSA[1]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[1].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[1]._interface[1].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                    //UPF interface with SMF
                    device_container_NSA[0]._interface[0].ID = 1;
                    device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip(ipv4_count, 1);
                    device_container_NSA[0]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[0].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[0]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);
                    device_container_NSA[0].device.INTERFACE_COUNT = 3;



                    device_container_NSA[0]._interface[1].ID = 2;
                    ip_upf = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[1].IP_ADDRESS = ip_upf;
                    device_container_NSA[0]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[1].INTERFACE_TYPE = "5G_N3";
                    device_container_NSA[0]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(4);

                    ip_upf_r = addNet.next_ip(++ipv4_count, 1);
                    device_container_NSA[0]._interface[2].ID = 3;

                    device_container_NSA[0]._interface[2].IP_ADDRESS = ip_upf_r;
                    device_container_NSA[0]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[2].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[2].INTERFACE_TYPE = "5G_N6";
                    device_container_NSA[0]._interface[2].CONNECTED_TO = "Router_" + Convert.ToString(NSA_router_id_1);//router id




                    octate_4th += 2;
                    //AMF interface with L2_Switch
                    ipv4_count = 0;
                    device_container_NSA[2]._interface[1].ID = 2;
                    device_container_NSA[2]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[2]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                    device_container_NSA[2]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    //L2_Switch_4

                    device_container_NSA[3].device.DEVICE_ID = 4;
                    device_container_NSA[3].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(4);
                    device_container_NSA[3].device.DEVICE_TYPE = "L2_Switch_UPF";
                    device_container_NSA[3].device.INTERFACE_COUNT = max_gnb + 1;
                    device_container_NSA[3].pos_3d.X_OR_LON = L2_Switch_4_x0;
                    device_container_NSA[3].pos_3d.Y_OR_LAT = L2_Switch_4_y0;
                    device_container_NSA[3]._interface = new INTERFACE[max_switch_interface];

                    r = 0;
                    while (r < max_eNB)
                    {
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 1;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);
                        L2_switch_4_last_interface++;

                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 2;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "eNB_" + Convert.ToString(max_5G_core_devices + max_gnb + 1+ r);
                        L2_switch_4_last_interface++;
                        r++;
                    }

                    //attributes position of L2_Switches_5

                    device_container_NSA[4].device.DEVICE_ID = 5;
                    device_container_NSA[4].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[4].device.DEVICE_TYPE = "L2_Switch_AMF";
                    device_container_NSA[4].device.INTERFACE_COUNT = max_gnb + 1;
                    device_container_NSA[4].pos_3d.X_OR_LON = L2_Switch_5_x0;
                    device_container_NSA[4].pos_3d.Y_OR_LAT = L2_Switch_5_y0;
                    device_container_NSA[4]._interface = new INTERFACE[max_switch_interface];
                    r = 0;

                    device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                    mac = addNet.next_mac(mac);
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                    L2_switch_5_last_interface++;
                    while (r < max_eNB)
                    {
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "eNB_" + Convert.ToString(max_5G_core_devices +max_gnb + 1 + r);
                        L2_switch_5_last_interface++;
                        r++;
                    }


                    //attributes position of L2_Switches_6
                    device_container_NSA[5].device.DEVICE_ID = 6;
                    device_container_NSA[5].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(6);
                    device_container_NSA[5].device.DEVICE_TYPE = "L2_Switch_gNB";
                    device_container_NSA[5].device.INTERFACE_COUNT = max_gnb + max_eNB;
                    device_container_NSA[5].pos_3d.X_OR_LON = L2_Switch_6_x0;
                    device_container_NSA[5].pos_3d.Y_OR_LAT = L2_Switch_6_y0;
                    device_container_NSA[5]._interface = new INTERFACE[max_gnb + max_eNB];

                    r = 0;
                    //L2_Switch_6 with gNB
                    while (r < max_gnb)
                    {
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].ID = 1;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].IP_ADDRESS = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_6_last_interface++;
                        r++;
                    }

                    //Links
                    //SMF with AMF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_AMF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 2;
                    link[link_count].link_device[0].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[0].INTERFACE_ID = 1;

                    link[link_count].link_device[1].DEVICE_ID = 3;
                    link[link_count].link_device[1].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;


                    //SMF with UPF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_UPF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[1].DEVICE_ID = 2;
                    link[link_count].link_device[1].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[1].INTERFACE_ID = 2;

                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 1;
                    link_count++;

                    //Connection UPF with L2_Switch_4
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "UPF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 2;

                    link[link_count].link_device[1].DEVICE_ID = 4;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(4);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;

                    //Connection AMF with L2_Switch_5
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "AMF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 3;
                    link[link_count].link_device[0].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[0].INTERFACE_ID = 2;


                    link[link_count].link_device[1].DEVICE_ID = 5;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(5);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;

                    //Link enb and L2_switch
                    //L2_Switch and eNB
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "L2_Swtich_gNB";
                    link[link_count].link_device = new LINK_DEVICE[max_eNB + 1];
                    link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x;
                    link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link[link_count].link_device[0].DEVICE_ID = 6;
                    link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(6);
                    link[link_count].link_device[0].INTERFACE_ID = 1;
                    link_count++;
                    int upf_last_interface = 0;
                    int NSA_gnb_idd_1 = max_5G_core_devices + max_gnb;//max gNB check
                    string ip;
                    octate_4th += 2;
                    ipv4_count = 0;
                    int check = 1;
                    while (NSA_gnb_idd_4x - 1 < NSA_gnb_idd_1)
                    {

                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_ID = NSA_gnb_idd_4x;
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_TYPE = "LTE_gNB";
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.INTERFACE_COUNT = 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface = new INTERFACE[2];

                                             

                 
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].ID = 1;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].CONNECTED_TO = "L2_Switch_" + Convert.ToString(6);

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].ID = 2;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].INTERFACE_TYPE = "5G_RAN";
                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.X_OR_LON = gnbNSA_x0;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.Y_OR_LAT = gnbNSA_y0;
                        upf_last_interface++;
                        NSA_gnb_idd_4x++;


                    }

                  
                    check = 1;
                    NSA_enb_idd_7 = max_5G_core_devices + max_gnb + 1;
                    //L2_Switch_6 connrcted with eNB
                    while (L2_switch_6_last_interface >= 1)
                    {
                        if (check > max_eNB)
                            break;


                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].ID = L2_switch_6_last_interface;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].DEFAULT_GATEWAY = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                        ip = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].MAC_ADDRESS = mac;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].CONNECTED_TO = "eNB_" + Convert.ToString(NSA_enb_idd_7 + check - 1);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                        L2_switch_6_last_interface++;
                        NSA_enb_idd_7++;
                        check++;


                    }
                    
                    check = 1;
                    NSA_enb_idd_7 = max_5G_core_devices + max_gnb;
                    NSA_enb_idd_1 = max_5G_core_devices + max_gnb + max_eNB;
                    while (NSA_enb_idd_7 < NSA_enb_idd_1)
                    {

                        //L2_switch link_4 connection with eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "ENB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 4;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(4);
                        link[link_count].link_device[0].INTERFACE_ID = 2; //
                        link[link_count].link_device[1].DEVICE_ID = NSA_enb_idd_7 + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(NSA_enb_idd_7 + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1;//
                        link_count++;

                        //L2_switch link_5 connection with gNB

                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "ENB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 5;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(5);
                        link[link_count].link_device[0].INTERFACE_ID = 2;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_enb_idd_7 + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(NSA_enb_idd_7 + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 2;//
                        link_count++;

                        //L2_switch_6 link connection with eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "ENB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 6;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(6);
                        link[link_count].link_device[0].INTERFACE_ID = 2;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_enb_idd_7 + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(NSA_enb_idd_7 + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 3;//
                        link_count++;
                        NSA_enb_idd_7++;


                    }

                    link_device_count = link[link_count].DEVICE_COUNT = 0;
                    double theta;
                    e_idd = max_5G_core_devices + max_gnb + 1;
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    r = 0;
                    ipv4_count = 0;
                    while (e_idd < eNb_idd)
                    {
                        device_container_NSA[e_idd - 1].device.DEVICE_ID = e_idd;
                        device_container_NSA[e_idd - 1].device.DEVICE_NAME = "eNB_" + Convert.ToString(e_idd);
                        device_container_NSA[e_idd - 1].device.DEVICE_TYPE = "LTE_eNB";

                        device_container_NSA[e_idd - 1]._interface = new INTERFACE[4];


                        device_container_NSA[e_idd - 1]._interface[0].ID = 1;
                        device_container_NSA[e_idd - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[0].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[0].INTERFACE_TYPE = "5G_N3";
                        octate_4th += 2;
                        device_container_NSA[e_idd - 1]._interface[1].ID = 2;
                        device_container_NSA[e_idd - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[1].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[1].INTERFACE_TYPE = "5G_N1_N2";

                        octate_4th += 2;
                        device_container_NSA[e_idd - 1]._interface[2].ID = 3;
                        device_container_NSA[e_idd - 1]._interface[2].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[2].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[2].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[e_idd - 1]._interface[3].ID = 4;

                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[3].MAC_ADDRESS = mac;
                        device_container_NSA[e_idd - 1]._interface[3].INTERFACE_TYPE = "LTE";


                        while (L2_switch_6_last_interface >= 1)
                        {
                            if (check > max_eNB)
                                break;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].ID = L2_switch_6_last_interface;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].DEFAULT_GATEWAY = "";
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            ip = addNet.next_ip_1(ipv4_count, octate_4th);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].CONNECTED_TO = "eNB_" + Convert.ToString(e_idd + r);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                            L2_switch_6_last_interface++;
                            check++;

                        }

                        theta = e_idd * gnb_angle_increment;
                        device_container_NSA[e_idd - 1].pos_3d.X_OR_LON = enb_x0 + gnb_radius * Math.Cos(Math.PI * (theta / 180.0));
                        device_container_NSA[e_idd - 1].pos_3d.Y_OR_LAT = enb_y0 + gnb_radius * Math.Sin(Math.PI * (theta / 180.0));
                        double low_angle_NSA = theta - (num_ue_per_enb_NSA * ue_angle_increment / 2.0);

                        

                        //Ue link 
                        //Link gNB  with Ue

                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_gnb + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = e_idd ;
                        link[link_count].link_device[link_device_count].NAME = "eNB_" + Convert.ToString(e_idd);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 4;
                        link_device_count++;

                        //gnb with ue
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = NSA_k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 1;
                            link_device_count++;
                            NSA_k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;


                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "gNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_enb_NSA + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = NSA_gnb_idd_4x;
                        link[link_count].link_device[link_device_count].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                        link_device_count++;

                        k = 1;

                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;
                            ipv4_count = 0;
                            device_container_NSA[ue_id - 1].device.DEVICE_ID = ue_id;
                            device_container_NSA[ue_id - 1].device.DEVICE_NAME = "UE_" + Convert.ToString(ue_id);
                            device_container_NSA[ue_id - 1].device.DEVICE_TYPE = "LTE_NR_UE";
                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[ue_id - 1].device.WIRESHARK_OPTION = "Disable";
                            device_container_NSA[ue_id - 1]._interface = new INTERFACE[2];

                            double theta1 = low_angle_NSA + l * ue_angle_increment;
                            device_container_NSA[ue_id - 1].pos_3d.X_OR_LON = enb_x0 + ue_radius * Math.Cos(Math.PI * (theta1 / 180.0));
                            device_container_NSA[ue_id - 1].pos_3d.Y_OR_LAT = enb_y0 + ue_radius * Math.Sin(Math.PI * (theta1 / 180.0));

                            int last_interface = device_container_NSA[ue_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[ue_id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[ue_id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th + l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface].INTERFACE_TYPE = "LTE";

                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].ID = last_interface + 2;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th + l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].INTERFACE_TYPE = "5G_RAN";

                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 2;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                            link_device_count++;
                            k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;
                        device_container_NSA[e_idd - 1].device.INTERFACE_COUNT = 4;
                        e_idd++;
                        r++;

                    }
                      
                   i = max_5G_core_devices + max_eNB + max_gnb + max_ue;
                    //Add router
                    for (; i < (NSA_enb_idd_1 + max_ue + max_router); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Router_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "ROUTER";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_router_interface];
                    }

                    //Add node
                    for (; i < (NSA_enb_idd_1 + max_ue + max_router + max_node); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Wired_Node_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "WIREDNODE";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";
                        device_container_NSA[i]._interface = new INTERFACE[1];
                    }



                    /*-----------------------------------------------------------------------------------------------------*/
                    // this block sets the attributes, position of first_router and
                    NSA_router_id_1 = max_5G_core_devices+max_gnb + max_eNB + max_ue + 1;
                    int NSA_max_router_id = max_5G_core_devices + max_gnb + max_eNB + max_ue + max_router;
                    
                    check = 1;
                    while (NSA_router_id_1 - 1 < NSA_max_router_id)
                    {

                        if (check < max_router)
                            break;

                        device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                        device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;
                        upf_last_interface = device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                        device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip_2(++ipv4_count, 2);
                        device_container_NSA[0]._interface[1].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                        device_container_NSA[0]._interface[2].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "SERIAL";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                        upf_last_interface++;

                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "Wired_Node_" + Convert.ToString(NSA_router_id_1 + max_router);
                        device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT = upf_last_interface + 1;



                        //Router link with UPF
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].link_type = "UPF_Router";
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_device[1].DEVICE_ID = NSA_router_id_1;
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(NSA_router_id_1);
                        link[link_count].link_device[0].DEVICE_ID = 1;
                        link[link_count].link_device[0].INTERFACE_ID = 3;
                        link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                        link_count++;

                       

                        device_container_NSA[NSA_router_id_1 - 1].level.r = 0.0;
                        theta0 = device_container_NSA[NSA_router_id_1 - 1].level.theta = 0.0;
                        level0 = device_container_NSA[NSA_router_id_1 - 1].level.level = 0;
                        increment0 = device_container_NSA[NSA_router_id_1 - 1].level.increment = (360.0 / Math.Pow(branch, level0 + 1));
                        device_container_NSA[NSA_router_id_1 - 1].level.low_angle = theta0 - (branch * 1.0) * increment0 / 2.0;
                        NSA_router_id_1++;
                        check++;
                    }
                    /*device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;*/

                    /***********************************************************************************************/
                    /*************************************************************************************************/

                    //Console.WriteLine(not_leaf_node);
                    //Console.ReadLine();

                    /************************************************************************************************/
                    // this block of code sets the sttributes,positions,interfaces,and link(to router) of all the wirednodes
                    i = max_router + max_5G_core_devices + max_gnb + max_eNB + max_ue;
                    // int kii = - 1;//first router id
                    int NSA_max_node_temp = max_node;
                    double r_level;

                    while (NSA_max_node_temp != 0)
                    {
                        for (j = max_5G_core_devices + max_gnb + max_ue + max_eNB; j < i; j++)
                        {
                            int router_id = j + 1;

                            int id = device_container_NSA[i].device.DEVICE_ID;
                            int last_interface = device_container_NSA[i].device.INTERFACE_COUNT;
                            int router_last_interface = device_container_NSA[router_id - 1].device.INTERFACE_COUNT;
                            POS_3D pos_3d = device_container_NSA[router_id - 1].pos_3d;

                            r_level = device_container_NSA[router_id - 1].level.r;
                            theta = device_container_NSA[router_id - 1].level.theta;
                            int level = device_container_NSA[router_id - 1].level.level;
                            low_angle = device_container_NSA[router_id - 1].level.low_angle;
                            double increment = device_container_NSA[router_id - 1].level.increment;




                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].ID = router_last_interface;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].DEFAULT_GATEWAY = "";

                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].INTERFACE_TYPE = "ETHERNET";

                            ip = addNet.next_ip_3(ipv4_count, 1);
                            device_container_NSA[id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                            device_container_NSA[id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[id - 1]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[id - 1]._interface[last_interface].INTERFACE_TYPE = "ETHERNET";


                            double r1 = device_container_NSA[id - 1].level.r = r_level + offset_radius;
                            //Console.WriteLine(r);
                            //Console.WriteLine(r1);
                            double level1 = device_container_NSA[id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[id - 1].level.theta = low_angle + (router_last_interface - 1) * increment;
                            double increment1 = device_container_NSA[id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));


                            //device_container[id - 1].pos_3d.X_OR_LON = (pos_3d.X_OR_LON + 0.1);
                            //device_container[id - 1].pos_3d.Y_OR_LAT = (pos_3d.Y_OR_LAT + 0.1);

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "Wired_Router";
                            link[link_count].link_device[1].DEVICE_ID = id;
                            link[link_count].link_device[1].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[1].NAME = "Wired_Node_" + Convert.ToString(id);
                            link[link_count].link_device[0].DEVICE_ID = router_id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 2;
                            link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(router_id);


                            device_container_NSA[id - 1].device.INTERFACE_COUNT = last_interface + 1;
                            device_container_NSA[router_id - 1].device.INTERFACE_COUNT = router_last_interface;

                            link_count++;
                            i++;
                            router_id++;


                            NSA_max_node_temp--;
                            if (NSA_max_node_temp == 0)
                                break;
                        }
                    }


                }
/********************************************************************************************************************************/
                else if(args[1] == "OPTION_7a")
                {

                    device_container_NSA = new DEVICE_CONTAINER[total_device_NSA_4];
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    int NSA_k = 1;
                    int e_idd;
                    int octate_4th;
                    int r = 0;
                    string ip_upf;
                    string ip_upf_r;
                    int NSA_enb_idd_1;

                    int eNb_idd = max_5G_core_devices + max_eNB + max_gnb + 1;
                    //ADD first UMF
                    device_container_NSA[0].device.DEVICE_ID = 1;
                    device_container_NSA[0].device.DEVICE_NAME = "UPF_" + Convert.ToString(1);
                    device_container_NSA[0].device.DEVICE_TYPE = "UPF";
                    device_container_NSA[0].device.INTERFACE_COUNT = max_UPF_interface;
                    device_container_NSA[0]._interface = new INTERFACE[max_UPF_interface];

                    device_container_NSA[0].pos_3d.X_OR_LON = UPF_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = UPF_y0;

                    //Add SMF

                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;
                    device_container_NSA[1].device.DEVICE_ID = 2;
                    device_container_NSA[1].device.DEVICE_NAME = "SMF_" + Convert.ToString(2);
                    device_container_NSA[1].device.DEVICE_TYPE = "SMF";
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;
                    device_container_NSA[1]._interface = new INTERFACE[max_SMF_interface];
                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;

                    //ADD first AMF
                    device_container_NSA[2].device.DEVICE_ID = 3;
                    device_container_NSA[2].device.DEVICE_NAME = "AMF_" + Convert.ToString(3);
                    device_container_NSA[2].device.DEVICE_TYPE = "AMF";
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    device_container_NSA[2].pos_3d.X_OR_LON = AMF_x0;
                    device_container_NSA[2].pos_3d.Y_OR_LAT = AMF_y0;
                    device_container_NSA[2]._interface = new INTERFACE[max_AMF_interface];


                    /*****************************************************************************************************/
                    //SMF interface  with AMF
                    octate_4th = 1;
                    device_container_NSA[1]._interface[0].ID = 1;
                    device_container_NSA[1]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[1]._interface[0].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;

                    //AMF interface  with SMF
                    device_container_NSA[2]._interface[0].ID = 1;
                    device_container_NSA[2]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[2]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[2]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);


                    //interface of SMF with UPF
                    device_container_NSA[1]._interface[1].ID = 2;
                    device_container_NSA[1]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[1].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[1]._interface[1].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                    //UPF interface with SMF
                    device_container_NSA[0]._interface[0].ID = 1;
                    device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip(ipv4_count, 1);
                    device_container_NSA[0]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[0].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[0]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);
                    device_container_NSA[0].device.INTERFACE_COUNT = 3;



                    device_container_NSA[0]._interface[1].ID = 2;
                    ip_upf = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[1].IP_ADDRESS = ip_upf;
                    device_container_NSA[0]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[1].INTERFACE_TYPE = "5G_N3";
                    device_container_NSA[0]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(4);

                    ip_upf_r = addNet.next_ip(++ipv4_count, 1);
                    device_container_NSA[0]._interface[2].ID = 3;

                    device_container_NSA[0]._interface[2].IP_ADDRESS = ip_upf_r;
                    device_container_NSA[0]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[2].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[2].INTERFACE_TYPE = "5G_N6";
                    device_container_NSA[0]._interface[2].CONNECTED_TO = "Router_" + Convert.ToString(NSA_router_id_1);//router id




                    octate_4th += 2;
                    //AMF interface with L2_Switch
                    ipv4_count = 0;
                    device_container_NSA[2]._interface[1].ID = 2;
                    device_container_NSA[2]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[2]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                    device_container_NSA[2]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    //L2_Switch_4
                    max_switch_interface = max_gnb + max_eNB + 1;
                    device_container_NSA[3].device.DEVICE_ID = 4;
                    device_container_NSA[3].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(4);
                    device_container_NSA[3].device.DEVICE_TYPE = "L2_Switch_UPF";
                    device_container_NSA[3].device.INTERFACE_COUNT = max_gnb + max_eNB + 1;
                    device_container_NSA[3].pos_3d.X_OR_LON = L2_Switch_4_x0;
                    device_container_NSA[3].pos_3d.Y_OR_LAT = L2_Switch_4_y0;
                    device_container_NSA[3]._interface = new INTERFACE[max_switch_interface];

                    r = 0;
                    while (r < max_gnb)
                    {
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 1;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);
                        L2_switch_4_last_interface++;

                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 2;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_4_last_interface++;
                        r++;
                    }

                    //attributes position of L2_Switches_5

                    device_container_NSA[4].device.DEVICE_ID = 5;
                    device_container_NSA[4].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[4].device.DEVICE_TYPE = "L2_Switch_AMF";
                    device_container_NSA[4].device.INTERFACE_COUNT = max_gnb + max_eNB + 1;
                    device_container_NSA[4].pos_3d.X_OR_LON = L2_Switch_5_x0;
                    device_container_NSA[4].pos_3d.Y_OR_LAT = L2_Switch_5_y0;
                    device_container_NSA[4]._interface = new INTERFACE[max_switch_interface];
                    r = 0;

                    device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                    mac = addNet.next_mac(mac);
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                    L2_switch_5_last_interface++;
                    while (r < max_gnb)
                    {
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices +  1 + r);
                        L2_switch_5_last_interface++;
                        r++;
                    }


                    //attributes position of L2_Switches_6
                    device_container_NSA[5].device.DEVICE_ID = 6;
                    device_container_NSA[5].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(6);
                    device_container_NSA[5].device.DEVICE_TYPE = "L2_Switch_gNB";
                    device_container_NSA[5].device.INTERFACE_COUNT =  max_eNB;
                    device_container_NSA[5].pos_3d.X_OR_LON = L2_Switch_6_x0;
                    device_container_NSA[5].pos_3d.Y_OR_LAT = L2_Switch_6_y0;
                    device_container_NSA[5]._interface = new INTERFACE[max_eNB];

                    r = 0;
                    //L2_Switch_6 with gNB
                    while (r < max_eNB)
                    {
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].ID = 1;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].IP_ADDRESS = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].CONNECTED_TO = "eNB_" + Convert.ToString(max_5G_core_devices + max_gnb+ 1 + r);
                        L2_switch_6_last_interface++;
                        r++;
                    }

                    //Links
                    //SMF with AMF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_AMF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 2;
                    link[link_count].link_device[0].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[0].INTERFACE_ID = 1;

                    link[link_count].link_device[1].DEVICE_ID = 3;
                    link[link_count].link_device[1].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;


                    //SMF with UPF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_UPF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[1].DEVICE_ID = 2;
                    link[link_count].link_device[1].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[1].INTERFACE_ID = 2;

                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 1;
                    link_count++;

                    //Connection UPF with L2_Switch_4
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "UPF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 2;

                    link[link_count].link_device[1].DEVICE_ID = 4;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(4);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;

                    //Connection AMF with L2_Switch_5
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "AMF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 3;
                    link[link_count].link_device[0].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[0].INTERFACE_ID = 2;


                    link[link_count].link_device[1].DEVICE_ID = 5;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(5);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;

                    //Link gnb and L2_switch
                    //L2_Switch_4 and gNB
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "L2_Swtich_gNB";
                    link[link_count].link_device = new LINK_DEVICE[max_gnb + 1];
                    link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x;
                    link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link[link_count].link_device[0].DEVICE_ID = 4;
                    link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(4);
                    link[link_count].link_device[0].INTERFACE_ID = 2;
                    link_count++;

                    //L2_Switch_5 with gNB
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "L2_Swtich_gNB";
                    link[link_count].link_device = new LINK_DEVICE[max_gnb + 1];
                    link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x;
                    link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                    link[link_count].link_device[1].INTERFACE_ID = 2;
                    link[link_count].link_device[0].DEVICE_ID = 5;
                    link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(5);
                    link[link_count].link_device[0].INTERFACE_ID = 2;
                    link_count++;
                    int upf_last_interface = 0;
                    int NSA_gnb_idd_1 = max_5G_core_devices + max_gnb;//max gNB check
                    string ip;
                    octate_4th += 2;
                    ipv4_count = 0;
                    int check = 1;
                    while (NSA_gnb_idd_4x - 1 < NSA_gnb_idd_1)
                    {

                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_ID = NSA_gnb_idd_4x;
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_TYPE = "LTE_gNB";
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.INTERFACE_COUNT = 3;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface = new INTERFACE[3];



                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].ID = 1;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].MAC_ADDRESS = mac;

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].INTERFACE_TYPE = "5G_N3";
                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].ID = 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].MAC_ADDRESS = mac;

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].INTERFACE_TYPE = "5G_N1_N2";

                        /*
                                                device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].ID = 1;
                                                device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                                                mac = addNet.next_mac(mac);
                                                device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].MAC_ADDRESS = mac;
                                                device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].INTERFACE_TYPE = "5G_XN";

                                                device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                                                device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].CONNECTED_TO = "L2_Switch_" + Convert.ToString(6);*/

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].ID = 3;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].INTERFACE_TYPE = "5G_RAN";
                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.X_OR_LON = gnbNSA_x0;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.Y_OR_LAT = gnbNSA_y0;
                        upf_last_interface++;
                        NSA_gnb_idd_4x++;


                    }
                   


                    check = 1;
                    NSA_enb_idd_7 = max_5G_core_devices + max_gnb + 1;
                    //L2_Switch_4 connected with eNb
                    while (L2_switch_4_last_interface >= 2)
                    {
                        if (check > max_eNB)
                            break;


                        device_container_NSA[3]._interface[L2_switch_4_last_interface ].ID = L2_switch_4_last_interface + 1;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        ip = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "eNB_" + Convert.ToString(NSA_enb_idd_7 + check - 1);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        L2_switch_4_last_interface++;
                        NSA_enb_idd_7++;
                        check++;


                    }

                    check = 1;
                    NSA_enb_idd_7 = max_5G_core_devices + max_gnb + 1;
                    //L2_Switch_5 connected with enb
                    while (L2_switch_5_last_interface >= 2)
                    {
                        if (check > max_eNB)
                            break;


                        device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        ip = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "eNB_" + Convert.ToString(NSA_enb_idd_7 + check - 1);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                        L2_switch_5_last_interface++;
                        NSA_enb_idd_7++;
                        check++;


                    }


                    

                    check = 1;
                    NSA_enb_idd_7 = max_5G_core_devices + max_gnb;
                    NSA_enb_idd_1 = max_5G_core_devices + max_gnb + max_eNB;
                    while (NSA_enb_idd_7 < NSA_enb_idd_1)
                    {

                        //L2_switch link_4 connection with eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "ENB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 4;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(4);
                        link[link_count].link_device[0].INTERFACE_ID = 3; //
                        link[link_count].link_device[1].DEVICE_ID = NSA_enb_idd_7 + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(NSA_enb_idd_7 + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1;//
                        link_count++;

                        //L2_switch link_5 connection with eNB

                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "ENB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 5;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(5);
                        link[link_count].link_device[0].INTERFACE_ID = 3;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_enb_idd_7 + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(NSA_enb_idd_7 + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 2;//
                        link_count++;

                        //L2_switch_6 link connection with eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "ENB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 6;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(6);
                        link[link_count].link_device[0].INTERFACE_ID = 1;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_enb_idd_7 + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(NSA_enb_idd_7 + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 3;//
                        link_count++;
                        NSA_enb_idd_7++;


                    }

                    link_device_count = link[link_count].DEVICE_COUNT = 0;
                    double theta;
                    e_idd = max_5G_core_devices + max_gnb + 1;
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    r = 0;
                    ipv4_count = 0;
                    while (e_idd < eNb_idd)
                    {
                        device_container_NSA[e_idd - 1].device.DEVICE_ID = e_idd;
                        device_container_NSA[e_idd - 1].device.DEVICE_NAME = "eNB_" + Convert.ToString(e_idd);
                        device_container_NSA[e_idd - 1].device.DEVICE_TYPE = "LTE_eNB";

                        device_container_NSA[e_idd - 1]._interface = new INTERFACE[4];


                        device_container_NSA[e_idd - 1]._interface[0].ID = 1;
                        device_container_NSA[e_idd - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[0].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[0].INTERFACE_TYPE = "5G_N3";
                        octate_4th += 2;
                        device_container_NSA[e_idd - 1]._interface[1].ID = 2;
                        device_container_NSA[e_idd - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[1].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[1].INTERFACE_TYPE = "5G_N1_N2";

                        octate_4th += 2;
                        device_container_NSA[e_idd - 1]._interface[2].ID = 3;
                        device_container_NSA[e_idd - 1]._interface[2].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[2].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[2].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[e_idd - 1]._interface[3].ID = 4;

                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[3].MAC_ADDRESS = mac;
                        device_container_NSA[e_idd - 1]._interface[3].INTERFACE_TYPE = "LTE";


                        while (L2_switch_6_last_interface >= 1)
                        {
                            if (check > max_eNB)
                                break;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].ID = L2_switch_6_last_interface;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].DEFAULT_GATEWAY = "";
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            ip = addNet.next_ip_1(ipv4_count, octate_4th);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].CONNECTED_TO = "eNB_" + Convert.ToString(e_idd + r);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface - 1].INTERFACE_TYPE = "ETHERNET";
                            L2_switch_6_last_interface++;
                            check++;

                        }

                        theta = e_idd * gnb_angle_increment;
                        device_container_NSA[e_idd - 1].pos_3d.X_OR_LON = enb_x0 + gnb_radius * Math.Cos(Math.PI * (theta / 180.0));
                        device_container_NSA[e_idd - 1].pos_3d.Y_OR_LAT = enb_y0 + gnb_radius * Math.Sin(Math.PI * (theta / 180.0));
                        double low_angle_NSA = theta - (num_ue_per_enb_NSA * ue_angle_increment / 2.0);



                        //Ue link 
                        //Link gNB  with Ue

                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_gnb + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = e_idd;
                        link[link_count].link_device[link_device_count].NAME = "eNB_" + Convert.ToString(e_idd);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 4;
                        link_device_count++;

                        //gnb with ue
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = NSA_k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 1;
                            link_device_count++;
                            NSA_k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;


                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "gNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_enb_NSA + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = NSA_gnb_idd_4x;
                        link[link_count].link_device[link_device_count].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 3;
                        link_device_count++;

                        k = 1;

                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;
                            ipv4_count = 0;
                            device_container_NSA[ue_id - 1].device.DEVICE_ID = ue_id;
                            device_container_NSA[ue_id - 1].device.DEVICE_NAME = "UE_" + Convert.ToString(ue_id);
                            device_container_NSA[ue_id - 1].device.DEVICE_TYPE = "LTE_NR_UE";
                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[ue_id - 1].device.WIRESHARK_OPTION = "Disable";
                            device_container_NSA[ue_id - 1]._interface = new INTERFACE[2];

                            double theta1 = low_angle_NSA + l * ue_angle_increment;
                            device_container_NSA[ue_id - 1].pos_3d.X_OR_LON = enb_x0 + ue_radius * Math.Cos(Math.PI * (theta1 / 180.0));
                            device_container_NSA[ue_id - 1].pos_3d.Y_OR_LAT = enb_y0 + ue_radius * Math.Sin(Math.PI * (theta1 / 180.0));

                            int last_interface = device_container_NSA[ue_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[ue_id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[ue_id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th + l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface].INTERFACE_TYPE = "LTE";

                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].ID = last_interface + 2;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th + l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].INTERFACE_TYPE = "5G_RAN";

                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 2;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                            link_device_count++;
                            k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;
                        device_container_NSA[e_idd - 1].device.INTERFACE_COUNT = 4;
                        e_idd++;
                        r++;

                    }

                    i = max_5G_core_devices + max_eNB + max_gnb + max_ue;
                    //Add router
                    for (; i < (NSA_enb_idd_1 + max_ue + max_router); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Router_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "ROUTER";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_router_interface];
                    }

                    //Add node
                    for (; i < (NSA_enb_idd_1 + max_ue + max_router + max_node); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Wired_Node_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "WIREDNODE";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";
                        device_container_NSA[i]._interface = new INTERFACE[1];
                    }



                    /*-----------------------------------------------------------------------------------------------------*/
                    // this block sets the attributes, position of first_router and
                    NSA_router_id_1 = max_5G_core_devices + max_gnb + max_eNB + max_ue + 1;
                    int NSA_max_router_id = max_5G_core_devices + max_gnb + max_eNB + max_ue + max_router;

                    check = 1;
                    while (NSA_router_id_1 - 1 < NSA_max_router_id)
                    {

                        if (check < max_router)
                            break;

                        device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                        device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;
                        upf_last_interface = device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                        device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip_2(++ipv4_count, 2);
                        device_container_NSA[0]._interface[1].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                        device_container_NSA[0]._interface[2].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "SERIAL";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                        upf_last_interface++;

                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "Wired_Node_" + Convert.ToString(NSA_router_id_1 + max_router);
                        device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT = upf_last_interface + 1;



                        //Router link with UPF
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].link_type = "UPF_Router";
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_device[1].DEVICE_ID = NSA_router_id_1;
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(NSA_router_id_1);
                        link[link_count].link_device[0].DEVICE_ID = 1;
                        link[link_count].link_device[0].INTERFACE_ID = 3;
                        link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                        link_count++;



                        device_container_NSA[NSA_router_id_1 - 1].level.r = 0.0;
                        theta0 = device_container_NSA[NSA_router_id_1 - 1].level.theta = 0.0;
                        level0 = device_container_NSA[NSA_router_id_1 - 1].level.level = 0;
                        increment0 = device_container_NSA[NSA_router_id_1 - 1].level.increment = (360.0 / Math.Pow(branch, level0 + 1));
                        device_container_NSA[NSA_router_id_1 - 1].level.low_angle = theta0 - (branch * 1.0) * increment0 / 2.0;
                        NSA_router_id_1++;
                        check++;
                    }
                    /*device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;*/

                    /***********************************************************************************************/
                    /*************************************************************************************************/

                    //Console.WriteLine(not_leaf_node);
                    //Console.ReadLine();

                    /************************************************************************************************/
                    // this block of code sets the sttributes,positions,interfaces,and link(to router) of all the wirednodes
                    i = max_router + max_5G_core_devices + max_gnb + max_eNB + max_ue;
                    // int kii = - 1;//first router id
                    int NSA_max_node_temp = max_node;
                    double r_level;

                    while (NSA_max_node_temp != 0)
                    {
                        for (j = max_5G_core_devices + max_gnb + max_ue + max_eNB; j < i; j++)
                        {
                            int router_id = j + 1;

                            int id = device_container_NSA[i].device.DEVICE_ID;
                            int last_interface = device_container_NSA[i].device.INTERFACE_COUNT;
                            int router_last_interface = device_container_NSA[router_id - 1].device.INTERFACE_COUNT;
                            POS_3D pos_3d = device_container_NSA[router_id - 1].pos_3d;

                            r_level = device_container_NSA[router_id - 1].level.r;
                            theta = device_container_NSA[router_id - 1].level.theta;
                            int level = device_container_NSA[router_id - 1].level.level;
                            low_angle = device_container_NSA[router_id - 1].level.low_angle;
                            double increment = device_container_NSA[router_id - 1].level.increment;




                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].ID = router_last_interface;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].DEFAULT_GATEWAY = "";

                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].INTERFACE_TYPE = "ETHERNET";

                            ip = addNet.next_ip_3(ipv4_count, 1);
                            device_container_NSA[id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                            device_container_NSA[id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[id - 1]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[id - 1]._interface[last_interface].INTERFACE_TYPE = "ETHERNET";


                            double r1 = device_container_NSA[id - 1].level.r = r_level + offset_radius;
                            //Console.WriteLine(r);
                            //Console.WriteLine(r1);
                            double level1 = device_container_NSA[id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[id - 1].level.theta = low_angle + (router_last_interface - 1) * increment;
                            double increment1 = device_container_NSA[id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));


                            //device_container[id - 1].pos_3d.X_OR_LON = (pos_3d.X_OR_LON + 0.1);
                            //device_container[id - 1].pos_3d.Y_OR_LAT = (pos_3d.Y_OR_LAT + 0.1);

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "Wired_Router";
                            link[link_count].link_device[1].DEVICE_ID = id;
                            link[link_count].link_device[1].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[1].NAME = "Wired_Node_" + Convert.ToString(id);
                            link[link_count].link_device[0].DEVICE_ID = router_id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 2;
                            link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(router_id);


                            device_container_NSA[id - 1].device.INTERFACE_COUNT = last_interface + 1;
                            device_container_NSA[router_id - 1].device.INTERFACE_COUNT = router_last_interface;

                            link_count++;
                            i++;
                            router_id++;


                            NSA_max_node_temp--;
                            if (NSA_max_node_temp == 0)
                                break;
                        }
                    }
                }
/*******************************************************************************************************************/
                else if (args[1] == "OPTION_7x")
                {
                    device_container_NSA = new DEVICE_CONTAINER[total_device_NSA_4];
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    int NSA_k = 1;
                    int e_idd;
                    int octate_4th;
                    int r = 0;
                    string ip_upf;
                    string ip_upf_r;
                    int NSA_enb_idd_1;

                    int eNb_idd = max_5G_core_devices + max_eNB + max_gnb + 1;
                    //ADD first UMF
                    device_container_NSA[0].device.DEVICE_ID = 1;
                    device_container_NSA[0].device.DEVICE_NAME = "UPF_" + Convert.ToString(1);
                    device_container_NSA[0].device.DEVICE_TYPE = "UPF";
                    device_container_NSA[0].device.INTERFACE_COUNT = max_UPF_interface;
                    device_container_NSA[0]._interface = new INTERFACE[max_UPF_interface];

                    device_container_NSA[0].pos_3d.X_OR_LON = UPF_x0;
                    device_container_NSA[0].pos_3d.Y_OR_LAT = UPF_y0;

                    //Add SMF

                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;
                    device_container_NSA[1].device.DEVICE_ID = 2;
                    device_container_NSA[1].device.DEVICE_NAME = "SMF_" + Convert.ToString(2);
                    device_container_NSA[1].device.DEVICE_TYPE = "SMF";
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;
                    device_container_NSA[1]._interface = new INTERFACE[max_SMF_interface];
                    device_container_NSA[1].pos_3d.X_OR_LON = SMF_x0;
                    device_container_NSA[1].pos_3d.Y_OR_LAT = SMF_y0;

                    //ADD first AMF
                    device_container_NSA[2].device.DEVICE_ID = 3;
                    device_container_NSA[2].device.DEVICE_NAME = "AMF_" + Convert.ToString(3);
                    device_container_NSA[2].device.DEVICE_TYPE = "AMF";
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    device_container_NSA[2].pos_3d.X_OR_LON = AMF_x0;
                    device_container_NSA[2].pos_3d.Y_OR_LAT = AMF_y0;
                    device_container_NSA[2]._interface = new INTERFACE[max_AMF_interface];


                    /*****************************************************************************************************/
                    //SMF interface  with AMF
                    octate_4th = 1;
                    device_container_NSA[1]._interface[0].ID = 1;
                    device_container_NSA[1]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[1]._interface[0].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                    device_container_NSA[1].device.INTERFACE_COUNT = 2;

                    //AMF interface  with SMF
                    device_container_NSA[2]._interface[0].ID = 1;
                    device_container_NSA[2]._interface[0].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[2]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[0].INTERFACE_TYPE = "5G_N11";
                    device_container_NSA[2]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);


                    //interface of SMF with UPF
                    device_container_NSA[1]._interface[1].ID = 2;
                    device_container_NSA[1]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[1]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[1]._interface[1].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[1]._interface[1].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                    //UPF interface with SMF
                    device_container_NSA[0]._interface[0].ID = 1;
                    device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip(ipv4_count, 1);
                    device_container_NSA[0]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[0].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[0].INTERFACE_TYPE = "5G_N4";
                    device_container_NSA[0]._interface[0].CONNECTED_TO = "SMF_" + Convert.ToString(2);
                    device_container_NSA[0].device.INTERFACE_COUNT = 3;



                    device_container_NSA[0]._interface[1].ID = 2;
                    ip_upf = addNet.next_ip_1(ipv4_count, ++octate_4th);
                    device_container_NSA[0]._interface[1].IP_ADDRESS = ip_upf;
                    device_container_NSA[0]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[1].INTERFACE_TYPE = "5G_N3";
                    device_container_NSA[0]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(4);

                    ip_upf_r = addNet.next_ip(++ipv4_count, 1);
                    device_container_NSA[0]._interface[2].ID = 3;

                    device_container_NSA[0]._interface[2].IP_ADDRESS = ip_upf_r;
                    device_container_NSA[0]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[0]._interface[2].MAC_ADDRESS = mac;
                    device_container_NSA[0]._interface[2].INTERFACE_TYPE = "5G_N6";
                    device_container_NSA[0]._interface[2].CONNECTED_TO = "Router_" + Convert.ToString(NSA_router_id_1);//router id




                    octate_4th += 2;
                    //AMF interface with L2_Switch
                    ipv4_count = 0;
                    device_container_NSA[2]._interface[1].ID = 2;
                    device_container_NSA[2]._interface[1].DEFAULT_GATEWAY = "";
                    device_container_NSA[2]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                    device_container_NSA[2]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                    mac = addNet.next_mac(mac);
                    device_container_NSA[2]._interface[1].MAC_ADDRESS = mac;
                    device_container_NSA[2]._interface[1].INTERFACE_TYPE = "5G_N1_N2";
                    device_container_NSA[2]._interface[1].CONNECTED_TO = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[2].device.INTERFACE_COUNT = 2;

                    //L2_Switch_4
                    max_switch_interface = max_gnb + max_eNB + 1;
                    device_container_NSA[3].device.DEVICE_ID = 4;
                    device_container_NSA[3].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(4);
                    device_container_NSA[3].device.DEVICE_TYPE = "L2_Switch_UPF";
                    device_container_NSA[3].device.INTERFACE_COUNT = max_gnb + max_eNB + 1;
                    device_container_NSA[3].pos_3d.X_OR_LON = L2_Switch_4_x0;
                    device_container_NSA[3].pos_3d.Y_OR_LAT = L2_Switch_4_y0;
                    device_container_NSA[3]._interface = new INTERFACE[max_switch_interface];

                    r = 0;
                    while (r < max_gnb)
                    {
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 1;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);
                        L2_switch_4_last_interface++;

                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = 2;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_4_last_interface++;
                        r++;
                    }

                    //attributes position of L2_Switches_5

                    device_container_NSA[4].device.DEVICE_ID = 5;
                    device_container_NSA[4].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(5);
                    device_container_NSA[4].device.DEVICE_TYPE = "L2_Switch_AMF";
                    device_container_NSA[4].device.INTERFACE_COUNT = max_gnb + max_eNB + 1;
                    device_container_NSA[4].pos_3d.X_OR_LON = L2_Switch_5_x0;
                    device_container_NSA[4].pos_3d.Y_OR_LAT = L2_Switch_5_y0;
                    device_container_NSA[4]._interface = new INTERFACE[max_switch_interface];
                    r = 0;

                    device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                    mac = addNet.next_mac(mac);
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                    device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "AMF_" + Convert.ToString(3);
                    L2_switch_5_last_interface++;
                    while (r < max_gnb)
                    {
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].ID = L2_switch_5_last_interface + 1;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].IP_ADDRESS = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices + 1 + r);
                        L2_switch_5_last_interface++;
                        r++;
                    }


                    //attributes position of L2_Switches_6
                    device_container_NSA[5].device.DEVICE_ID = 6;
                    device_container_NSA[5].device.DEVICE_NAME = "L2_Switch_" + Convert.ToString(6);
                    device_container_NSA[5].device.DEVICE_TYPE = "L2_Switch_gNB";
                    device_container_NSA[5].device.INTERFACE_COUNT = max_eNB + max_gnb;
                    device_container_NSA[5].pos_3d.X_OR_LON = L2_Switch_6_x0;
                    device_container_NSA[5].pos_3d.Y_OR_LAT = L2_Switch_6_y0;
                    device_container_NSA[5]._interface = new INTERFACE[max_eNB + max_gnb];

                    r = 0;
                    //L2_Switch_6 with gNB
                    while (r < max_gnb)
                    {
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].ID = 1;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].IP_ADDRESS = "";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].SUBNET_MASK = "";
                        mac = addNet.next_mac(mac);
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[5]._interface[L2_switch_6_last_interface].CONNECTED_TO = "gNB_" + Convert.ToString(max_5G_core_devices  + 1 + r);
                        L2_switch_6_last_interface++;
                        r++;
                    }

                    //Links
                    //SMF with AMF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_AMF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 2;
                    link[link_count].link_device[0].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[0].INTERFACE_ID = 1;

                    link[link_count].link_device[1].DEVICE_ID = 3;
                    link[link_count].link_device[1].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;


                    //SMF with UPF
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "SMF_UPF";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[1].DEVICE_ID = 2;
                    link[link_count].link_device[1].NAME = "SMF_" + Convert.ToString(2);
                    link[link_count].link_device[1].INTERFACE_ID = 2;

                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 1;
                    link_count++;

                    //Connection UPF with L2_Switch_4
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "UPF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 1;
                    link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                    link[link_count].link_device[0].INTERFACE_ID = 2;

                    link[link_count].link_device[1].DEVICE_ID = 4;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(4);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;

                    //Connection AMF with L2_Switch_5
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "AMF_L2_Switch";
                    link[link_count].link_device = new LINK_DEVICE[2];
                    link[link_count].link_device[0].DEVICE_ID = 3;
                    link[link_count].link_device[0].NAME = "AMF_" + Convert.ToString(3);
                    link[link_count].link_device[0].INTERFACE_ID = 2;


                    link[link_count].link_device[1].DEVICE_ID = 5;
                    link[link_count].link_device[1].NAME = "L2_Switch_" + Convert.ToString(5);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link_count++;

                    //Link gnb and L2_switch
                    //L2_Switch_4 and gNB
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "L2_Swtich_gNB";
                    link[link_count].link_device = new LINK_DEVICE[max_gnb + 1];
                    link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x;
                    link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                    link[link_count].link_device[1].INTERFACE_ID = 1;
                    link[link_count].link_device[0].DEVICE_ID = 4;
                    link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(4);
                    link[link_count].link_device[0].INTERFACE_ID = 2;
                    link_count++;

                    //L2_Switch_5 with gNB
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "L2_Swtich_gNB";
                    link[link_count].link_device = new LINK_DEVICE[max_gnb + 1];
                    link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x;
                    link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                    link[link_count].link_device[1].INTERFACE_ID = 2;
                    link[link_count].link_device[0].DEVICE_ID = 5;
                    link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(5);
                    link[link_count].link_device[0].INTERFACE_ID = 2;
                    link_count++;

                    //L2_Switch_6 with gNB
                    link[link_count].DEVICE_COUNT = 2;
                    link[link_count].LINK_ID = link_count + 1;
                    link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                    link[link_count].link_type = "L2_Swtich_gNB";
                    link[link_count].link_device = new LINK_DEVICE[max_gnb + 1];
                    link[link_count].link_device[1].DEVICE_ID = NSA_gnb_idd_4x;
                    link[link_count].link_device[1].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                    link[link_count].link_device[1].INTERFACE_ID = 3;
                    link[link_count].link_device[0].DEVICE_ID = 6;
                    link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(6);
                    link[link_count].link_device[0].INTERFACE_ID = 1;
                    link_count++;

                    int upf_last_interface = 0;
                    int NSA_gnb_idd_1 = max_5G_core_devices + max_gnb;//max gNB check
                    string ip;
                    octate_4th += 2;
                    ipv4_count = 0;
                    int check = 1;
                    while (NSA_gnb_idd_4x - 1 < NSA_gnb_idd_1)
                    {

                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_ID = NSA_gnb_idd_4x;
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.DEVICE_TYPE = "LTE_gNB";
                        device_container_NSA[NSA_gnb_idd_4x - 1].device.INTERFACE_COUNT = 4;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface = new INTERFACE[4];



                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].ID = 1;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].MAC_ADDRESS = mac;

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[0].INTERFACE_TYPE = "5G_N3";
                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].ID = 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].MAC_ADDRESS = mac;

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[1].INTERFACE_TYPE = "5G_N1_N2";


                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].ID = 3;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[2].CONNECTED_TO = "L2_Switch_" + Convert.ToString(6);

                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[3].ID = 4;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[3].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_gnb_idd_4x - 1]._interface[3].INTERFACE_TYPE = "5G_RAN";
                        octate_4th += 2;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.X_OR_LON = gnbNSA_x0;
                        device_container_NSA[NSA_gnb_idd_4x - 1].pos_3d.Y_OR_LAT = gnbNSA_y0;
                        upf_last_interface++;
                        NSA_gnb_idd_4x++;


                    }



                    check = 1;
                    NSA_enb_idd_7 = max_5G_core_devices + max_gnb + 1;
                    //L2_Switch_4 connected with eNb
                    while (L2_switch_4_last_interface >= 2)
                    {
                        if (check > max_eNB)
                            break;


                        device_container_NSA[3]._interface[L2_switch_4_last_interface].ID = L2_switch_4_last_interface + 1;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[3]._interface[L2_switch_4_last_interface ].SUBNET_MASK = addNet.subnet_mask();
                        ip = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[3]._interface[L2_switch_4_last_interface ].CONNECTED_TO = "eNB_" + Convert.ToString(NSA_enb_idd_7 + check - 1);
                        device_container_NSA[3]._interface[L2_switch_4_last_interface ].INTERFACE_TYPE = "ETHERNET";
                        L2_switch_4_last_interface++;
                        NSA_enb_idd_7++;
                        check++;


                    }

                    check = 1;
                    NSA_enb_idd_7 = max_5G_core_devices + max_gnb + 1;
                    //L2_Switch_5 connected with enb
                    while (L2_switch_5_last_interface >= 2)
                    {
                        if (check > max_eNB)
                            break;


                        device_container_NSA[4]._interface[L2_switch_5_last_interface ].ID = L2_switch_5_last_interface + 1;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface ].DEFAULT_GATEWAY = "";
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        ip = addNet.next_ip(++ipv4_count, 1);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface ].IP_ADDRESS = ip;
                        mac = addNet.next_mac(mac);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[4]._interface[L2_switch_5_last_interface ].CONNECTED_TO = "eNB_" + Convert.ToString(NSA_enb_idd_7 + check - 1);
                        device_container_NSA[4]._interface[L2_switch_5_last_interface ].INTERFACE_TYPE = "ETHERNET";
                        L2_switch_5_last_interface++;
                        NSA_enb_idd_7++;
                        check++;


                    }




                    check = 1;
                    NSA_enb_idd_7 = max_5G_core_devices + max_gnb;
                    NSA_enb_idd_1 = max_5G_core_devices + max_gnb + max_eNB;
                    while (NSA_enb_idd_7 < NSA_enb_idd_1)
                    {

                        //L2_switch link_4 connection with eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "ENB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].link_device[0].DEVICE_ID = 4;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(4);
                        link[link_count].link_device[0].INTERFACE_ID = 3; //
                        link[link_count].link_device[1].DEVICE_ID = NSA_enb_idd_7 + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(NSA_enb_idd_7 + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 1;//
                        link_count++;

                        //L2_switch link_5 connection with eNB

                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "ENB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 5;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(5);
                        link[link_count].link_device[0].INTERFACE_ID = 3;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_enb_idd_7 + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(NSA_enb_idd_7 + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 2;//
                        link_count++;

                        //L2_switch_6 link connection with eNB
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "ENB_L2_Switch";
                        link[link_count].link_device = new LINK_DEVICE[2];

                        link[link_count].link_device[0].DEVICE_ID = 6;
                        link[link_count].link_device[0].NAME = "L2_Switch_" + Convert.ToString(6);
                        link[link_count].link_device[0].INTERFACE_ID = 2;//

                        link[link_count].link_device[1].DEVICE_ID = NSA_enb_idd_7 + 1;
                        link[link_count].link_device[1].NAME = "eNB_" + Convert.ToString(NSA_enb_idd_7 + 1);
                        link[link_count].link_device[1].INTERFACE_ID = 3;//
                        link_count++;
                        NSA_enb_idd_7++;


                    }

                    link_device_count = link[link_count].DEVICE_COUNT = 0;
                    double theta;
                    e_idd = max_5G_core_devices + max_gnb + 1;
                    NSA_gnb_idd_4x = max_5G_core_devices + 1;
                    r = 0;
                    ipv4_count = 0;
                    while (e_idd < eNb_idd)
                    {
                        device_container_NSA[e_idd - 1].device.DEVICE_ID = e_idd;
                        device_container_NSA[e_idd - 1].device.DEVICE_NAME = "eNB_" + Convert.ToString(e_idd);
                        device_container_NSA[e_idd - 1].device.DEVICE_TYPE = "LTE_eNB";

                        device_container_NSA[e_idd - 1]._interface = new INTERFACE[4];


                        device_container_NSA[e_idd - 1]._interface[0].ID = 1;
                        device_container_NSA[e_idd - 1]._interface[0].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[0].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[0].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[0].INTERFACE_TYPE = "5G_N3";
                        octate_4th += 2;
                        device_container_NSA[e_idd - 1]._interface[1].ID = 2;
                        device_container_NSA[e_idd - 1]._interface[1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[1].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[1].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[1].INTERFACE_TYPE = "5G_N1_N2";

                        octate_4th += 2;
                        device_container_NSA[e_idd - 1]._interface[2].ID = 3;
                        device_container_NSA[e_idd - 1]._interface[2].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th);
                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[2].MAC_ADDRESS = mac;

                        device_container_NSA[e_idd - 1]._interface[2].SUBNET_MASK = addNet.subnet_mask();
                        device_container_NSA[e_idd - 1]._interface[2].INTERFACE_TYPE = "5G_XN";

                        device_container_NSA[e_idd - 1]._interface[3].ID = 4;

                        mac = addNet.next_mac(mac);
                        device_container_NSA[e_idd - 1]._interface[3].MAC_ADDRESS = mac;
                        device_container_NSA[e_idd - 1]._interface[3].INTERFACE_TYPE = "LTE";


                        while (L2_switch_6_last_interface >= 1)
                        {
                            if (check > max_eNB)
                                break;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface].ID = L2_switch_6_last_interface +1;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface ].DEFAULT_GATEWAY = "";
                            device_container_NSA[5]._interface[L2_switch_6_last_interface ].SUBNET_MASK = addNet.subnet_mask();
                            ip = addNet.next_ip_1(ipv4_count, octate_4th);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface].IP_ADDRESS = ip;
                            mac = addNet.next_mac(mac);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[5]._interface[L2_switch_6_last_interface ].CONNECTED_TO = "eNB_" + Convert.ToString(e_idd + r);
                            device_container_NSA[5]._interface[L2_switch_6_last_interface].INTERFACE_TYPE = "ETHERNET";
                            L2_switch_6_last_interface++;
                            check++;

                        }

                        theta = e_idd * gnb_angle_increment;
                        device_container_NSA[e_idd - 1].pos_3d.X_OR_LON = enb_x0 + gnb_radius * Math.Cos(Math.PI * (theta / 180.0));
                        device_container_NSA[e_idd - 1].pos_3d.Y_OR_LAT = enb_y0 + gnb_radius * Math.Sin(Math.PI * (theta / 180.0));
                        double low_angle_NSA = theta - (num_ue_per_enb_NSA * ue_angle_increment / 2.0);



                        //Ue link 
                        //Link gNB  with Ue

                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "eNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_gnb + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = e_idd;
                        link[link_count].link_device[link_device_count].NAME = "eNB_" + Convert.ToString(e_idd);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 4;
                        link_device_count++;

                        //gnb with ue
                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = NSA_k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 1;
                            link_device_count++;
                            NSA_k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;


                        link_device_count = link[link_count].DEVICE_COUNT = 0;
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_type = "gNB_UE";
                        link[link_count].link_device = new LINK_DEVICE[num_ue_per_enb_NSA + 1];
                        link[link_count].link_device[link_device_count].DEVICE_ID = NSA_gnb_idd_4x;
                        link[link_count].link_device[link_device_count].NAME = "gNB_" + Convert.ToString(NSA_gnb_idd_4x);
                        link[link_count].link_device[link_device_count].INTERFACE_ID = 4;
                        link_device_count++;

                        k = 1;

                        for (int l = 0; l < num_ue_per_enb_NSA; l++)
                        {
                            int ue_id = k + max_5G_core_devices + max_eNB + max_gnb;
                            if (ue_id - 1 >= total_UE_check_4)
                                break;
                            ipv4_count = 0;
                            device_container_NSA[ue_id - 1].device.DEVICE_ID = ue_id;
                            device_container_NSA[ue_id - 1].device.DEVICE_NAME = "UE_" + Convert.ToString(ue_id);
                            device_container_NSA[ue_id - 1].device.DEVICE_TYPE = "LTE_NR_UE";
                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 0;
                            device_container_NSA[ue_id - 1].device.WIRESHARK_OPTION = "Disable";
                            device_container_NSA[ue_id - 1]._interface = new INTERFACE[2];

                            double theta1 = low_angle_NSA + l * ue_angle_increment;
                            device_container_NSA[ue_id - 1].pos_3d.X_OR_LON = enb_x0 + ue_radius * Math.Cos(Math.PI * (theta1 / 180.0));
                            device_container_NSA[ue_id - 1].pos_3d.Y_OR_LAT = enb_y0 + ue_radius * Math.Sin(Math.PI * (theta1 / 180.0));

                            int last_interface = device_container_NSA[ue_id - 1].device.INTERFACE_COUNT;
                            device_container_NSA[ue_id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[ue_id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th + l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface].INTERFACE_TYPE = "LTE";

                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].ID = last_interface + 2;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].DEFAULT_GATEWAY = ip_upf;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IP_ADDRESS = addNet.next_ip_1(ipv4_count, octate_4th + l + 2);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].SUBNET_MASK = addNet.subnet_mask();
                            mac = addNet.next_mac(mac);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MAC_ADDRESS = mac;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].CONNECTED_TO = "";
                            ime1_number = addNet.next_ime1_number(ime1_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].IMEI_NUMBER = ime1_number;
                            mobile_number = addNet.next_mobile_number(mobile_number);
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].MOBILE_NUMBER = mobile_number;
                            device_container_NSA[ue_id - 1]._interface[last_interface + 1].INTERFACE_TYPE = "5G_RAN";

                            device_container_NSA[ue_id - 1].device.INTERFACE_COUNT = 2;

                            link[link_count].link_device[link_device_count].DEVICE_ID = ue_id;
                            link[link_count].link_device[link_device_count].NAME = "UE_" + Convert.ToString(ue_id);
                            link[link_count].link_device[link_device_count].INTERFACE_ID = 2;
                            link_device_count++;
                            k++;
                        }
                        link[link_count].DEVICE_COUNT = link_device_count;
                        link_count++;
                        device_container_NSA[e_idd - 1].device.INTERFACE_COUNT = 4;
                        e_idd++;
                        r++;

                    }

                    i = max_5G_core_devices + max_eNB + max_gnb + max_ue;
                    //Add router
                    for (; i < (NSA_enb_idd_1 + max_ue + max_router); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Router_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "ROUTER";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";

                        device_container_NSA[i]._interface = new INTERFACE[max_router_interface];
                    }

                    //Add node
                    for (; i < (NSA_enb_idd_1 + max_ue + max_router + max_node); i++)
                    {
                        device_container_NSA[i].device.DEVICE_ID = i + 1;
                        device_container_NSA[i].device.DEVICE_NAME = "Wired_Node_" + Convert.ToString(i + 1);
                        device_container_NSA[i].device.DEVICE_TYPE = "WIREDNODE";
                        device_container_NSA[i].device.INTERFACE_COUNT = 0;
                        device_container_NSA[i].device.WIRESHARK_OPTION = "Disable";
                        device_container_NSA[i]._interface = new INTERFACE[1];
                    }



                    /*-----------------------------------------------------------------------------------------------------*/
                    // this block sets the attributes, position of first_router and
                    NSA_router_id_1 = max_5G_core_devices + max_gnb + max_eNB + max_ue + 1;
                    int NSA_max_router_id = max_5G_core_devices + max_gnb + max_eNB + max_ue + max_router;

                    check = 1;
                    while (NSA_router_id_1 - 1 < NSA_max_router_id)
                    {

                        if (check < max_router)
                            break;

                        device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                        device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;
                        upf_last_interface = device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                        device_container_NSA[0]._interface[0].DEFAULT_GATEWAY = addNet.next_ip_2(++ipv4_count, 2);
                        device_container_NSA[0]._interface[1].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                        device_container_NSA[0]._interface[2].DEFAULT_GATEWAY = addNet.next_ip_2(ipv4_count, 2);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip(ipv4_count, 2);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "SERIAL";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "UPF_" + Convert.ToString(1);

                        upf_last_interface++;

                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].ID = upf_last_interface + 1;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].DEFAULT_GATEWAY = "";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].SUBNET_MASK = addNet.subnet_mask();
                        mac = addNet.next_mac(mac);
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].MAC_ADDRESS = mac;
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].INTERFACE_TYPE = "ETHERNET";
                        device_container_NSA[NSA_router_id_1 - 1]._interface[upf_last_interface].CONNECTED_TO = "Wired_Node_" + Convert.ToString(NSA_router_id_1 + max_router);
                        device_container_NSA[NSA_router_id_1 - 1].device.INTERFACE_COUNT = upf_last_interface + 1;



                        //Router link with UPF
                        link[link_count].link_device = new LINK_DEVICE[2];
                        link[link_count].DEVICE_COUNT = 2;
                        link[link_count].link_type = "UPF_Router";
                        link[link_count].LINK_ID = link_count + 1;
                        link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                        link[link_count].link_device[1].DEVICE_ID = NSA_router_id_1;
                        link[link_count].link_device[1].INTERFACE_ID = 1;
                        link[link_count].link_device[1].NAME = "Router_" + Convert.ToString(NSA_router_id_1);
                        link[link_count].link_device[0].DEVICE_ID = 1;
                        link[link_count].link_device[0].INTERFACE_ID = 3;
                        link[link_count].link_device[0].NAME = "UPF_" + Convert.ToString(1);
                        link_count++;



                        device_container_NSA[NSA_router_id_1 - 1].level.r = 0.0;
                        theta0 = device_container_NSA[NSA_router_id_1 - 1].level.theta = 0.0;
                        level0 = device_container_NSA[NSA_router_id_1 - 1].level.level = 0;
                        increment0 = device_container_NSA[NSA_router_id_1 - 1].level.increment = (360.0 / Math.Pow(branch, level0 + 1));
                        device_container_NSA[NSA_router_id_1 - 1].level.low_angle = theta0 - (branch * 1.0) * increment0 / 2.0;
                        NSA_router_id_1++;
                        check++;
                    }
                    /*device_container_NSA[NSA_router_id_1 - 1].pos_3d.X_OR_LON = router_x0;
                    device_container_NSA[NSA_router_id_1 - 1].pos_3d.Y_OR_LAT = router_y0;*/

                    /***********************************************************************************************/
                    /*************************************************************************************************/

                    //Console.WriteLine(not_leaf_node);
                    //Console.ReadLine();

                    /************************************************************************************************/
                    // this block of code sets the sttributes,positions,interfaces,and link(to router) of all the wirednodes
                    i = max_router + max_5G_core_devices + max_gnb + max_eNB + max_ue;
                    // int kii = - 1;//first router id
                    int NSA_max_node_temp = max_node;
                    double r_level;

                    while (NSA_max_node_temp != 0)
                    {
                        for (j = max_5G_core_devices + max_gnb + max_ue + max_eNB; j < i; j++)
                        {
                            int router_id = j + 1;

                            int id = device_container_NSA[i].device.DEVICE_ID;
                            int last_interface = device_container_NSA[i].device.INTERFACE_COUNT;
                            int router_last_interface = device_container_NSA[router_id - 1].device.INTERFACE_COUNT;
                            POS_3D pos_3d = device_container_NSA[router_id - 1].pos_3d;

                            r_level = device_container_NSA[router_id - 1].level.r;
                            theta = device_container_NSA[router_id - 1].level.theta;
                            int level = device_container_NSA[router_id - 1].level.level;
                            low_angle = device_container_NSA[router_id - 1].level.low_angle;
                            double increment = device_container_NSA[router_id - 1].level.increment;




                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].ID = router_last_interface;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].DEFAULT_GATEWAY = "";

                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 1);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].MAC_ADDRESS = mac;
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].CONNECTED_TO = "";
                            device_container_NSA[router_id - 1]._interface[router_last_interface - 1].INTERFACE_TYPE = "ETHERNET";

                            ip = addNet.next_ip_3(ipv4_count, 1);
                            device_container_NSA[id - 1]._interface[last_interface].ID = last_interface + 1;
                            device_container_NSA[id - 1]._interface[last_interface].DEFAULT_GATEWAY = ip;
                            device_container_NSA[id - 1]._interface[last_interface].IP_ADDRESS = addNet.next_ip_3(ipv4_count, 2);
                            mac = addNet.next_mac(mac);
                            device_container_NSA[id - 1]._interface[last_interface].MAC_ADDRESS = mac;
                            device_container_NSA[id - 1]._interface[last_interface].SUBNET_MASK = addNet.subnet_mask();
                            device_container_NSA[id - 1]._interface[last_interface].CONNECTED_TO = "";
                            device_container_NSA[id - 1]._interface[last_interface].INTERFACE_TYPE = "ETHERNET";


                            double r1 = device_container_NSA[id - 1].level.r = r_level + offset_radius;
                            //Console.WriteLine(r);
                            //Console.WriteLine(r1);
                            double level1 = device_container_NSA[id - 1].level.level = level + 1;
                            double theta1 = device_container_NSA[id - 1].level.theta = low_angle + (router_last_interface - 1) * increment;
                            double increment1 = device_container_NSA[id - 1].level.increment = (360.0 / Math.Pow(branch, level1 + 1));
                            device_container_NSA[id - 1].level.low_angle = theta1 - (branch * 1.0) * increment1 / 2.0;

                            device_container_NSA[id - 1].pos_3d.X_OR_LON = (router_x0 + r1 * Math.Cos((theta1 / 180.0) * Math.PI));
                            device_container_NSA[id - 1].pos_3d.Y_OR_LAT = (router_y0 + r1 * Math.Sin((theta1 / 180.0) * Math.PI));


                            //device_container[id - 1].pos_3d.X_OR_LON = (pos_3d.X_OR_LON + 0.1);
                            //device_container[id - 1].pos_3d.Y_OR_LAT = (pos_3d.Y_OR_LAT + 0.1);

                            link[link_count].link_device = new LINK_DEVICE[2];
                            link[link_count].DEVICE_COUNT = 2;
                            link[link_count].LINK_ID = link_count + 1;
                            link[link_count].LINK_NAME = Convert.ToString(link_count + 1);
                            link[link_count].link_type = "Wired_Router";
                            link[link_count].link_device[1].DEVICE_ID = id;
                            link[link_count].link_device[1].INTERFACE_ID = last_interface + 1;
                            link[link_count].link_device[1].NAME = "Wired_Node_" + Convert.ToString(id);
                            link[link_count].link_device[0].DEVICE_ID = router_id;
                            link[link_count].link_device[0].INTERFACE_ID = last_interface + 2;
                            link[link_count].link_device[0].NAME = "Router_" + Convert.ToString(router_id);


                            device_container_NSA[id - 1].device.INTERFACE_COUNT = last_interface + 1;
                            device_container_NSA[router_id - 1].device.INTERFACE_COUNT = router_last_interface;

                            link_count++;
                            i++;
                            router_id++;


                            NSA_max_node_temp--;
                            if (NSA_max_node_temp == 0)
                                break;
                        }
                    }
                }

                /**************************************************************************************************/


                /************************************************************************************************/
                //this block of code randomly or from file  sets the  attributes for all the applications

                if (!application_from_file.Equals(""))
                {
                    /*
                      source id(max_router+1,max_router+max_node) and destination id(max_router+max_node+1,max_router+max_node+max_sensor) or vice versa
                    */
                    application_count = 0;
                    using (StreamReader sr = new StreamReader(application_from_file))
                    {
                        string line;
                        int count = 0;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (count == 0)
                            {
                                count++;
                                continue;
                            }
                            string[] tokens = line.Split(' ');
                            // Console.WriteLine(tokens[0]+","+tokens[1]);
                            if (application_count < max_application)
                            {
                                application[application_count].DESTINATION_ID = Convert.ToInt32(tokens[1]);
                                application[application_count].ID = application_count + 1;
                                application[application_count].NAME = "App" + Convert.ToString(application_count + 1) + "_CBR";
                                application[application_count].SOURCE_ID = Convert.ToInt32(tokens[0]);
                                application_count++;
                            }
                        }
                        // Console.ReadLine();
                    }
                }
                else
                {
                    //source = max_router + 1 to max_router + max_node
                    //destination = max_router + max_node + max_gnb + 1 to max_router + max_node + max_gnb + max_ue
                    if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
                    {
                        int node_start = max_epc + max_gnb + L2_Switch + max_router + 1;
                        int node_end = max_epc + max_gnb + L2_Switch + max_router + max_node + 1;
                        int ue_start = max_epc + max_gnb + L2_Switch + max_eNB + max_router + max_node + max_gnb;
                        //int ue_end = max_router + max_node + max_gnb + max_ue + 1;
                        int node = node_start;

                        for (i = 0; i < max_application; i++)
                        {
                            if (node == node_end)
                            {
                                ue_start++;
                                node = node_start;
                            }

                            application[i].DESTINATION_ID = node;
                            application[i].ID = i + 1;
                            application[i].NAME = Convert.ToString(i + 1);
                            application[i].SOURCE_ID = ue_start;
                            ue_start++;
                        }
                    }
                    else
                    {
                        int node_start = max_5G_core_devices+max_eNB  + max_gnb + max_ue + max_router + 1;
                        int node_end = max_5G_core_devices + max_eNB + max_gnb + max_ue + max_router  + max_node + 1;
                        int ue_start = max_5G_core_devices + max_eNB +  max_gnb + 1;
                        //int ue_end = max_router + max_node + max_gnb + max_ue + 1;
                        int node = node_start;

                        for (i = 0; i < max_application; i++)
                        {
                            if (node == node_end)
                            {
                                ue_start++;
                                node = node_start;
                            }

                            application[i].DESTINATION_ID = node;
                            application[i].ID = i + 1;
                            application[i].NAME = Convert.ToString(i + 1);
                            application[i].SOURCE_ID = ue_start;
                            ue_start++;
                        }

                    }
                }
                /***************************************************************************************/


                /***************************************************************************************/

                if ((args[1] == "OPTION_3") || (args[1] == "OPTION_3a") || (args[1] == "OPTION_3x"))
                {
                    //this block of code calls the diffrent funtions to create the Configuration.netsim
                    nsWriter.add_experimentInfo(root, exp_name, version_name, mode, option);
                    //nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\Experiment_Info.txt");
                    nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\NSA\\Gui_Info.txt");
                    addNet.add_network(root, total_device_NSA, link_count, max_application, device_container_NSA, link, application, config_helper_location, args,gnb_ip_address);
                    nsWriter.add_simulation_parameter(root, simulation_time);
                    //nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\Simulation_Parameter.txt");

                    nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\NSA\\Protocol_Configuration.txt");
                    nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\NSA\\Statistics_Collection.txt");
                    nsWriter.save_document(config_helper_location + "\\Configuration.netsim");
                }
                else
                {
                    //this block of code calls the diffrent funtions to create the Configuration.netsim
                    nsWriter.add_experimentInfo(root, exp_name, version_name, mode, option);
                    //nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\Experiment_Info.txt");
                    nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\NSA\\Gui_Info.txt");
                    addNet.add_network(root, total_device_NSA_4, link_count, max_application, device_container_NSA, link, application, config_helper_location, args,gnb_ip_address);
                    nsWriter.add_simulation_parameter(root, simulation_time);
                    //nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\Simulation_Parameter.txt");

                    nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\NSA\\Protocol_Configuration.txt");
                    nsWriter.add_element_from_file(root, config_helper_location + "\\ConfigHelper\\NSA\\Statistics_Collection.txt");
                    nsWriter.save_document(config_helper_location + "\\Configuration.netsim");

                }
                    /***************************************************************************************/


                
            }



      
            /***************************************************************************************/
        }
    }
}